#ifndef SYSTEM_INTERRUPT_H_
#define SYSTEM_INTERRUPT_H_

#include "../user/inc/Dsp280015x.h"
#include "../Diagnostic/diagnostic.h"

#ifdef  SYSTEM_INTERRUPT_C_
    #define SYSTEM_INTERRUPT
#else
    #define SYSTEM_INTERRUPT  extern
#endif

SYSTEM_INTERRUPT __interrupt void INT_CpuTimer1_ISR(void);

#endif /* SYSTEM_INTERRUPT_H_ */

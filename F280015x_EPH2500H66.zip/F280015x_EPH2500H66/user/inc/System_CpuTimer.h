#ifndef SYSTEM_CPUTIMER_H_
#define SYSTEM_CPUTIMER_H_

#include "../user/inc/Dsp280015x.h"

#ifdef  SYSTEM_CPUTIMER_C_
    #define SYSTEM_CPUTIMER
#else
    #define SYSTEM_CPUTIMER  extern
#endif

SYSTEM_CPUTIMER void System_CpuTimerInit(uint32_t CpuTimerBase,uint32_t period_us);

#endif /* SYSTEM_CPUTIMER_H_ */

#ifndef APP_CANVEHICLEINIT_H_
#define APP_CANVEHICLEINIT_H_

#include "../user/inc/Dsp280015x.h"

#define CAN_VEHCILE_BASE                        CANA_BASE
#define CAN_VEHCILE_BITRATE                     500000

#define CAN_VEHCILE_RECV_ID                     0x747
#define CAN_VEHCILE_SEND_ID0                    0x787
#define CAN_VEHCILE_SEND_ID1                    0x767
#define CAN_VEHCILE_SEND_ID2                    0x768

#define CAN_VEHCILE_RECV_MAILBOX_ID             1
#define CAN_VEHCILE_SEND0_MAILBOX_ID            11
#define CAN_VEHCILE_SEND1_MAILBOX_ID            12
#define CAN_VEHCILE_SEND2_MAILBOX_ID            13

#define CAN_VEHCILE_RECV_NUMBER                 1
#define CAN_VEHCILE_SEND_NUMBER                 2

#define CAN_UDS_TESTER_FUNC_ID                  0x7DF
#define CAN_UDS_TESTER_PHY_ID                   0x735
#define CAN_UDS_ECU_PHY_ID                      0x73D

#define CAN_UDS_TESTER_FUNC_MAILBOX_ID          4
#define CAN_UDS_TESTER_PHY_MAILBOX_ID           5
#define CAN_UDS_ECU_PHY_MAILBOX_ID              29

#define CAN_UDS_MAILBOX_DATA_LENGTH             8
#define CAN_COM_MAILBOX_DATA_LENGTH             8

typedef struct
{
    uint32_t         TesterFuncMsgID;
    uint32_t         TesterPhyMsgID;
    uint32_t         EcuPhyMsgID;

    uint32_t         TesterFuncMbID;
    uint32_t         TesterPhyMbID;
    uint32_t         EcuPhyMbID;

    CAN_MsgFrameType TesterFuncMsgType;
    CAN_MsgFrameType TesterPhyMsgType;
    CAN_MsgFrameType EcuPhyMsgType;

    uint16_t         TesterFuncMsgData[8];
    uint16_t         TesterPhyMsgData[8];
    uint16_t         EcuPhyMsgData[8];

} CAN_UDS_MB_t;

typedef struct
{
    uint32_t         TxMsgID[12];
    uint16_t         TxMailBoxID[12];
    CAN_MsgFrameType TxMsgFrameType[12];
    uint32_t         RxMsgID[12];
    uint16_t         RxMailBoxID[12];
    CAN_MsgFrameType RxMsgFrameType[12];
    uint16_t         TxData[8];
    uint16_t         RxData[8];

    uint16_t         TxMsgNum;
    uint16_t         RxMsgNum;

} CAN_VEHICLE_MB_t;

#ifdef  APP_CANVEHICLEINIT_C
    #define APP_CANVEHICLEINIT
#else
    #define APP_CANVEHICLEINIT  extern
#endif


APP_CANVEHICLEINIT CAN_UDS_MB_t UdsMB;
APP_CANVEHICLEINIT CAN_VEHICLE_MB_t VCanMB;

APP_CANVEHICLEINIT void CanVehicle_Init(CAN_UDS_MB_t *pUds,CAN_VEHICLE_MB_t *pCar);//(uint32_t Bps,CAN_UDS_MB_t *pUds,CAN_VEHICLE_MB_t *pCar);

APP_CANVEHICLEINIT void CanVehicle_Test(uint16_t RxMbId,uint16_t TxMbId);

APP_CANVEHICLEINIT void CanVehicle_UdsSendMessage(uint32_t msgID,const uint16_t *msgData,uint16_t msgLen);
APP_CANVEHICLEINIT uint16_t CanVehicle_UdsRecvMassage(void);

#endif /* APP_CANVEHICLEINIT_H_ */

#ifndef DSP280015X_H_
#define DSP280015X_H_

#include "stdint.h"
#include "stdbool.h"
#include "driverlib.h"
#include "device.h"
#include "string.h"


typedef uint16_t byte;
typedef uint16_t word;
typedef uint32_t dword;

#endif /* DSP280015X_H_ */

#ifndef APP_UDSIF_H_
#define APP_UDSIF_H_

#include "../Diagnostic/diagnostic.h"
#include "../user/inc/Dsp280015x.h"

#ifdef  APP_UDSIF_C_
    #define APP_UDSIF
#else
    #define APP_UDSIF  extern
#endif

typedef struct
{
    uint32_t TesterFuncMsgID;
    uint32_t TesterPhyMsgID;
    uint32_t EcuPhyMsgID;
} UDS_IF_DATA_t;

APP_UDSIF UDS_IF_DATA_t UdsIf;
APP_UDSIF uint8_t App_RxEnable;
APP_UDSIF uint8_t App_TxEnable;

APP_UDSIF void Diagnostic_RecvFrame(void);
APP_UDSIF void Diagnostic_InitConfig(UDS_IF_DATA_t *pUds);
APP_UDSIF byte Diagnostic_SendFrame(uint32_t ID, byte *array, byte length);
#endif /* APP_UDSIF_H_ */

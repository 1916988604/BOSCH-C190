#ifndef APP_CANVEHICLEINIT_C_
#define APP_CANVEHICLEINIT_C_

#include "app_include.h"

CAN_UDS_MB_t UdsMB;
CAN_VEHICLE_MB_t VCanMB;
/*****************************************************************
 **fun    : CANģ���ʼ��
 **name   : CanVehicle_ModuleInit
 **return : ��
 ****************************************************************/
void CanVehicle_ModuleInit(void)
{
    //myCAN0 initialization
    CAN_initModule(CAN_VEHCILE_BASE);

#if XTAL_PLL_FREQ==0  || XTAL_PLL_FREQ==2
    #if BAUDRATE_SEL==0
        CAN_setBitTiming(myCAN0_BASE, 9, 0, 14, 7, 3); //500k,������79.1%
    #else
        CAN_setBitTiming(myCAN0_BASE, 19, 0, 14, 7, 3); //250k,������79.1%
    #endif
#else
    #if BAUDRATE_SEL==0
        CAN_setBitTiming(myCAN0_BASE, 7, 0, 15, 7, 3); //500k,������79.1%
    #else
        CAN_setBitTiming(myCAN0_BASE, 15, 0, 15, 7, 3); //250k,������79.1%
    #endif
#endif

    //Sets the CAN Bit Timing based on requested Bit Rate
    //CAN_setBitRate(CAN_VEHCILE_BASE, DEVICE_SYSCLK_FREQ, Bps, 20);

}



/*****************************************************************
 **fun    : ���CAN��Ϣ��ʼ��
 **name   : CanVehicle_UdsMailBoxInit
 **param0 : pUds:ָ��CAN_UDS_MB_t(���CAN)��ָ�����
 **return : ��
 ****************************************************************/
void CanVehicle_UdsMailBoxInit(CAN_UDS_MB_t *pUds)
{
    //���ò���������ID��CAN��Ϣ
    CAN_setupMessageObject(CAN_VEHCILE_BASE,
                           pUds->TesterPhyMbID,
                           pUds->TesterPhyMsgID,
                           pUds->TesterPhyMsgType,
                           CAN_MSG_OBJ_TYPE_RX,
                           0,
                           0,
                           CAN_UDS_MAILBOX_DATA_LENGTH);

    //���ò����ǹ���ID��CAN��Ϣ
    CAN_setupMessageObject(CAN_VEHCILE_BASE,
                           pUds->TesterFuncMbID,
                           pUds->TesterFuncMsgID,
                           pUds->TesterFuncMsgType,
                           CAN_MSG_OBJ_TYPE_RX,
                           0,
                           0,
                           CAN_UDS_MAILBOX_DATA_LENGTH);

    //����ECU����ID��CAN��Ϣ
    CAN_setupMessageObject(CAN_VEHCILE_BASE,
                           pUds->EcuPhyMbID,
                           pUds->EcuPhyMsgID,
                           pUds->EcuPhyMsgType,
                           CAN_MSG_OBJ_TYPE_TX,
                           0,
                           0,
                           CAN_UDS_MAILBOX_DATA_LENGTH);
}



/*****************************************************************
 **fun    : ͨѶCAN��Ϣ��ʼ��
 **name   : CanVehicle_CarMailBoxInit
 **param0 : pCar:ָ��CAN_VEHICLE_MB_t(ͨѶCAN)��ָ�����
 **return : ��
 ****************************************************************/
void CanVehicle_CarMailBoxInit(CAN_VEHICLE_MB_t *pCar)
{
    uint16_t i = 0;

    for(i = 0; i < pCar->RxMsgNum; i++)
    {
        //����ͨѶCANRX��Ϣ
        CAN_setupMessageObject(CAN_VEHCILE_BASE,
                               pCar->RxMailBoxID[i],
                               pCar->RxMsgID[i],
                               pCar->RxMsgFrameType[i],
                               CAN_MSG_OBJ_TYPE_RX,
                               0,
                               0,
                               CAN_COM_MAILBOX_DATA_LENGTH);
    }

    for(i = 0; i < pCar->TxMsgNum; i++)
    {
        //����ͨѶCANTX��Ϣ
        CAN_setupMessageObject(CAN_VEHCILE_BASE,
                               pCar->TxMailBoxID[i],
                               pCar->TxMsgID[i],
                               pCar->TxMsgFrameType[i],
                               CAN_MSG_OBJ_TYPE_TX,
                               0,
                               0,
                               CAN_COM_MAILBOX_DATA_LENGTH);
    }

}



/*****************************************************************
 **fun    : CAN��ʼ��
 **name   : CanVehicle_Init
 **param0 : Bps:������
 **param1 : pUds:ָ��CAN_UDS_MB_t(���CAN)��ָ�����
 **param2 : pCar:ָ��CAN_VEHICLE_MB_t(ͨѶCAN)��ָ�����
 **return : ��
 ****************************************************************/
void CanVehicle_Init(CAN_UDS_MB_t *pUds, CAN_VEHICLE_MB_t *pCar)
{
    CanVehicle_ModuleInit();
    CanVehicle_UdsMailBoxInit(pUds);
    CanVehicle_CarMailBoxInit(pCar);

    //Starts the CAN Module's Operations
    CAN_startModule(CAN_VEHCILE_BASE);
}



/*****************************************************************
 **fun    : CANͨѶ���Ժ���
 **name   : CanVehicle_Test
 **param0 : RxMbId:��������ID
 **param1 : TxMbId:��������ID
 **return : ��
 ****************************************************************/
void CanVehicle_Test(uint16_t RxMbId, uint16_t TxMbId)
{
    uint16_t RxData[8]={0,0,0,0,0,0,0,0};
    uint16_t TxData[8]={0,0,0,0,0,0,0,0};
    if(CAN_readMessage(CAN_VEHCILE_BASE, RxMbId, RxData) == 1)
    {
        if(RxData[0] == 0xFF)
        {
            TxData[0] = 0xFF;
            TxData[1] = 9;
            TxData[2] = 2;
            TxData[3] = 3;
            TxData[4] = 4;
            TxData[5] = 5;
            TxData[6] = 6;
            TxData[7] = 9;
            CAN_sendMessage(CAN_VEHCILE_BASE, TxMbId, CAN_COM_MAILBOX_DATA_LENGTH, TxData);
        }
    }

}



/*****************************************************************
 **fun    : ���CAN���ݷ��ͺ���
 **name   : CanVehicle_Test
 **param0 : msgID:���CANTX��ID
 **param1 : msgData:�������ݴ洢��ַ
 **param1 : msgLen:���ݳ���
 **return : ��
 ****************************************************************/
void CanVehicle_UdsSendMessage(uint32_t msgID, const uint16_t *msgData,uint16_t msgLen)
{
    if(msgID == UdsMB.EcuPhyMsgID)
    {
        CAN_sendMessage_updateDLC(CAN_VEHCILE_BASE, UdsMB.EcuPhyMbID, msgLen, msgData);
    }

}

/*****************************************************************
 **fun    : ���CAN���ݽ��պ�����
 **name   : CanVehicle_UdsRecvMassage
 **param0 : ��
 **return : 1:���յ�����CANID����Ϣ
 **         2:���յ�����CANID����Ϣ
 **         3:û�н��յ����CAN����
 ****************************************************************/
uint16_t CanVehicle_UdsRecvMassage(void)
{

    if(CAN_readMessageWithID(CAN_VEHCILE_BASE,
                             UdsMB.TesterPhyMbID,
                             &UdsMB.TesterPhyMsgType,
                             &UdsMB.TesterPhyMsgID,
                             &UdsMB.TesterPhyMsgData[0]))
    {
        return 1;
    }
    else if(CAN_readMessageWithID(CAN_VEHCILE_BASE,
                                  UdsMB.TesterFuncMbID,
                                  &UdsMB.TesterFuncMsgType,
                                  &UdsMB.TesterFuncMsgID,
                                  &UdsMB.TesterFuncMsgData[0]))
    {
        return 2;
    }
    else
    {
        return 0;
    }
}

#endif /* APP_CANVEHICLEINIT_C_ */

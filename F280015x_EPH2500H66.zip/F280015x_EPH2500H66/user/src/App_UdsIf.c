#ifndef APP_UDSIF_C_
#define APP_UDSIF_C_

#include "app_include.h"

UDS_IF_DATA_t UdsIf;
uint8_t App_RxEnable = 1;//����Ӧ�ñ��Ľ���
uint8_t App_TxEnable = 1;//����Ӧ�ñ��ķ���
extern uint16 Buffer[250];

uint16_t TestF180Data = 0xF180;
uint8_t TestCurrentTemp = 0x40;
uint16_t CurrentSpeed = 0x0895;
uint8_t CurrentVoltage = 135;

//static uint8_t FingerID[14];   //ָ����Ϣ
uint8_t IO9826_MixMtrCtrl;

//extern uint32 Example_ProgramUsingAutoECC(uint32 address, uint8_t* data, uint16 Length);


void ForceReset(void)
{

    Buffer[0] = 0x55;//0x55BB;
    Buffer[1] = 0xBB;
    Buffer[2] = 0x55;//0x5500;
    Buffer[3] = 0x00;
    Buffer[4] = 0x55;//0x5511;
    Buffer[5] = 0x11;
    Buffer[6] = 0x55;//0x5522;
    Buffer[7] = 0x22;
    Buffer[8] = 0x55;//0x5533;
    Buffer[9] = 0x33;
    Buffer[10] = 0x55;//0x5544;
    Buffer[11] = 0x44;
    Buffer[12] = 0x55;//0x5555;
    Buffer[13] = 0x55;
    Buffer[14] = 0x55;//0x5566;
    Buffer[15] = 0x66;

    DINT;
    //Example_ProgramUsingAutoECC(FLASH_FLG1_ADDRESS, Buffer, 8);
    SysCtl_enableWatchdog();
    while (1)
    {
       asm(" nop");
    }

}

void SystemReset(EcuResetType resetType)
{
    if(resetType == 1)//Ӳ����λ
    {
        ForceReset();
    }
    else if(resetType == 2)//key-off-on��λ
    {
        //ForceReset();��֧�ָ�λ����ʱ��������������
    }
    else if(resetType == 3)//������λ
    {
        //ForceReset();
    }
}

void CommulicatonControl(CommulicationType type, communicationParam param)
{
    bool rxenable = ((type & 0x02) == 0x00);//��������
    bool txenable = ((type & 0x01) == 0x00);//��������
    bool CtrlNmMessage = ((param & 0x02) == 0x02);//�������������Ϣ
    bool CtrlAppMessage = ((param & 0x01) == 0x01);//����Ӧ�ñ���

    if(CtrlNmMessage)
    {
        //NMSetCommulicationEnable(txenable, rxenable);

    }

    if(CtrlAppMessage){
        if(rxenable){
            App_RxEnable = 1;
        }else{
            App_RxEnable = 0;
            J1939_Module.flag_rece1 = 0;
        }

        if(txenable){
            App_TxEnable = 1;
        }else{
            App_TxEnable = 0;
        }
    }
}


void SeedToKeyDemo(uint8_t *seed, uint8_t *key, uint8_t size)
{
    uint8_t i;
    for(i = 0; i < size; i++)
    {
        *(key+i)=*(seed+i)+1;
        *(key+i) =  *(key+i) & 0x00FF;
    }
}

uint8_t IoControl_9826(uint8_t ctrl, uint8_t param)
{
    if(ctrl == 0) {
        IO9826_MixMtrCtrl = 2;
    }
    else if(ctrl == 1)
    {
        IO9826_MixMtrCtrl = 2;
    } else if(ctrl == 2)
    {

    }else if(ctrl == 3)
    {
        if(param == 0)
        {
            IO9826_MixMtrCtrl = 0;
        }
        else if(param == 1)
        {
            IO9826_MixMtrCtrl = 1;
        }
    }
    return IO9826_MixMtrCtrl;
}

uint8_t NMGetLimpHome(void)
{
     if (1)
     {
        return 2;//failed
     }
     else
     {
        return 0;//passed
     }
}

byte Diagnostic_SendFrame(uint32_t ID, byte *array, byte length)
{
    CanVehicle_UdsSendMessage(ID, array, length);
    return 1;
}

/*****************************************************************
 **fun    : ���CAN���ݽ��պ�����
 **name   : Diagnostic_RecvFrame
 **param0 : ��
 **Temp   : 1:���յ�����CANID����Ϣ
 **         2:���յ�����CANID����Ϣ
 ****************************************************************/
void Diagnostic_RecvFrame(void)
{
    uint16_t Temp = CanVehicle_UdsRecvMassage();
    if(Temp == 1)
    {
        Diagnostic_RxFrame(UdsMB.TesterPhyMsgID, &UdsMB.TesterPhyMsgData[0], UdsMB.TesterPhyMsgType, 8, 0);
    }
    else if(Temp == 2)
    {
        Diagnostic_RxFrame(UdsMB.TesterFuncMsgID, &UdsMB.TesterFuncMsgData[0], UdsMB.TesterFuncMsgType, 8, 0);
    }
}

void Diagnostic_InitConfig(UDS_IF_DATA_t *pUds)
{

    //                                                                                                               P2server=50ms P2*server=200*10=2s
    Diagnostic_Init(pUds->TesterPhyMsgID, pUds->EcuPhyMsgID, pUds->TesterFuncMsgID, 0x00085008, 1024, Diagnostic_SendFrame,   0x0032,     0x00C8);
    //Diagnostic_Set2ndReqAndResID(0x18DA19F9, 0x18DAF919 , 0x18DBFFF9);

    //service 3E
    InitSetSessionSupportAndSecurityAccess(TRUE, 0x3E, LEVEL_ZERO, LEVEL_ZERO, LEVEL_ZERO, LEVEL_ZERO, LEVEL_ZERO, LEVEL_ZERO);
    InitSetTesterPresentSupress(TRUE);

    //service 10
    InitSetSessionSupportAndSecurityAccess(TRUE, 0x10, LEVEL_ZERO, LEVEL_ZERO, LEVEL_ZERO, LEVEL_ZERO, LEVEL_ZERO, LEVEL_ZERO);
    InitSetSessionControlParam(TRUE, TRUE, TRUE, FALSE, FALSE, TRUE);

    //service 85
    InitSetSessionSupportAndSecurityAccess(TRUE, 0x85, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT, LEVEL_ZERO, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT, LEVEL_ZERO);
    InitSetDTCControlSupress(TRUE);//TRUE:֧��������Ӧ  FALSE:��֧��������Ӧ

    //service 28
    InitSetSessionSupportAndSecurityAccess(TRUE, 0x28, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT, LEVEL_ZERO, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT, LEVEL_ZERO);
    InitSetCommControlParam(TRUE, FALSE, FALSE, TRUE, TRUE, FALSE, FALSE, CommulicatonControl, TRUE);

    //service 22
    InitSetSessionSupportAndSecurityAccess(TRUE, 0x22, LEVEL_ZERO, LEVEL_UNSUPPORT, LEVEL_ZERO, LEVEL_ZERO, LEVEL_UNSUPPORT, LEVEL_ZERO);
    InitAddDID(0xF189, 1, NULL, EEPROM_DID, NULL, READONLY, 0, TRUE);//�����汾 ��Ӧ�̴��룬�����洢��EEPROM�У�������������ʱд��
    InitAddDID(0xF191, 1, NULL, EEPROM_DID, NULL, READONLY, 0, TRUE);//Ӳ���汾 ��Ӧ�̴��룬�����洢��EEPROM�У�������������ʱд��
/*
    //service 27
    InitSetSessionSupportAndSecurityAccess(TRUE, 0x27, LEVEL_UNSUPPORT, LEVEL_ZERO, LEVEL_ZERO, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT);
    InitAddSecurityAlgorithm(LEVEL_ONE, SeedToKeyDemo, 0x01, 0x02, NULL, 3, 10000, SUB_PROGRAM | SUB_EXTENDED, 4);
    InitFactorySecuriyAlgorithm();//������ȫ�ȼ�����

    //service 2E
    InitSetSessionSupportAndSecurityAccess(TRUE, 0x2E, LEVEL_UNSUPPORT, LEVEL_ONE, LEVEL_ONE, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT);
    InitAddDID(0xF15A, 14, FingerID, REALTIME_DID, NULL, WRITEONLY, 0, TRUE);//ָ����Ϣ ��Ӧ�̴��룬�����洢��EEPROM�У�������������ʱд��

    //service 31
    InitSetSessionSupportAndSecurityAccess(TRUE, 0x31, LEVEL_UNSUPPORT, LEVEL_ONE, LEVEL_ONE, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT);

    //service 34
    InitSetSessionSupportAndSecurityAccess(TRUE, 0x34, LEVEL_UNSUPPORT, LEVEL_ONE, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT);

    //service 36
    InitSetSessionSupportAndSecurityAccess(TRUE, 0x36, LEVEL_UNSUPPORT, LEVEL_ONE, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT);

    //service 37
    InitSetSessionSupportAndSecurityAccess(TRUE, 0x37, LEVEL_UNSUPPORT, LEVEL_ONE, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT);

    //service 11
    InitSetSessionSupportAndSecurityAccess(TRUE, 0x11, LEVEL_ZERO, LEVEL_ZERO, LEVEL_ZERO, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT, LEVEL_UNSUPPORT);
    InitSetSysResetParam(TRUE, FALSE, FALSE, FALSE, FALSE, SystemReset, TRUE);
*/
    //service 14
    InitSetSessionSupportAndSecurityAccess(TRUE, 0x14, LEVEL_ZERO, LEVEL_UNSUPPORT, LEVEL_ZERO, LEVEL_ZERO, LEVEL_UNSUPPORT, LEVEL_ZERO);
    InitAddDTCGroup(0x00FFFFFF);

    //                    As   Bs   Cr   Ar   Br  Cs   BS STmin FillData
    Diagnostic_SetNLParam(150, 150, 150, 150, 70, 70,  0,  20,   0x55);//�����ͨѶ�������� //STmin=20;
}

#endif /* APP_UDSIF_C_ */

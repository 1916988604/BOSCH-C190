#ifndef SYSTEM_INTERRUPT_C_
#define SYSTEM_INTERRUPT_C_

#include "app_include.h"

/*****************************************************************
 **fun    : ϵͳ�ж�1��ʼ��
 **name   : INT_CpuTimer1_ISR
 **param0 : ��
 **return : ��
 ****************************************************************/
__interrupt void INT_CpuTimer1_ISR(void)
{
    static uint32_t Counter = 0;

    Counter++;
    if(Counter % 2 == 0)
    {
        Diagnostic_1msTimer();
    }
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}

#endif /* SYSTEM_CPUTIMER_C_ */



#ifndef SYSTEM_CPUTIMER_C_
#define SYSTEM_CPUTIMER_C_

#include "app_include.h"


/*****************************************************************
 **fun    : ϵͳ��ʱ����ʼ��
 **name   : System_CpuTimerInit
 **param0 : CpuTimerBase:��ʱ���ڴ��ַ
 **param1 : period_us   :��ʱʱ�䣬��λus
 **return : ��
 ****************************************************************/
void System_CpuTimerInit(uint32_t CpuTimerBase,uint32_t period_us)
{
    uint32_t temp;

    //
    // Initialize timer period:
    //
#if XTAL_PLL_FREQ==0  || XTAL_PLL_FREQ==2
    temp = (uint32_t)(DEVICE_SYSCLK_FREQ / 1200000 * period_us);
#else
    temp = (uint32_t)(DEVICE_SYSCLK_FREQ / 1000000 * period_us);
#endif
    CPUTimer_setPeriod(CpuTimerBase, temp);

    //
    // Set pre-scale counter to divide by 1 (SYSCLKOUT):
    //
    CPUTimer_setPreScaler(CpuTimerBase, 0);

    //
    // Initializes timer control register. The timer is stopped, reloaded,
    // free run disabled, and interrupt enabled.
    // Additionally, the free and soft bits are set
    //
    CPUTimer_stopTimer(CpuTimerBase);
    CPUTimer_reloadTimerCounter(CpuTimerBase);
    CPUTimer_setEmulationMode(CpuTimerBase, CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
    CPUTimer_enableInterrupt(CpuTimerBase);

    CPUTimer_startTimer(CpuTimerBase);
}

#endif /* SYSTEM_CPUTIMER_C_ */



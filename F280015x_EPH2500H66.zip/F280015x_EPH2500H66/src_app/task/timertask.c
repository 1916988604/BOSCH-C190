//������

#ifndef SRC_APP_TIMERTASK_C_
#define SRC_APP_TIMERTASK_C_

#include "app_include.h"
extern uint16_t txData[8];
extern uint16_t rxData[8];
extern volatile uint32_t level0Count;

float uln_data[21]={0};

#define TASK_NUM    7
static const TASK_TYPE task_list[] =
{
    {ms1_task,                 1},
    {ms2_task,                 2},
    {ms5_task,                 5},
    {ms10_task,               10},
    {ms20_task,               20},
    {ms50_task,               50},
    {ms100_task,             100},
};

void timer_task_init(void)
{
#if PCBA_TYPE == driverC250_PCBA
    AiCalc_init();
    sci_comm_init();
#else
    outPwmInit();
    eCap_Init();
    AiCalc_init();
    sci_comm_init();
#endif
#if    SCI_DtoC_EN ==1
    f_rs485_DtoC_ComInit();
#endif
#if    SCI_HtoC_EN ==1
    f_rs485_HtoC_ComInit();
#endif
#if    SCI_485_EN ==1
    f_rs485_ComInit();
#endif


#if PCBA_TYPE==control_PCBA
    relay_init();
#elif PCBA_TYPE == driverES_PCBA
    f_igbtTemp_Init();
    f_preRelayCtrlInit();
    powerAndLmtInit();
    QH_pump_Init();
    speedRamp_init();
    f_udcAdjust_init();
    gear_init();
    liquidLmtInit();
#elif PCBA_TYPE == driverC250_PCBA
    f_igbtTemp_Init();
    powerAndLmtInit();
    speedRamp_init();
    f_udcAdjust_init();
    liquidLmtInit();
#else
    led_init();
#endif

    timeTask_cnt = 0;
}

void timer_task(void)
{
    uint8_t i = 0;
    static uint32_t tick[TASK_NUM]={0,0,0,0,0,0,0};

    for (i = 0; i < TASK_NUM; i++)
    {
        if(fabsf(timeTask_cnt - tick[i]) >= task_list[i].interval)
        {
            tick[i] = timeTask_cnt;
            task_list[i].timer_task();
        }
    }
}

void ms1_task(void)
{
#if PCBA_TYPE == driverC250_PCBA
    Ai8Calc();//ת���˲�
#else
    unsigned int i;
    float f_temp;
    static unsigned int freq_flg=0,freq_type=19,freq_cnt=0;
    static unsigned int delay_freq_cnt=0;
    static float freq_dataMaxBak=0;

    delay_freq_cnt++;
    if(delay_freq_cnt>1000)     //�ϵ���ʱ1S
    {   //3����������
        delay_freq_cnt = 1000;
        if(freq_flg==0){
            if(freq_dataMaxBak > aiDeal[1]){      //ץȡ������Ϊ��ʼ��
                freq_flg = 1;
            }else{
                freq_dataMaxBak = aiDeal[1];
            }
            freq_cnt=0;
        }

        if((freq_cnt>10)&&(freq_cnt<22)&&(freq_flg==1)){
            f_temp = freq_dataMaxBak - aiDeal[1];
            if(fabsf(f_temp) < 100.0f){
                if(freq_cnt>17){
                    freq_type = 19; //50Hz
                }else{
                    freq_type = 15; //60Hz
                }
                freq_flg=2;
            }else{
            }
        }else{
        }
        freq_type=19;
        freq_cnt++;

        for(i=0; i<freq_type; i++){            //50Hz
            uln_data[i] = uln_data[i+1];
        }
        uln_data[freq_type] = aiDeal[1];
        uln_data[20] = 0;
        for(i=0; i<(freq_type+1); i++){
            uln_data[20] = uln_data[20] + uln_data[i];
        }
    }
    Ai8Calc();//ת���˲�
#endif

}

void ms2_task(void)
{
    #if    SCI_DtoC_EN ==1
        SciDeal_DtoC();
    #endif
    #if    SCI_HtoC_EN ==1
        SciDeal_HtoC();
    #endif
    #if    SCI_485_EN ==1
        SciDeal();  //������ӻ�
    #endif
}

void ms5_task(void)
{
#if PCBA_TYPE==display_PCBA
    KeyScan();
    UpdateDisplayBuffer();
    led_display();
#endif
}

void ms10_task(void)
{
#if PCBA_TYPE == driverES_PCBA
    f_igbtTemp_Cal();
    powerCal();
    f_preRelayCtrl();
    f_udcAdjust_k();
    speedRamp();
    f_faultCheck();
#elif PCBA_TYPE == driverC250_PCBA
    f_igbtTemp_Cal();
    powerCal();
    f_udcAdjust_k();
    adi_Ctrl();
    process_gear();
    f_faultCheck();
    speedRamp();
#endif
}

void ms20_task(void)
{
#if PCBA_TYPE == driverC250_PCBA
    //adi_Ctrl();
    Ai7Calc();//�ߵ�ѹ��ͨ�˲�
    GPIO_togglePin(Relay3_IO);//����ι��
#elif PCBA_TYPE == driverES_PCBA
    PulseInCalc();
    outPwm();
    adi_Ctrl();
    Ai7Calc();//�ߵ�ѹ��ͨ�˲�
#elif PCBA_TYPE==control_PCBA
    DiStatus();
    Ai1Calc();
    Ai2Calc();
    Ai3Calc();
    Ai4Calc();
    relay_ctrl();
    Lin_Deal();
#endif
}

void ms50_task(void)
{

    //GPIO_togglePin(Relay3_IO);//����ι��

}

//�ٶȻ�Ĭ��Ϊ�ж����ڵ�10��ʱ�䣨8K����Ƶ�ʣ��ٶȻ�1.25ms�����������㼰����ֵ��ҪԶԶ���ڴ�ֵ
void ms100_task(void)
{
#if PCBA_TYPE==driverES_PCBA
    QH_pump_Cal();
    process_gear();
    Ai6Calc();//���ʵ�ͨ�˲�
#elif PCBA_TYPE == driverC250_PCBA
    //process_gear();
    Ai6Calc();//���ʵ�ͨ�˲�
    //GPIO_togglePin(Relay3_IO);//����ι��
#endif
}

#endif /* SRC_APP_TIMERTASK_C_ */

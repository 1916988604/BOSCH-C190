
//��ʾ�壨����������ư壨�ӻ�����ͨѶ
//����C_RS485Comm�߼�


#ifndef SRC_APP_COM_DANDC_C_
#define SRC_APP_COM_DANDC_C_

#define     test_sendFlg_DtoC    1       //0:������ 1:�ӻ�
#define     sci_numeber_DtoC      0       //0:scia�� 1:scib; 2:scic��  48pinֻ��0��2


#include "app_include.h"

extern const unsigned int dspBaudRegData[13][3];
volatile struct SCI_REGS *SciDtoCRegs;

enum COMM_STATUS commStatusDtoC;

// MODBUSЭ��
#define RTUslaveAddressDtoC rcvFrameDtoC[0]      // RTU֡�Ĵӻ���ַ
#define RTUcmdDtoC          rcvFrameDtoC[1]      // RTU֡��������
#define RTUhighAddrDtoC     rcvFrameDtoC[2]      // RTU֡�ĵ�ַ���ֽ�
#define RTUlowAddrDtoC      rcvFrameDtoC[3]      // RTU֡�ĵ�ַ���ֽ�
#define RTUhighDataDtoC     rcvFrameDtoC[4]      // RTU֡�����ݸ��ֽ�
#define RTUlowDataDtoC      rcvFrameDtoC[5]      // RTU֡�����ݵ��ֽ�
#define RTUlowCrcDtoC       rcvFrameDtoC[6]      // RTU֡��CRCУ����ֽ�
#define RTUhighCrcDtoC      rcvFrameDtoC[7]      // RTU֡��CRCУ����ֽ�


void f_rs485_DtoC_ComInit()
{
    Uint16 i;

    baudrateDtoC = 5;       //9600bit/s
    for(i=0;i<RTU_WRITE_DATANUM_DtoC;i++){
        rcvFrameMoreDtoC[i] = 0;
    }

#if sci_numeber_DtoC==0
    SciDtoCRegs = &SciaRegs;
#elif sci_numeber_DtoC==1
    SciDtoCRegs = &ScibRegs;
#else
    SciDtoCRegs = &ScicRegs;
#endif

    EALLOW;
    SciDtoCRegs->SCICTL1.all = 0;       //SCIϵͳ��λʱ,�ָ���ʼ״̬

    SciDtoCRegs->SCICCR.all = 0x0007;   // 1ֹͣλ������żУ��λ����LOOPBACKģʽ��idleѡ��8λ�ַ�
    SciDtoCRegs->SCIPRI.bit.FREESOFT = 1;       //����������ʱ��SCI��������
    SciDtoCRegs->SCIHBAUD.all = dspBaudRegData[baudrateDtoC][1];//2;   //50000000/((0x28a+1)*8) = 50000000/((650+1)*8) = 50000000/5208 = 9600
    SciDtoCRegs->SCILBAUD.all = dspBaudRegData[baudrateDtoC][2];//0x8A;

#if   test_sendFlg_DtoC==0
    //SCI����Ϊ����ģʽ
    SET_RTS_T_DtoC;
    SciDtoCRegs->SCICTL1.all = 0x0022;  // ����
    SciDtoCRegs->SCICTL2.all = 0x00C1;  // ���������ж�
#else
    SET_RTS_R_DtoC;
    SciDtoCRegs->SCICTL1.all = 0x0021;  // ����
    SciDtoCRegs->SCICTL2.all = 0x0002;  // ���������ж�
#endif


#if    MCU_PAKAGE==0    //48pin
    #if sci_numeber_DtoC==0     //scia��������
        GpioCtrlRegs.GPAPUD.bit.GPIO28 = 0;
        GpioCtrlRegs.GPAPUD.bit.GPIO29 = 0;
        GpioCtrlRegs.GPAQSEL2.bit.GPIO28 = 0;
        GpioCtrlRegs.GPAQSEL2.bit.GPIO29 = 0;
        GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 1;
        GpioCtrlRegs.GPAMUX2.bit.GPIO29 = 1;
        GpioCtrlRegs.GPAGMUX2.bit.GPIO28 = 0;
        GpioCtrlRegs.GPAGMUX2.bit.GPIO29 = 0;

        // ͨѶ����ʹ���жϣ���ʼ��
        PieVectTable.SCIA_TX_INT =  &SCI_DtoC_TXD_isr;
        PieVectTable.SCIA_RX_INT =  &SCI_DtoC_RXD_isr;

        PieCtrlRegs.PIEIER9.bit.INTx1 = 1;
        PieCtrlRegs.PIEIER9.bit.INTx2 = 1;
        IER |= M_INT9;                  //  Enable interrupts:
    #else
        //Scic,���ư�
        GpioCtrlRegs.GPHPUD.bit.GPIO224 = 0;
        GpioCtrlRegs.GPHPUD.bit.GPIO226 = 0;
        GpioCtrlRegs.GPHQSEL1.bit.GPIO224 = 0;
        GpioCtrlRegs.GPHQSEL1.bit.GPIO226 = 0;
        GpioCtrlRegs.GPHMUX1.bit.GPIO224 = 2;    //SCITXA
        GpioCtrlRegs.GPHMUX1.bit.GPIO226 = 2;    //SCIRXA
        GpioCtrlRegs.GPHGMUX1.bit.GPIO224 = 3;
        GpioCtrlRegs.GPHGMUX1.bit.GPIO226 = 3;

        PieVectTable.SCIC_TX_INT =  &SCI_DtoC_TXD_isr;
        PieVectTable.SCIC_RX_INT =  &SCI_DtoC_RXD_isr;

        IER |= M_INT8;                  //  Enable interrupts:
        PieCtrlRegs.PIEIER8.bit.INTx5 = 1;
        PieCtrlRegs.PIEIER8.bit.INTx6 = 1;
    #endif
#else   //80PIN
    #if sci_numeber_DtoC==0 //scia
        GpioCtrlRegs.GPAPUD.bit.GPIO16 = 0;
        GpioCtrlRegs.GPAPUD.bit.GPIO17 = 0;
        GpioCtrlRegs.GPAQSEL2.bit.GPIO16 = 0;
        GpioCtrlRegs.GPAQSEL2.bit.GPIO17 = 0;
        GpioCtrlRegs.GPAMUX2.bit.GPIO16 = 2;
        GpioCtrlRegs.GPAMUX2.bit.GPIO17 = 2;
        GpioCtrlRegs.GPAGMUX2.bit.GPIO16 = 1;
        GpioCtrlRegs.GPAGMUX2.bit.GPIO17 = 1;

        // ͨѶ����ʹ���жϣ���ʼ��
        PieVectTable.SCIA_TX_INT =  &SCI_DtoC_TXD_isr;
        PieVectTable.SCIA_RX_INT =  &SCI_DtoC_RXD_isr;

        PieCtrlRegs.PIEIER9.bit.INTx1 = 1;
        PieCtrlRegs.PIEIER9.bit.INTx2 = 1;
        IER |= M_INT9;                  //  Enable interrupts:
    #elif sci_numeber_DtoC==1
        //Scib
        GpioCtrlRegs.GPADIR.bit.GPIO14 = 1;
        GpioCtrlRegs.GPADIR.bit.GPIO15 = 0;
        GpioCtrlRegs.GPAPUD.bit.GPIO14 = 0;
        GpioCtrlRegs.GPAPUD.bit.GPIO15 = 0;
        GpioCtrlRegs.GPAQSEL1.bit.GPIO14 = 0;
        GpioCtrlRegs.GPAQSEL1.bit.GPIO15 = 0;
        GpioCtrlRegs.GPAMUX1.bit.GPIO14 = 2;    //SCITXA
        GpioCtrlRegs.GPAMUX1.bit.GPIO15 = 2;    //SCIRXA
        GpioCtrlRegs.GPAGMUX1.bit.GPIO14 = 0;
        GpioCtrlRegs.GPAGMUX1.bit.GPIO15 = 0;

        PieVectTable.SCIB_TX_INT =  &SCI_DtoC_TXD_isr;
        PieVectTable.SCIB_RX_INT =  &SCI_DtoC_RXD_isr;

        PieCtrlRegs.PIEIER9.bit.INTx3 = 1;
        PieCtrlRegs.PIEIER9.bit.INTx4 = 1;
        IER |= M_INT9;                  //  Enable interrupts:
    #else
        //Scic
        GpioCtrlRegs.GPBPUD.bit.GPIO42 = 0;
        GpioCtrlRegs.GPBPUD.bit.GPIO43 = 0;
        GpioCtrlRegs.GPBQSEL1.bit.GPIO42 = 0;
        GpioCtrlRegs.GPBQSEL1.bit.GPIO43 = 0;
        GpioCtrlRegs.GPBMUX1.bit.GPIO42 = 3;    //SCITXA
        GpioCtrlRegs.GPBMUX1.bit.GPIO43 = 3;    //SCIRXA
        GpioCtrlRegs.GPBGMUX1.bit.GPIO42 = 1;
        GpioCtrlRegs.GPBGMUX1.bit.GPIO43 = 1;

        PieVectTable.SCIC_TX_INT =  &SCI_DtoC_TXD_isr;
        PieVectTable.SCIC_RX_INT =  &SCI_DtoC_RXD_isr;

        IER |= M_INT8;                  //  Enable interrupts:
        PieCtrlRegs.PIEIER8.bit.INTx5 = 1;
        PieCtrlRegs.PIEIER8.bit.INTx6 = 1;
    #endif
#endif


    EDIS;
    commRcvDataDtoC.rcvFlag = 0;
    commRcvDataDtoC.rcvNum = 0;
    commRcvDataDtoC.slaveAddr = 0;
    commRcvDataDtoC.slaveDddr = 0;
    commRcvDataDtoC.commAddr = 0;
    commRcvDataDtoC.commCmd = 0;
    commRcvDataDtoC.rcvDataJuageFlag = 0;
    commRcvDataDtoC.moreWriteNum = 0;
    commRcvDataDtoC.rcvNumMax = 8;      // ��ʼ�����ճ��ȣ�ʵ�ʳ������ж��ж�
    commRcvDataDtoC.frameSpaceTime = (Uint16)(385.0*2.0/dspBaudRegData[baudrateDtoC][0])+1;   // 3.5 char time=3.5*(1+8+2)/baud
    //commRcvDataDtoC.frameSpaceTime = 385 * 2 / 96+ 1;        // 3.5 char time=3.5*(1+8+2)/baud
#if   test_sendFlg_DtoC==0
    commRcvDataDtoC.delay = 120;      //60ms
    commStatusDtoC = SCI_SEND_DATA_PREPARE;        // ��Ϊ����״̬
#else
    commRcvDataDtoC.delay = 2;      //1ms
    commStatusDtoC = SCI_RECEIVE_DATA;        // ��Ϊ����״̬
#endif
}

//*****************************����**************************************************/
void CommReadBackDtoC(void)
{
    //����ʱ��0x03�������ݽ���
    sci_motor_spd     = (int16)rcvFrameMoreDtoC[0];     //--0x5000
    sci_motor_udcVol  = rcvFrameMoreDtoC[1];
    sci_motor_gridVol = rcvFrameMoreDtoC[2];
    sci_motor_igbtT   = (int16)rcvFrameMoreDtoC[3];
    sci_motor_fault   = rcvFrameMoreDtoC[4];
    sci_motor_runFlg  = rcvFrameMoreDtoC[5] & 0x03;
    sci_motor_pwrLmtFlg  = (rcvFrameMoreDtoC[5] >> 2)& 0x01;
    sci_motor_gear   = (rcvFrameMoreDtoC[5] >> 7)& 0x01F;
    sci_motor_flow   = rcvFrameMoreDtoC[6];
    sci_motor_lift   = rcvFrameMoreDtoC[7];
    sci_motor_power  = rcvFrameMoreDtoC[8];
    //sci_motor_Hauto = rcvFrameMoreDtoC[9];
    sci_motor_Hmax = rcvFrameMoreDtoC[10];
    sci_motor_Hmin = rcvFrameMoreDtoC[11];
    sci_motor_CHmax = rcvFrameMoreDtoC[12];
    sci_motor_CHmin = rcvFrameMoreDtoC[13];
    sci_motor_softVer = rcvFrameMoreDtoC[14];
    sci_motor_hardVer = rcvFrameMoreDtoC[15];
    sci_motor_bootVer = rcvFrameMoreDtoC[16];

    motor_runFlg_sci = 0;
    motor_err_sci = 0;
    motor_readyFlg_sci = 0;
    motor_warnFlg_sci = 0;
    if(sci_motor_runFlg == 3){
        motor_err_sci = 1;
    }else if(sci_motor_runFlg == 1){
        motor_runFlg_sci = 1;
    }else if(sci_motor_runFlg == 0){
        motor_readyFlg_sci = 1;
    }else{
        motor_warnFlg_sci = 1;
    }
}

void CommWriteDtoC(void)
{
    Uint16 temp;
    //����ʱ��0x10�������ݴ��
    sysSci_mode.errRstEn = sys_param.errRstEn;
    sysSci_mode.liquidLimtEn = sys_param.liquidLimtEn;
    sysSci_mode.liquidLimtMax = sys_param.liquidLimtMax;
    sysSci_mode.headSensor = sys_param.headSensor;
    sysSci_mode.headValid = sys_param.headValid;
    sysSci_mode.varInit = sys_param.varInit;

    temp = u_enable_exsci + (sysSci_mode.errRstEn<<1) + (sysSci_mode.liquidLimtEn<<2) + (sysSci_mode.headValid<<3) + \
            (sysSci_mode.mode<<8) + (sysSci_mode.varInit<<15);       //0x4000
    sendFrameDtoC[7] = temp>>8;
    sendFrameDtoC[8] = temp&0x0ff;
    temp = u_speed_exsci;        //0x4000
    sendFrameDtoC[9] = temp>>8;
    sendFrameDtoC[10] = temp&0x0ff;
    temp = sysSci_mode.liquidLimtMax;
    sendFrameDtoC[11] = temp>>8;
    sendFrameDtoC[12] = temp&0x0ff;
    temp = sysSci_mode.headSensor;
    sendFrameDtoC[13] = temp>>8;
    sendFrameDtoC[14] = temp&0x0ff;
    temp = 0x30;
    sendFrameDtoC[15] = temp>>8;
    sendFrameDtoC[16] = temp&0x0ff;
    temp = 0x40;
    sendFrameDtoC[17] = temp>>8;
    sendFrameDtoC[18] = temp&0x0ff;
    temp = 0x50;
    sendFrameDtoC[19] = temp>>8;
    sendFrameDtoC[20] = temp&0x0ff;
    temp = 0x60;
    sendFrameDtoC[21] = temp>>8;
    sendFrameDtoC[22] = temp&0x0ff;
    temp = 0x70;
    sendFrameDtoC[23] = temp>>8;
    sendFrameDtoC[24] = temp&0x0ff;
    temp = 0x80;
    sendFrameDtoC[25] = temp>>8;
    sendFrameDtoC[26] = temp&0x0ff;
    temp = 0x90;
    sendFrameDtoC[27] = temp>>8;
    sendFrameDtoC[28] = temp&0x0ff;
    temp = 0x91;
    sendFrameDtoC[29] = temp>>8;
    sendFrameDtoC[30] = temp&0x0ff;
    temp = 0x92;
    sendFrameDtoC[31] = temp>>8;
    sendFrameDtoC[32] = temp&0x0ff;
    temp = 0x93;
    sendFrameDtoC[33] = temp>>8;
    sendFrameDtoC[34] = temp&0x0ff;
    temp = 0x94;
    sendFrameDtoC[35] = temp>>8;
    sendFrameDtoC[36] = temp&0x0ff;
    temp = 0x95;
    sendFrameDtoC[37] = temp>>8;
    sendFrameDtoC[38] = temp&0x0ff;
    temp = 0x96;
    sendFrameDtoC[39] = temp>>8;
    sendFrameDtoC[40] = temp&0x0ff;
    temp = 0x97;
    sendFrameDtoC[41] = temp>>8;
    sendFrameDtoC[42] = temp&0x0ff;
    temp = 0x98;
    sendFrameDtoC[43] = temp>>8;
    sendFrameDtoC[44] = temp&0x0ff;
    temp = 0x99;
    sendFrameDtoC[45] = temp>>8;
    sendFrameDtoC[46] = temp&0x0ff;
    temp = 0x9a;
    sendFrameDtoC[47] = temp>>8;
    sendFrameDtoC[48] = temp&0x0ff;
    temp = 0x9b;
    sendFrameDtoC[49] = temp>>8;
    sendFrameDtoC[50] = temp&0x0ff;
    temp = 0x9c;
    sendFrameDtoC[51] = temp>>8;
    sendFrameDtoC[52] = temp&0x0ff;
    temp = 0x9d;
    sendFrameDtoC[53] = temp>>8;
    sendFrameDtoC[54] = temp&0x0ff;
    temp = 0x9e;
    sendFrameDtoC[55] = temp>>8;
    sendFrameDtoC[56] = temp&0x0ff;
    temp = 0x9f;
    sendFrameDtoC[57] = temp>>8;
    sendFrameDtoC[58] = temp&0x0ff;
    temp = 0xa0;
    sendFrameDtoC[59] = temp>>8;
    sendFrameDtoC[60] = temp&0x0ff;
    temp = 0xa1;
    sendFrameDtoC[61] = temp>>8;
    sendFrameDtoC[62] = temp&0x0ff;
    temp = 0xa2;
    sendFrameDtoC[63] = temp>>8;
    sendFrameDtoC[64] = temp&0x0ff;
    temp = 0xa3;
    sendFrameDtoC[65] = temp>>8;
    sendFrameDtoC[66] = temp&0x0ff;
    temp = 0xa4;
    sendFrameDtoC[67] = temp>>8;
    sendFrameDtoC[68] = temp&0x0ff;
}


//*****************************�ӻ�**************************************************/
//�ӻ�����������������
void CommWriteBackDtoC(void)
{
    u_enable_HandC = rcvFrameMoreDtoC[0] & 0x01;
    sys_param.errRstEn = (rcvFrameMoreDtoC[0]>>1) & 0x01;
    sys_param.liquidLimtEn = (rcvFrameMoreDtoC[0]>>2) & 0x01;
    sys_param.headValid = (rcvFrameMoreDtoC[0]>>3) & 0x01;
    sys_param.mode = (rcvFrameMoreDtoC[0]>>8) & 0x01F;
    sys_param.varInit = (rcvFrameMoreDtoC[0]>>15) & 0x01;
    u_speed_HandC = rcvFrameMoreDtoC[1];
    sys_param.liquidLimtMax = rcvFrameMoreDtoC[2];
    sys_param.headSensor = rcvFrameMoreDtoC[3];
}

//�ӻ������͸�����������
void CommReadDtoC(void)
{
    Uint16  u_temp;

    //�ӻ�ʱ��0x03�������ݴ��
    commReadDataDtoC[0]=(Uint16)(motorVars_M1.speed_int_Hz*0.016666 * USER_MOTOR1_NUM_POLE_PAIRS);      //0x5000
    commReadDataDtoC[1]=(Uint16)(motorVars_M1.adcData.VdcBus_V);      //0x5001
    commReadDataDtoC[2]=(Uint16)(motorVars_M1.adcData.VdcBus_V);
    commReadDataDtoC[3]=(int16)(Temp_IGBT.igbtTemp*10);
    commReadDataDtoC[4]=u_fault_sta.all;

    if(u_fault_sta.all != 0){
        if(motorVars_M1.flagEnableRunAndIdentify==1){
            u_temp = 3;
        }else{
            u_temp = 2;
        }
    }else if(motorVars_M1.flagEnableRunAndIdentify==1){
        u_temp = 1;
    }else if(motorVars_M1.flagEnableRunAndIdentify==0){
        u_temp = 0;
    }
    commReadDataDtoC[5]= u_temp + (sysSci_mode.mode<<7);
    commReadDataDtoC[6]=(Uint16)(var_QH_cal.Q_pump*10);
    commReadDataDtoC[7]=(Uint16)(var_QH_cal.H_pump*10);
    commReadDataDtoC[8]=(Uint16)(outpower*10);
    commReadDataDtoC[9]=sci_motor_Hauto;
    commReadDataDtoC[10]=BL_HEAD_MAX;
    commReadDataDtoC[11]=BL_HEAD_MIN;
    commReadDataDtoC[12]=HD_HEAD_MAX;
    commReadDataDtoC[13]=HD_HEAD_MIN;
    commReadDataDtoC[14]=SW_VER_NUMBER;
    commReadDataDtoC[15]=HW_VER_NUMBER;
    commReadDataDtoC[16]=boot_ver;
    commReadDataDtoC[17]=0;
    commReadDataDtoC[18]=6;
    commReadDataDtoC[19]=7;
    commReadDataDtoC[20]=8;
    commReadDataDtoC[21]=9;
    commReadDataDtoC[22]=0;
    commReadDataDtoC[23]=0;
    commReadDataDtoC[24]=0;
    commReadDataDtoC[25]=0;
    commReadDataDtoC[26]=0;
    commReadDataDtoC[27]=0;
    commReadDataDtoC[28]=28;
    commReadDataDtoC[29]=0;
    commReadDataDtoC[30]=0;
    commReadDataDtoC[31]=0;
    commReadDataDtoC[32]=0;
    commReadDataDtoC[33]=33;
    commReadDataDtoC[34]=0;
    commReadDataDtoC[35]=0;
    commReadDataDtoC[36]=0;
    commReadDataDtoC[37]=0;
    commReadDataDtoC[38]=38;
    commReadDataDtoC[39]=39;
}


//====================================================================
// ���ݽ��պ���Ϣ����
//====================================================================
void ModbusRcvDataDealDtoC(void)
{
#if    test_sendFlg_DtoC==0
    if(RTUcmdDtoC == SCI_CMD_READ)
#else
        if(RTUcmdDtoC == SCI_CMD_WRITE_MORE)
#endif
    {
#if    test_sendFlg_DtoC==0
            commRcvDataDtoC.slaveAddr = RTUslaveAddressDtoC;                // �ӻ���ַ
            commRcvDataDtoC.commCmd = RTUcmdDtoC;                           // ͨѶ����
            commRcvDataDtoC.commAddr = RTU_READ_ADDRESS_DtoC; // ������ַ
            commRcvDataDtoC.commData = rcvFrameDtoC[2] ; // ��������
            commRcvDataDtoC.crcRcv = (rcvFrameDtoC[commRcvDataDtoC.commData+4] <<8)+rcvFrameDtoC[commRcvDataDtoC.commData+3]; // ��������;     // CRCУ��ֵ
            commRcvDataDtoC.crcSize = commRcvDataDtoC.commData + 3;                                // CRCУ�鳤��
            commRcvDataDtoC.commCmdSaveEeprom = SCI_WRITE_WITH_EEPROM;  // �洢EEPROM����

#else
        commRcvDataDtoC.slaveAddr = RTUslaveAddressDtoC;                // �ӻ���ַ
        commRcvDataDtoC.commCmd = RTUcmdDtoC;                           // ͨѶ����
        commRcvDataDtoC.commAddr = (RTUhighAddrDtoC << 8) + RTUlowAddrDtoC; // ������ʼ��ַ
        commRcvDataDtoC.commData = (RTUhighDataDtoC << 8) + RTUlowDataDtoC; // �����Ĵ���������

        commRcvDataDtoC.moreWriteNum = rcvFrameDtoC[6];                 // �ֽ���

        commRcvDataDtoC.crcSize = commRcvDataDtoC.moreWriteNum + 7; // CRCУ�鳤��
        commRcvDataDtoC.crcRcv = (rcvFrameDtoC[commRcvDataDtoC.crcSize+1] << 8) + rcvFrameDtoC[commRcvDataDtoC.crcSize];     // CRCУ��ֵ
        commRcvDataDtoC.commCmdSaveEeprom = SCI_WRITE_WITH_EEPROM;  // �洢EEPROM����
#endif
    }
    else
    {
        commRcvDataDtoC.slaveAddr = RTUslaveAddressDtoC;                // �ӻ���ַ
        commRcvDataDtoC.commCmd = RTUcmdDtoC;                           // ͨѶ����
        commRcvDataDtoC.commAddr = (RTUhighAddrDtoC << 8) + RTUlowAddrDtoC; // ������ַ
        commRcvDataDtoC.commData = (RTUhighDataDtoC << 8) + RTUlowDataDtoC; // ��������
        commRcvDataDtoC.crcRcv = (RTUhighCrcDtoC << 8) + RTUlowCrcDtoC;     // CRCУ��ֵ
        commRcvDataDtoC.crcSize = 6;                                // CRCУ�鳤��
        commRcvDataDtoC.commCmdSaveEeprom = SCI_WRITE_WITH_EEPROM;  // �洢EEPROM����
    }
}

//=====================================================================
// ͨѶ���յ����ݴ�������
//=====================================================================
void CommRcvDataDealDtoC(void)
{
    Uint16 writeErr=0,readErr=0;
    Uint16 i,j;
    long u32_temp;
    Uint16 comCrcDtoC=0;

    // ��ͬЭ��Ľ���������Ϣ����
    // �������������ַ�����ݵ���Ϣ
    ModbusRcvDataDealDtoC();
    // ��SCI��־
    sciFlagDtoC.all = 0;

    comCrcDtoC = CrcValueByteCalc(rcvFrameDtoC, commRcvDataDtoC.crcSize);
    // CRCУ��
    if (commRcvDataDtoC.crcRcv != comCrcDtoC)  // CRCУ������ж�
    {
        sciFlagDtoC.bit.crcChkErr = 1;                      // ��λ��CRCErr��send
        commRcvDataDtoC.rcvCrcErrCounter++;                 // ��¼CRCУ���������
    }
     // �㲥ģʽ
    else if (!commRcvDataDtoC.slaveAddr)
    {
        // �㲥д����
        if ((SCI_CMD_WRITE == commRcvDataDtoC.commCmd)
          || (SCI_CMD_WRITE_MORE == commRcvDataDtoC.commCmd)
           )
        {
            // ��д��־
            sciFlagDtoC.bit.write = 1;
        }
        else
        {
            sciFlagDtoC.bit.cmdErr = 1;                                                 // �������
        }
    }
    else if (commRcvDataDtoC.slaveAddr == SCI_SLAVE_ADDRESS_DtoC) // ������ַ�ж�
    {
        if (SCI_CMD_READ == commRcvDataDtoC.commCmd)       // ���������
        {
            sciFlagDtoC.bit.read = 1;                           // ��λ��read��send
        }
        else if ((SCI_CMD_WRITE == commRcvDataDtoC.commCmd)
                || (SCI_CMD_WRITE_MORE == commRcvDataDtoC.commCmd))      // д�������
        {
            sciFlagDtoC.bit.write = 1;
        }
        else
        {
            sciFlagDtoC.bit.cmdErr = 1;                                                 // �������
        }
    }

#if    test_sendFlg_DtoC==0  //��������
    if (sciFlagDtoC.bit.read){
        if(commRcvDataDtoC.commData > (RTU_READ_DATANUM_DtoC*2)){
            readErr = COMM_ERR_ADDR;
        }else{
            j =0;
            for(i=0;i<(commRcvDataDtoC.commData>>1);i++)
            {
                rcvFrameMoreDtoC[j] = (rcvFrameDtoC[3+i*2]<<8) + rcvFrameDtoC[4+i*2];       //������ȡ�ӻ����͵�����
                j++;
            }
            CommReadBackDtoC();
        }

        if (readErr){
            sciFlagDtoC.bit.paraOver = 1;
        }
    }

    if (sciFlagDtoC.bit.write){
        if(commRcvDataDtoC.commData != RTU_WRITE_DATANUM_DtoC){
            writeErr = COMM_ERR_ADDR;
        }else if(commRcvDataDtoC.commAddr != RTU_WRITE_ADDRESS_DtoC){
            writeErr = COMM_ERR_ADDR;
        }

        if (writeErr){
           sciFlagDtoC.bit.paraOver = 1;
        }
    }

#endif
#if    test_sendFlg_DtoC==1  //�ӻ�����
    if (sciFlagDtoC.bit.read)
    {
        u32_temp = commRcvDataDtoC.commAddr + commRcvDataDtoC.commData-1;
        if(commRcvDataDtoC.commData > RTU_READ_DATANUM_DtoC){
            readErr = COMM_ERR_ADDR;
        }else if(commRcvDataDtoC.commAddr < RTU_READ_ADDRESS_DtoC){
            readErr = COMM_ERR_ADDR;
        }else if(u32_temp>(RTU_READ_ADDRESS_DtoC+RTU_READ_DATANUM_DtoC-1)){
            readErr = COMM_ERR_ADDR;
        }else{
            CommReadDtoC();
        }
        if (readErr){
            sciFlagDtoC.bit.paraOver = 1;
        }
    }
    // д���ݴ���
    if (sciFlagDtoC.bit.write)
    {
        if(SCI_CMD_WRITE_MORE == commRcvDataDtoC.commCmd)
        {
            u32_temp = commRcvDataDtoC.commAddr + commRcvDataDtoC.commData-1;
            if(((commRcvDataDtoC.commData*2) != commRcvDataDtoC.moreWriteNum)
                ||(commRcvDataDtoC.commData > RTU_WRITE_DATANUM_DtoC))
            {
                writeErr = COMM_ERR_ADDR;
            }else if(commRcvDataDtoC.commAddr < RTU_WRITE_ADDRESS_DtoC){
                writeErr = COMM_ERR_ADDR;
            }else if(u32_temp > (RTU_WRITE_ADDRESS_DtoC + RTU_WRITE_DATANUM_DtoC - 1) ){
                writeErr = COMM_ERR_ADDR;
            }
            else
            {
                j = commRcvDataDtoC.commAddr;
                j = j - RTU_WRITE_ADDRESS_DtoC;
                if(j > (RTU_WRITE_DATANUM_DtoC - 1)){
                    writeErr = COMM_ERR_ADDR;
                }else{
                    for(i=0;i<commRcvDataDtoC.moreWriteNum;i++)
                    {
                        rcvFrameMoreDtoC[j] = (rcvFrameDtoC[7+i]<<8) + rcvFrameDtoC[8+i];
                        i++;
                        j++;
                    }
                    CommWriteBackDtoC();
                }
            }
        }
        else
        {
            writeErr = COMM_ERR_ADDR;
        }
        // дʧ��
        if (writeErr)
        {
            // ��ʾдʧ�ܹ���
            sciFlagDtoC.bit.paraOver = 1;
        }
    }
#endif
}


interrupt void SCI_DtoC_RXD_isr(void)
{
    // ���ݽ���֡ͷ�ж�
    Uint16 tmp;
    Uint16 tmp1;
    tmp = SciDtoCRegs->SCIRXBUF.all;
    tmp1 = ModbusStartDealDtoC(tmp);
    if (tmp1)
    {
        // Ϊ�����Ľ�������  0-��Ч   1-�㲥��ַ    2-������ַ
        if (commRcvDataDtoC.rcvFlag)
        {
            // ��֡ͷͨѶ���ݽ���
            CommDataReRcvDtoC(tmp);
        }
    }

    commTickerDtoC = 0;                     // �н������ݣ����¼�ʱ
#if sci_numeber_DtoC==2
    PieCtrlRegs.PIEACK.bit.ACK8 = 1;    // Issue PIE ACK
#else
    PieCtrlRegs.PIEACK.bit.ACK9 = 1;    // Issue PIE ACK
#endif
}

interrupt void SCI_DtoC_TXD_isr(void)
{
    // ͨѶ��������
     // ����һ֡����û�����
   if (commSendDataDtoC.sendNum< commSendDataDtoC.sendNumMax)
   {
       SciDtoCRegs->SCITXBUF.all = sendFrameDtoC[commSendDataDtoC.sendNum++];
   }
    // ����һ֡����ȫ�����
   else if (commSendDataDtoC.sendNum >= commSendDataDtoC.sendNumMax)
   {
        // ��־�����������
       commStatusDtoC = SCI_SEND_OK;
   }
   commTickerDtoC = 0;                     // ����һ���ַ���ɣ����¼�ʱ
#if sci_numeber_DtoC==2
    PieCtrlRegs.PIEACK.bit.ACK8 = 1;    // Issue PIE ACK
#else
    PieCtrlRegs.PIEACK.bit.ACK9 = 1;    // Issue PIE ACK
#endif
}

//====================================================================
// MODBUS֡ͷ�ж�
// ����: tmp-����֡����
// ����: 0-֡ͷ�жϹ�����
//       1-����Ҫ֡ͷ�жϣ�ֱ�Ӵ洢��������
//===================================================================
Uint16 ModbusStartDealDtoC(Uint16 tmp)
{
    if (commTickerDtoC >= 4000)                                     // 2sʱ��
    {
        commRcvDataDtoC.rcvDataJuageFlag = 0;                       // ��ʱ��û�����꣬֡ͷ�жϸ�λ
    }

    if ((commTickerDtoC > commRcvDataDtoC.frameSpaceTime))              // ����3.5���ַ�ʱ�䣬�µ�һ֡�Ŀ�ʼ
    {
        RTUslaveAddressDtoC = tmp;
        // �㲥ģʽ
        if (RTUslaveAddressDtoC == 0)
        {
            commRcvDataDtoC.rcvNum = 1;
            commRcvDataDtoC.rcvFlag = 1;                           // ���յ�֡�ĵ�һ���ֽڣ����ǹ㲥ģʽ
        }
        else if (RTUslaveAddressDtoC == SCI_SLAVE_ADDRESS_DtoC)
        {
            commRcvDataDtoC.rcvNum = 1;
            commRcvDataDtoC.rcvFlag = 2;
        }
        else                                                   // ������ַ
        {
            commRcvDataDtoC.rcvFlag = 0;                        // ��ַ����Ӧ�����ݲ�����
        }

        return 0;
    }

    return 1;
}

void CommDataReRcvDtoC(Uint16 tmp)
{
    if (commRcvDataDtoC.rcvNum < commRcvDataDtoC.rcvNumMax)  // ����һ֡���ݻ�û�����
    {
        rcvFrameDtoC[commRcvDataDtoC.rcvNum] = tmp;
    }
    commRcvDataDtoC.rcvNum++;

    if((rcvFrameDtoC[1] ==SCI_CMD_READ)
        ||(rcvFrameDtoC[1] ==SCI_CMD_WRITE)
        ||(rcvFrameDtoC[1] ==SCI_CMD_WRITE_MORE))
    {
        commRcvDataDtoC.dpOrModbus = 2; //  2:modbus
        commRcvDataDtoC.rcvNumMax = 8;
        // 01 10 f0 08 00 02 04
#if   test_sendFlg_DtoC==0
        //����
        //01 03 04 00 00 00 00 CRCL CRCH
        if((rcvFrameDtoC[1] ==SCI_CMD_READ)&&(commRcvDataDtoC.rcvNum>=8))
        {
            commRcvDataDtoC.rcvNumMax = rcvFrameDtoC[2] + 5;
        }
#else
        //�ӻ�
        if((rcvFrameDtoC[1] ==SCI_CMD_WRITE_MORE)&&(commRcvDataDtoC.rcvNum>=8))
        {
            commRcvDataDtoC.rcvNumMax = rcvFrameDtoC[6] + 9;
        }
#endif
    }
    if (commRcvDataDtoC.rcvNum == commRcvDataDtoC.rcvNumMax)  //���ո�������
    {
        commStatusDtoC = SCI_RCVFIN_WAIT;   //��־���ս����ȴ�
    }
}


void CommSendDataDealDtoC(void)
{
#if   test_sendFlg_DtoC==1
    Uint16 sendNum;
    Uint16 crcSend;
    Uint16 j,i;
    Uint16 readDataStartIndex;

    sendFrameDtoC[0] = rcvFrameDtoC[0];
    sendFrameDtoC[1] = rcvFrameDtoC[1];
    commSendDataDtoC.sendNumMax = 8;  // �������ݳ���

    if(sciFlagDtoC.bit.cmdErr==1){
        sendFrameDtoC[1] =  rcvFrameDtoC[1] + 0x80;
        sendFrameDtoC[2] =  0x01;
        commSendDataDtoC.sendNumMax = 5;  // �������ݳ���
    }else if(sciFlagDtoC.bit.paraOver){
        sendFrameDtoC[1] =  rcvFrameDtoC[1] + 0x80;
        sendFrameDtoC[2] =  0x02;
        commSendDataDtoC.sendNumMax = 5;  // �������ݳ���
    }else if(sciFlagDtoC.bit.write==1){
        sendFrameDtoC[2] = RTUhighAddrDtoC;
        sendFrameDtoC[3] = RTUlowAddrDtoC;
        sendFrameDtoC[4] = RTUhighDataDtoC;
        sendFrameDtoC[5] = RTUlowDataDtoC;
    }else if(sciFlagDtoC.bit.read==1){
        sendNum = commRcvDataDtoC.commData << 1;
        sendFrameDtoC[2] = sendNum;
        commSendDataDtoC.sendNumMax = sendNum + 5;
        readDataStartIndex = 3;

        j = commRcvDataDtoC.commAddr;
        j = j - RTU_READ_ADDRESS_DtoC;
        for(i = 0;i<commRcvDataDtoC.commData; i++){
            sendFrameDtoC[(i << 1) + readDataStartIndex] = commReadDataDtoC[i+j] >> 8;
            sendFrameDtoC[(i << 1) + readDataStartIndex + 1] = commReadDataDtoC[i+j] & 0x00ff;
        }
    }

#else
    Uint16 temp;
    static Uint16 wr_cnt_flg_DtoC=0;
    Uint16 crcSend;

    sendFrameDtoC[0] = SCI_SLAVE_ADDRESS_DtoC;
    if((sciFlagDtoC.bit.paraOver==0)&&(sciFlagDtoC.bit.cmdErr==0)&&(sciFlagDtoC.bit.crcChkErr==0)){
        //wr_cnt_flg_DtoC++;
    }
    wr_cnt_flg_DtoC++;
    if (wr_cnt_flg_DtoC==1)             //100
    {
        sendFrameDtoC[1] = 0x03;
        temp = RTU_READ_ADDRESS_DtoC;
        sendFrameDtoC[2] = temp>>8;
        sendFrameDtoC[3] = temp&0x0ff;
        temp = RTU_READ_DATANUM_DtoC;
        sendFrameDtoC[4] = temp>>8;
        sendFrameDtoC[5] = temp&0x0ff;
        commSendDataDtoC.sendNumMax = 8;  // �������ݳ���
    }
    else if (wr_cnt_flg_DtoC==2)
    {
        sendFrameDtoC[1] = 0x10;
        temp = RTU_WRITE_ADDRESS_DtoC;
        sendFrameDtoC[2] = temp>>8;
        sendFrameDtoC[3] = temp&0x0ff;
        temp = RTU_WRITE_DATANUM_DtoC;
        sendFrameDtoC[4] = temp>>8;
        sendFrameDtoC[5] = temp&0x0ff;
        temp = RTU_WRITE_DATANUM_DtoC*2;
        sendFrameDtoC[6] = temp;

        CommWriteDtoC();    //���ݴ��

        wr_cnt_flg_DtoC=0;
        commSendDataDtoC.sendNumMax = RTU_WRITE_DATANUM_DtoC*2+9;  // �������ݳ���
    }
#endif
    // ׼��CRCУ������
    crcSend = CrcValueByteCalc(sendFrameDtoC, commSendDataDtoC.sendNumMax - 2);
    sendFrameDtoC[commSendDataDtoC.sendNumMax - 2] = crcSend & 0x00ff;    // CRC��λ��ǰ
    sendFrameDtoC[commSendDataDtoC.sendNumMax - 1] = crcSend >> 8;
}

//2ms����
void SciDeal_DtoC(void)
{
    if((SciDtoCRegs->SCIRXST.all)&0x80)    // ͨѶ����
    {
        f_rs485_DtoC_ComInit();   // ��ʼ��SCI�Ĵ���
    }else if(commTickerDtoC>4000){
        commTickerDtoC = 0;
#if   test_sendFlg_DtoC==0
        commStatusDtoC = SCI_SEND_DATA_PREPARE;        // ��Ϊ����״̬

        SET_RTS_T_DtoC;
        SciDtoCRegs->SCICTL1.all = 0x0022;  // ����
        SciDtoCRegs->SCICTL2.all = 0x00C1;  // ���������ж�
#else
        commStatusDtoC = SCI_RECEIVE_DATA;        // ��Ϊ����״̬
        SET_RTS_R_DtoC;
        SciDtoCRegs->SCICTL1.all = 0x0021;  // ����
        SciDtoCRegs->SCICTL2.all = 0x0002;  // ���������ж�
#endif
    }else{
        // ͨѶ���̴���
        commStatusDeal_DtoC();
    }
}

void commStatusDeal_DtoC(void)
{
    switch (commStatusDtoC)
    {
        // ��������
        case SCI_RECEIVE_DATA:
#if    test_sendFlg_DtoC==0
            commSendTickerDtoC++;
            if(commSendTickerDtoC>200){
                commStatusDtoC = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
                SET_RTS_T_DtoC;           // RTS��Ϊ����
                SciDtoCRegs->SCICTL1.all = 0x0022;  // ����
                SciDtoCRegs->SCICTL2.all = 0x00C1;  // ���������ж�
            }
#else
            SET_RTS_R_DtoC;  // RTS��Ϊ����
#endif
            break;

        case SCI_RCVFIN_WAIT:
            if (commTickerDtoC < commRcvDataDtoC.frameSpaceTime)  //С��֡���
            {
                if (commRcvDataDtoC.rcvNum > commRcvDataDtoC.rcvNumMax)  //���ո�������
                {
                    commRcvDataDtoC.rcvDataJuageFlag = 0;
                    commRcvDataDtoC.rcvFlag = 0;

                    //�ô���Ϣ֡������, ά�ֽ���״̬

#if    test_sendFlg_DtoC==0
                    commStatusDtoC = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
                    SET_RTS_T_DtoC;           // RTS��Ϊ����
                    SciDtoCRegs->SCICTL1.all = 0x0022;  // ����
                    SciDtoCRegs->SCICTL2.all = 0x00C1;  // ���������ж�
#else
                    commStatusDtoC = SCI_RECEIVE_DATA;
#endif
                }
                break;
            }
            else if (commRcvDataDtoC.rcvNum == commRcvDataDtoC.rcvNumMax)  //δ���յ��µ�����
            {
                commRcvDataDtoC.rcvDataJuageFlag = 0;
                if (commRcvDataDtoC.rcvFlag == 2)  //������ַ�ŷ���
                {
                    SciDtoCRegs->SCICTL1.all = 0x0004;
                    SciDtoCRegs->SCICTL2.all = 0x00C0;
                }
                commRcvDataDtoC.rcvFlag = 0;

                commStatusDtoC = SCI_RECEIVE_OK;   //��־�����������
            }
            else                  //��ֹ�쳣״̬
            {
                commRcvDataDtoC.rcvDataJuageFlag = 0;
                commRcvDataDtoC.rcvFlag = 0;

                //�ô���Ϣ֡������, ά�ֽ���״̬
#if    test_sendFlg_DtoC==0
                commStatusDtoC = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
                SET_RTS_T_DtoC;           // RTS��Ϊ����
                SciDtoCRegs->SCICTL1.all = 0x0022;  // ����
                SciDtoCRegs->SCICTL2.all = 0x00C1;  // ���������ж�
#else
                commStatusDtoC = SCI_RECEIVE_DATA;
#endif
                break;
            }

        case SCI_RECEIVE_OK:
#if    test_sendFlg_DtoC==0
            commSendTickerDtoC++;
            if(commSendTickerDtoC>200){
                    CommRcvDataDealDtoC();
                    commStatusDtoC = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
                    SET_RTS_T_DtoC;           // RTS��Ϊ����
                    SciDtoCRegs->SCICTL1.all = 0x0022;  // ����
                    SciDtoCRegs->SCICTL2.all = 0x00C1;  // ���������ж�
            }
            break;
#else
            CommRcvDataDealDtoC();
            // ��������
            if ((commRcvDataDtoC.slaveAddr)              // �ǹ㲥
            && ((!sciFlagDtoC.bit.crcChkErr)         // CRCУ��ɹ���ΪPROFIBUSЭ��
            ))
            {
                CommSendDataDealDtoC();                 // ��������׼��
                commStatusDtoC = SCI_SEND_DATA_PREPARE; // ���մ�����ɣ�׼������
            }
            else                                    // �㲥��DSP��Ӧ֮�󲻷��ͣ���������
            {
                commStatusDtoC = SCI_RECEIVE_DATA;
                SET_RTS_R_DtoC;  // RTS = RS485_R;       // RTS��Ϊ����
                SciDtoCRegs->SCICTL1.all = 0x0021;  // ����
                SciDtoCRegs->SCICTL2.all = 0x00C2;  // ���������ж�
                break;
             }
#endif
        // ��������׼��
        case SCI_SEND_DATA_PREPARE:
#if    test_sendFlg_DtoC==0
            CommSendDataDealDtoC();                 // ��������׼��
#else
#endif
            if ((commTickerDtoC >= commRcvDataDtoC.delay)               // Ӧ���ӳ�
                && (commTickerDtoC > commRcvDataDtoC.frameSpaceTime))   // MODBUSΪ3.5���ַ�ʱ��
            {
                SET_RTS_T_DtoC;           // RTS��Ϊ����
                SciDtoCRegs->SCICTL1.all = 0x0022;  // ����
                SciDtoCRegs->SCICTL2.all = 0x00C1;  // ���������ж�

                commStatusDtoC = SCI_SEND_DATA;
                commSendDataDtoC.sendNum = 1;               // ��ǰ�������ݸ�����Ϊ1
                SciDtoCRegs->SCITXBUF.all = sendFrameDtoC[0];     // ��ʼ����,���͵�һ������
                commSendTickerDtoC = 0;
            }
            break;

        // ��������
        case SCI_SEND_DATA:
            commSendTickerDtoC++;
            // ��ʱ�����ݷ��Ͳ��ɹ�(1.5��)
            if (commSendTickerDtoC >= ((Uint32)600L*commSendDataDtoC.sendNumMax/(dspBaudRegData[baudrateDtoC][0]*10) + 1))     //*2ms
            {
                commStatusDtoC = SCI_SEND_OK;
            }
            else
            {
                break;
            }

        // ��������OK
        case SCI_SEND_OK:
            if(SciDtoCRegs->SCICTL2.all & 0x0001)// Transmitter empty flag, �����������
            {
                commStatusDtoC = SCI_RECEIVE_DATA;  // ������Ϻ���Ϊ����״̬
                SET_RTS_R_DtoC;  // RTS��Ϊ����
                SciDtoCRegs->SCICTL1.all = 0x0021;  // ����
                SciDtoCRegs->SCICTL2.all = 0x00C2;  // ���������ж�
                commSendTickerDtoC = 0;
            }
            break;

        default:
            break;
    }
}


#endif /* SRC_APP_COM_HANDC_C_ */

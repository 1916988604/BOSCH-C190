

#ifndef SRC_APP_C_COM_LIN_H_
#define SRC_APP_C_COM_LIN_H_


#ifdef  SRC_APP_COM_LIN_C_
    #define SRC_APP_COM_LIN
#else
    #define SRC_APP_COM_LIN  extern
#endif





#endif /* SRC_APP_C_COM_LIN_H_ */

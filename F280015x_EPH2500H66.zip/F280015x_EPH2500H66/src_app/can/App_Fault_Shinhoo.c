#ifndef	APP_FAULTSHINHOO_C
#define	APP_FAULTSHINHOO_C

#include "app_include.h"


#if (PMSM_DEBUG == 10)

extern volatile MOTOR_Vars_t motorVars_M1;

#if MOTOR_NUMBER==51
    #define UDC_OVerr   285     //v
    #define UDC_OVrec   270     //v
    #define UDC_LVerr   140     //v
    #define UDC_LVrec   150     //v

    #define UDC_CURerr  800    //8.0      //ĸ�ߵ���������,*100
    #define UDC_CURwarn 450    //4.5
    #define UDC_CURrec  400    //4.0

    #define OUTCURerr   10      //A 7.5
    #define OUTCURwarn  9      //A
    #define OUTCURrec   6      //A
    #define SPEED_OS    4500    //���ٵ�

    #define SPEED_noLoadErr     2500    //RPM;  //��ת�����ʼ�ٶ�
    #define CUR_noLoadErr       0.2     //A
    #define ROTORLock_cCUR      5       //A
    #define ROTORLock_speed     300     //RPM   //��ת�����жϵ�

    #define IGBT_OTerr      105//128     //IGBT���µ�,��
    #define IGBT_OTwarn     100//120     //IGBT���±�����,��
    #define IGBT_OTrec      95//110     //IGBT���»ָ���,��

    #define speedRevCheck   100     //��ת�жϵ�
#else
    #define UDC_OVerr   750     //v
    #define UDC_OVrec   720     //v
    #define UDC_LVerr   410     //v
    #define UDC_LVrec   430     //v

    #define UDC_CURerr  1800    //18.0      //ĸ�ߵ���������,*100
    #define UDC_CURwarn 1500    //15.0
    #define UDC_CURrec  1000    //10.0

    #define OUTCURerr   25      //A
    #define OUTCURwarn  20      //A
    #define OUTCURrec   14      //A
    #define SPEED_OS    7500    //���ٵ�

    #define SPEED_noLoadErr     3400    //RPM;  //��ת�����ʼ�ٶ�
    #define CUR_noLoadErr       0.4     //A
    #define ROTORLock_cCUR      5       //A
    #define ROTORLock_speed     300     //RPM   //��ת�����жϵ�

    #define IGBT_OTerr      110     //IGBT���µ�,��
    #define IGBT_OTwarn     105     //IGBT���±�����,��
    #define IGBT_OTrec      100     //IGBT���»ָ���,��

    #define speedRevCheck   100     //��ת�жϵ�
#endif

//��ʼ��
void  f_faultCheck_Init(void)
{
    u_fault_sta.all = 0;
    u_fault_recFlg.all = 0;
    fault_cnt.canErr_cnt = 0;
    fault_cnt.igbt_OT_cnt = 0;
    fault_cnt.load_no_cnt = 0;
    fault_cnt.oc_cnt = 0;
    fault_cnt.ol_cnt = 0;
    fault_cnt.udc_lv_cnt = 0;
    fault_cnt.udc_ov_cnt = 0;
    fault_cnt.zeroSpd_cnt = 0;
    fault_cnt.os_cnt = 0;
    fault_cnt.recSpd_cnt = 0;
    fault_cnt.udcoc_cnt = 0;
    fault_cnt.phaseCnc_cnt = 0;
    fault_recCnt.zeroSpd_cnt = 0;
    fault_recCnt.load_no_cnt = 0;
    fault_recCnt.udc_ov_cnt = 0;
    fault_recCnt.oc_cnt = 0;

    fault_cnt.udc_errChk = 0;
    fault_cnt.spd_errChk = 0;
    fault_cnt.is_errChk = 0;
    u_motor_ctrl.all = 0;
}

//���ϼ��
void  f_faultCheck(void)
{
    long u32_temp;
    float f_temp;
    static unsigned int can_errCnt=0;
    static unsigned int loadNc_clrCnt=0;
    static unsigned int oc_clrCnt=0;
    static unsigned int zeroSpd_clrCnt=0;
    static unsigned int OT_clrCnt=0;
    static unsigned int udcLvFlgt=0;

    fault_cnt.udc_errChk = Temp_IGBT.V_LN_Lpf;//motorVars_M1.adcData.VdcBus_V;
    fault_cnt.spd_errChk = motorSpd_Lpf;
    fault_cnt.is_errChk = fabsf(motorVars_M1.Is_A);

    //ĸ�߹�ѹ
    if(fault_cnt.udc_errChk  > UDC_OVerr){
        fault_cnt.udc_ov_cnt++;
        if(fault_cnt.udc_ov_cnt > 300){
            u_fault_sta.bit.udc_ov = 1;
            fault_cnt.udc_ov_cnt = 301;
        }
    }else if(fault_cnt.udc_errChk  < UDC_OVrec){
        if(u_fault_sta.bit.udc_ov == 1){
            fault_cnt.udc_ov_cnt++;
            if(fault_cnt.udc_ov_cnt > 801){     //5S recover
                fault_cnt.udc_ov_cnt = 0;
                u_fault_sta.bit.udc_ov = 0;
            }
        }else{
            fault_cnt.udc_ov_cnt = 0;
            u_fault_sta.bit.udc_ov = 0;
        }
    }

    //ĸ��Ƿѹ
    if(fault_cnt.udc_errChk  > UDC_LVerr){
        udcLvFlgt = 1;
    }
    if((udcLvFlgt==1)){// && (motorVars_M1.flagEnableRunAndIdentify==1)){
        if(fault_cnt.udc_errChk  < UDC_LVerr){
            fault_cnt.udc_lv_cnt++;
            if(fault_cnt.udc_lv_cnt > 300){
                u_fault_sta.bit.udc_lv = 1;
                fault_cnt.udc_lv_cnt = 301;
            }
        }else if(fault_cnt.udc_errChk  > UDC_LVrec){
            if(u_fault_sta.bit.udc_lv){
                fault_cnt.udc_lv_cnt++;
                if(fault_cnt.udc_lv_cnt > 801){     //5s recover
                    fault_cnt.udc_lv_cnt = 0;
                    u_fault_sta.bit.udc_lv = 0;
                }
            }else{
                fault_cnt.udc_lv_cnt = 0;
                u_fault_sta.bit.udc_lv = 0;
            }
        }
    }else{
        if(u_fault_sta.bit.udc_lv == 1){
            if(fault_cnt.udc_errChk  > UDC_LVrec){
                fault_cnt.udc_lv_cnt++;
                if(fault_cnt.udc_lv_cnt > 801){     //5s recover
                    fault_cnt.udc_lv_cnt = 0;
                    u_fault_sta.bit.udc_lv = 0;
                }
            }
        }else{
            fault_cnt.udc_lv_cnt = 0;
            u_fault_sta.bit.udc_lv = 0;
        }
    }

    //��ת����
    if((fabsf(fault_cnt.spd_errChk) < ROTORLock_speed)&&(fault_cnt.is_errChk > ROTORLock_cCUR)){
        zeroSpd_clrCnt=0;
        fault_cnt.zeroSpd_cnt++;
        if(fault_cnt.zeroSpd_cnt > 100){
            u_fault_sta.bit.zeroSpd = 1;
            fault_cnt.zeroSpd_cnt = 101;
        }
    }else{
        if((u_fault_sta.bit.zeroSpd) && (fault_recCnt.zeroSpd_cnt<5)){//5������
            fault_cnt.zeroSpd_cnt++;
            if(fault_cnt.zeroSpd_cnt > 1101){//10s����
                fault_cnt.zeroSpd_cnt = 0;
                fault_recCnt.zeroSpd_cnt++;
                u_fault_sta.bit.zeroSpd =0;
            }
        }else{
            zeroSpd_clrCnt++;
            if(zeroSpd_clrCnt > 500){//�ӳ�5S�����������
                fault_recCnt.zeroSpd_cnt = 0;
            }
            fault_cnt.zeroSpd_cnt = 0;
        }
    }

    //��ת
    if((fabsf(fault_cnt.spd_errChk) > SPEED_noLoadErr)&&(fault_cnt.is_errChk < CUR_noLoadErr )){
        loadNc_clrCnt=0;
        fault_cnt.load_no_cnt++;
        if(fault_cnt.load_no_cnt > 100){
            u_fault_sta.bit.load_no = 1;
            fault_cnt.load_no_cnt = 101;
        }
    }else{
        if((u_fault_sta.bit.load_no) && (fault_recCnt.load_no_cnt<5)){   //5������
            fault_cnt.load_no_cnt++;
            if(fault_cnt.load_no_cnt>1101){  //10s����
                 fault_cnt.load_no_cnt = 0;
                 fault_recCnt.load_no_cnt++;
                 u_fault_sta.bit.load_no = 0;
            }
        }else{
            loadNc_clrCnt++;
            if(loadNc_clrCnt > 500){//�ӳ�5S�����������
                fault_recCnt.load_no_cnt = 0;
            }
            fault_cnt.load_no_cnt = 0;
        }
    }


    //IGBT����
    if(Temp_IGBT.igbtTemp > IGBT_OTerr){
        OT_clrCnt = 0;
        fault_cnt.igbt_OT_cnt++;
        if(fault_cnt.igbt_OT_cnt>100){
            u_fault_sta.bit.igbt_OT = 1;
            u_fault_sta.bit.igbt_OTwarn = 1;
        }
    }else if(Temp_IGBT.igbtTemp > IGBT_OTwarn){
        OT_clrCnt = 0;
        fault_cnt.igbt_OT_cnt++;
        if(fault_cnt.igbt_OT_cnt>100){
            u_fault_sta.bit.igbt_OTwarn = 1;
        }
    }else if(Temp_IGBT.igbtTemp < IGBT_OTrec){
        fault_cnt.igbt_OT_cnt = 0;
        OT_clrCnt++;
        if(OT_clrCnt>500){                      //�ӳ�5S�����������
            u_fault_sta.bit.igbt_OT = 0;
            u_fault_sta.bit.igbt_OTwarn = 0;
        }
    }else{
        fault_cnt.igbt_OT_cnt = 0;
    }

    //����
    if(fault_cnt.is_errChk > OUTCURerr){
        oc_clrCnt=0;
        fault_cnt.oc_cnt++;
        if(fault_cnt.oc_cnt > 3){         //30ms
            u_fault_sta.bit.oc = 1;
            fault_cnt.oc_cnt = 4;
        }
    }else{
        if((u_fault_sta.bit.oc) && (fault_recCnt.oc_cnt<5)){   //5������
            fault_cnt.oc_cnt++;
            if(fault_cnt.oc_cnt>1004){  //10s����
                 fault_cnt.oc_cnt = 0;
                 fault_recCnt.oc_cnt++;
                 u_fault_sta.bit.oc = 0;
            }
        }else{
            oc_clrCnt++;
            if(oc_clrCnt > 500){//�ӳ�5S�����������
                fault_recCnt.oc_cnt= 0;
            }
            fault_cnt.oc_cnt = 0;
        }
    }


#if   (MOTOR_NUMBER==3)||(MOTOR_NUMBER==4)||(MOTOR_NUMBER==5)
    u_fault_sta.bit.hilErr = Temp_IGBT.hvilFlg;
#endif

    f_temp = 1600;
#if MOTOR_DIR==1
    f_temp = -f_temp;
#endif

    if((u_fault_sta.bit.udc_lv) || (u_fault_sta.bit.udc_ov) || (u_fault_sta.bit.igbt_OT) || (u_fault_sta.bit.zeroSpd) \
       || (u_fault_sta.bit.oc) || (u_fault_sta.bit.load_no) || (udcLvFlgt==0) || (motorVars_M1.faultMtrNow.all !=0)){
        u_motor_ctrl.bit.run_enable = 0;
        vcu_speedRampCmd = 0;
        can_errCnt = 0;
    }else if((u_fault_sta.bit.canErr)||(u_fault_sta.bit.checkErr)){
        can_errCnt++;
        if(can_errCnt<1000){        //10s
            vcu_speedRampCmd = f_temp;      //2000RPM
            u_motor_ctrl.bit.run_enable = 1;
        }else{
            can_errCnt = 1001;
            vcu_speedRampCmd = 0;
            u_motor_ctrl.bit.run_enable = 0;
        }
    }else if(u_fault_sta.bit.igbt_OTwarn == 1){
        vcu_speedRampCmd = f_temp;      //1600RPM
        can_errCnt = 0;
        u_motor_ctrl.bit.run_enable = u_motor_ctrl.bit.enable;
    }else{
        vcu_speedRampCmd = speed_ramp_cmd;
        can_errCnt = 0;
        u_motor_ctrl.bit.run_enable = u_motor_ctrl.bit.enable;
    }
    //motorVars_M1.speedRef_Hz = vcu_speedRampCmd*0.016666 * USER_MOTOR1_NUM_POLE_PAIRS;
    //motorVars_M1.flagEnableRunAndIdentify = u_motor_ctrl.bit.run_enable;
}

#endif
#endif






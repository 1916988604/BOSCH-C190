#ifndef	APP_BOSHCAN_C
#define	APP_BOSHCAN_C

#include "app_include.h"

extern volatile MOTOR_Vars_t motorVars_M1;
extern int EnstartUpFlg;
extern float motorPwr_Lpf;
extern int UnderLVFlag;
extern int OffestFlg;
extern float SPEED_noLoadPower;
//BOSH��CAN��Ϣ
#if (PMSM_DEBUG == 8)

const Uint32 mail_id[32] = {0x747,0x4179,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,
                            0x787,0x767,0x768,0x4192,0x4193,0x4194,0x4195,0x4196,0x4197,0x4198,
                            0x4199,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,
                            0x4200,0x4200};

unsigned char crc12=0;

//#pragma CODE_SECTION(Mot_Receive_From_Evcu, "ramfuncs");
/****************************************************************************************
** ��������:  �������ó�ʼ����mbox0-9������;  mbox10-12������MONITOR; mbox13-28������;  29-31:UDS BOOT
** ����ĵײ�����
****************************************************************************************/
void  J1939_Module_Mailbox_Config(void)
{
    CAN_setupMessageObject(myCAN0_BASE, 1, mail_id[0], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_RX, 0, 0,8);

    CAN_setupMessageObject(myCAN0_BASE, 11, mail_id[10], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 12, mail_id[11], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 13, mail_id[12], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
}

/****************************************************************************************
** �����������ʼ��
****************************************************************************************/
void J1939_Common_Data_Init(void)
{
    unsigned int i;

    J1939_Module.u16_send_count1 = 0;  //����֡1������
    J1939_Module.u16_send_count1_flag  = 0;
    J1939_Module.u16_send_count2 = 0;   //����֡2������
    J1939_Module.u16_send_count2_flag  = 0;
    J1939_Module.u16_send_count3 = 0;   //����֡3������
    J1939_Module.u16_send_count3_flag  = 0;

    J1939_Module.flag_rece1 = 0;

    Agreement_data.MOT_SEND_CNT1 = 100 ;  //100ms
    Agreement_data.MOT_SEND_CNT2 = 100 ;  //100ms
    Agreement_data.MOT_SEND_CNT3 = 10 ;   //100ms

    for(i=0;i<8;i++){
        ReceiveFrame.CANData[i]=0;
        ReceiveFrame1.CANData[i]=0;
        SendFrame.CANData[i]=0;
    }

    motorPwr_f=0;
    motorPwr_Lpf=0;
    motorSpd=0;
    motorSpd_Lpf=0;
    vcu_speedDirCmd = 0;
}

void Time_Count(void)       //1ms os
{
    if(J1939_Module.u16_send_count1 < Agreement_data.MOT_SEND_CNT1)
    {
        J1939_Module.u16_send_count1++;
        if(J1939_Module.u16_send_count1 == Agreement_data.MOT_SEND_CNT1)
        {
            J1939_Module.u16_send_count1 = 0;
            J1939_Module.u16_send_count1_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count2 < Agreement_data.MOT_SEND_CNT2)
    {
        J1939_Module.u16_send_count2++;
        if(J1939_Module.u16_send_count2 == Agreement_data.MOT_SEND_CNT2)
        {
            J1939_Module.u16_send_count2 = 0;
            J1939_Module.u16_send_count2_flag = 1;
        }
    }
    if(J1939_Module.u16_send_count3 < Agreement_data.MOT_SEND_CNT3)
    {
        J1939_Module.u16_send_count3++;
        if(J1939_Module.u16_send_count3 == Agreement_data.MOT_SEND_CNT3)
        {
            J1939_Module.u16_send_count3 = 0;
            J1939_Module.u16_send_count3_flag = 1;
        }
    }
}

/****************************************************************************************
** ��������:  MOT��EVCU����
****************************************************************************************/
void Mot_Send_To_Evcu(void)   //1ms os
{
    if(J1939_Module.u16_send_count1_flag == 1)
    {
        J1939_Module.u16_send_count1_flag = 0;
        if(App_TxEnable){
            SysCanSendData(CAN_VEHCILE_SEND0_MAILBOX_ID);
        }else{

        }
    }
    if(J1939_Module.u16_send_count2_flag == 1)
    {
        J1939_Module.u16_send_count2_flag = 0;
        if(App_TxEnable){
            SysCanSendData(CAN_VEHCILE_SEND1_MAILBOX_ID);
        }else{

        }
    }
    if(J1939_Module.u16_send_count3_flag == 1)
    {
        J1939_Module.u16_send_count3_flag = 0;
        if(App_TxEnable){
            SysCanSendData(CAN_VEHCILE_SEND2_MAILBOX_ID);
        }else{

        }
    }
}

void SysCanSendData(Uint16 num)
{
	unsigned long  uIntTemp,warnFlg;
	Uint16 errType;
	static	int rollcnt346=0,rollcnt441=0;
	float   f_temp;
	long    Int_temp;

	unsigned char i,k;
	unsigned char crc1=0x0FF;
	unsigned char crc2=0x0FF;

    if(num == CAN_VEHCILE_SEND0_MAILBOX_ID)
    {
        uIntTemp = 0;

        if(motorVars_M1.adcData.VdcBus_V  < 35)		//35V
        {
        	uIntTemp = 0;
        }else{
            uIntTemp = motorVars_M1.adcData.VdcBus_V; //udc
        }
        SendFrame.CANData[3] = uIntTemp & 0x0FF;
        SendFrame.CANData[4] = (uIntTemp >> 8)&0x0FF;

        uIntTemp = 0;
        if((u_fault_sta.bit.igbt_OT)||(u_fault_sta.bit.igbt_OTwarn)){//����
        	uIntTemp = 1;
        }
        if(u_fault_sta.bit.udc_ov){//��ѹ
        	uIntTemp = uIntTemp|2;
        }
        if(u_fault_sta.bit.udc_lv){//Ƿѹ
        	uIntTemp = uIntTemp|4;
        }
        if(motorVars_M1.faultMtrNow.bit.moduleOverCurrent){//Ӳ������
        	uIntTemp = uIntTemp|8;
        }
        if((u_fault_sta.bit.ol) || (u_fault_sta.bit.udc_oc)){//���� ���ض���
        	uIntTemp = uIntTemp|32;
        }
        if(u_fault_sta.bit.zeroSpd){//��ת
        	uIntTemp = uIntTemp|64;
        }
        if(u_fault_sta.bit.spdLowErr2){//ȱ��
            uIntTemp = uIntTemp|128;
        }
        SendFrame.CANData[2] = uIntTemp;// + 152;

        if((u_fault_sta.bit.oc) || (u_fault_sta.bit.idc_warn)){//��������/ĸ�߹���
        	uIntTemp = 1;
        }else{
        	uIntTemp = 0;
        }
        SendFrame.CANData[6] = (u_fault_sta.bit.spdLowErr<<4)+(motorVars_M1.faultMtrNow.bit.voltageOffset<<3)+(motorVars_M1.faultMtrNow.bit.currentOffset<<2)+(uIntTemp<<1)+(u_fault_sta.bit.sersorOpen)+224;//�̶�·����

        if(motorVars_M1.motorState>=MOTOR_SEEK_POS){
            if(Temp_IGBT.idc < 10){
                SendFrame.CANData[5] = 1;
            }else{
                SendFrame.CANData[5] = fabsf(Temp_IGBT.idc/5); //�����ֱ���0.05
            }
        }else{
            SendFrame.CANData[5] = 0;
        }

        SendFrame.CANData[1] = rollcnt346 + 240;
        rollcnt346++;
        if(rollcnt346>15){
        	rollcnt346 = 0;
        }
        SendFrame.CANData[7] = 255;

        k = 7;
        while(k--){
        	crc1 = crc1 ^ SendFrame.CANData[7-k];
        	for(i=8;i>0;--i){
        		if(crc1 & 0x80){
        			crc1 = crc1 & 0x7F;
        			crc1 = (crc1 << 1)^ 0x02F;
        		}else{
        			crc1 = (crc1 << 1);
        		}
        	}
        }
        crc1 = crc1 ^ 0x0FF;
        SendFrame.CANData[0] = crc1;

        CAN_sendMessage(myCAN0_BASE, CAN_VEHCILE_SEND0_MAILBOX_ID, 8, SendFrame.CANData);
    }
    else if(num == CAN_VEHCILE_SEND1_MAILBOX_ID)
    {
        f_temp = fabs(motorSpd_Lpf);
        if(motorVars_M1.flagEnableRunAndIdentify==0){//20250605�Ķ�
            f_temp = 0;
        }
        uIntTemp = (Uint16)f_temp;
        SendFrame.CANData[3] = uIntTemp & 0x0FF;
        SendFrame.CANData[4] = (uIntTemp >> 8)&0x0FF;

        if((u_fault_sta.bit.igbt_OT)||(u_fault_sta.bit.udc_ov)||(u_fault_sta.bit.udc_lv)\
        	||(u_fault_sta.bit.zeroSpd)||(motorVars_M1.faultMtrNow.bit.moduleOverCurrent)||(u_fault_sta.bit.oc)||(u_fault_sta.bit.load_no)||(u_fault_sta.bit.idc_warn)\
        	||(u_fault_sta.bit.sersorOpen)||(u_fault_sta.bit.ol) || (motorVars_M1.faultMtrNow.bit.currentOffset) || (motorVars_M1.faultMtrNow.bit.voltageOffset)|| (u_fault_sta.bit.spdLowErr2)){
        	errType = 3;
        	warnFlg = 1;
        }else if((u_fault_sta.bit.canErr)||(u_fault_sta.bit.checkErr)){
        	errType = 2;
        	warnFlg = 1;
        }else if((u_fault_sta.bit.igbt_OTwarn)  || (u_fault_sta.bit.udc_oc) || (u_fault_sta.bit.spdLowErr)){
        	errType = 1;
        	warnFlg = 1;
        }else{
        	errType = 0;
        	warnFlg = 0;
        }
        if(motorVars_M1.flagEnableRunAndIdentify == 1){
        	uIntTemp = 128;
        }else{
        	uIntTemp = 0;
        }
        SendFrame.CANData[5] = errType + uIntTemp + (warnFlg<<4) + (u_fault_sta.bit.load_no<<5);
        if((u_fault_sta.bit.canErr)||(u_fault_sta.bit.checkErr)){
        	uIntTemp = 1;
        }else{
        	uIntTemp = 0;
        }
        SendFrame.CANData[6] = uIntTemp + 254;

        SendFrame.CANData[2] = 2 + 48;	//3���������汾��3,4:302���,//16����Ӳ���汾��1  32����Ӳ���汾��2 48����Ӳ���汾��3

        SendFrame.CANData[1] = rollcnt441 + 240;
        rollcnt441++;
        if(rollcnt441>15){
        	rollcnt441 = 0;
        }
        SendFrame.CANData[7] = 255;

        k = 7;
        while(k--){
        	crc2 = crc2 ^ SendFrame.CANData[7-k];
        	for(i=8;i>0;--i){
        		if(crc2 & 0x80){
        			crc2 = crc2 & 0x7F;
        			crc2 = (crc2 << 1)^ 0x02F;
        		}else{
        			crc2 = (crc2 << 1);
        		}
        	}
        }
        crc2 = crc2 ^ 0x0FF;
        SendFrame.CANData[0] = crc2;

        CAN_sendMessage(myCAN0_BASE, CAN_VEHCILE_SEND1_MAILBOX_ID, 8, SendFrame.CANData);
    }
    else if(num == CAN_VEHCILE_SEND2_MAILBOX_ID)
    {

            SendFrame.CANData[0] = Temp_IGBT.igbtTemp + 40;     //ctrl TEMPE
            SendFrame.CANData[1] = Temp_IGBT.ntcTemp + 40;      //NTC TEMPE

            f_temp = SPEED_noLoadPower;
            uIntTemp = (int16)f_temp;
            SendFrame.CANData[2] = uIntTemp & 0x0FF;
            SendFrame.CANData[3] = (uIntTemp >> 8)&0x0FF;

            f_temp = motorPwr_Lpf;
            uIntTemp = (int16)f_temp;
            SendFrame.CANData[4] = uIntTemp & 0x0FF;
            SendFrame.CANData[5] = (uIntTemp >> 8)&0x0FF;
//
//
//            f_temp = fabsf(motorVars_M1.Is_A * 10.0f);
//            uIntTemp = (int16)f_temp;
//            SendFrame.CANData[6] = uIntTemp & 0x0FF;
//            SendFrame.CANData[7] = (uIntTemp >> 8)&0x0FF;

        CAN_sendMessage(myCAN0_BASE, CAN_VEHCILE_SEND2_MAILBOX_ID, 8, SendFrame.CANData);
    }
}

//���մ���
void  Mot_Receive_From_Evcu(void)   //200us
{
    unsigned int i;
    if( (CAN_readMessage(myCAN0_BASE, CAN_VEHCILE_RECV_NUMBER, rxMsgData)) && (J1939_Module.flag_rece1 == 0) )
     {
        for(i=0;i<8;i++){
            ReceiveFrame.CANData[i] = rxMsgData[i];
        }
        J1939_Module.flag_rece1 = 1;
     }
     if( (CAN_readMessage(myCAN0_BASE, 2, rxMsgData)) && (J1939_Module.flag_rece2 == 0) )
     {
        for(i=0;i<8;i++){
            ReceiveFrame1.CANData[i] = rxMsgData[i];
        }
        J1939_Module.flag_rece2 = 1;
     }
}


void Evcu_Receive_Process(void) 	//1ms os
{
	long u32_temp;
	static int rollcntbak=0;
	static int rollcntFlg=0;
	int rollcntOK;

	static int canErrtime=0;
	static int checkErrCnt=0;
	unsigned char i,k;
	unsigned char crc3=0x0FF;

	static int startUpCnt=0;
	static int startUpFlg=0;

	canErrtime++;
	if(canErrtime>1000){		//1s
		canErrtime = 1000;
		u_fault_sta.bit.canErr = 1;
	}else{
		u_fault_sta.bit.canErr = 0;
	}

    if(J1939_Module.flag_rece1 == TRUE)
    {
    	canErrtime = 0;
    	if(rollcntFlg == 0){
        	rollcntbak = ReceiveFrame.CANData[1] & 0x0F;
        	rollcntOK = 1;
        	rollcntFlg = 1;
    	}else{
    		rollcntFlg = 1;
			u32_temp = ReceiveFrame.CANData[1] & 0x0F;
			if((u32_temp == (rollcntbak + 1)) || (rollcntbak == 15)&&(u32_temp==0)){
				rollcntOK = 1;
			}else{
				rollcntOK = 0;
			}
			rollcntbak = ReceiveFrame.CANData[1]  & 0x0F;
    	}
        k = 7;
        while(k--){
        	crc3 = crc3 ^ ReceiveFrame.CANData[7-k];
        	for(i=8;i>0;--i){
        		if(crc3 & 0x80){
        			crc3 = crc3 & 0x7F;
        			crc3 = (crc3 << 1)^ 0x02F;
        		}else{
        			crc3 = (crc3 << 1);
        		}
        	}
        }
        crc3 = crc3 ^ 0x0FF;
        //crc3 = crc3 & 0x0FF;
        crc12 = crc3;
    	if((crc3 == ReceiveFrame.CANData[0])&&(rollcntOK==1)){
//    	 if(1){
			u32_temp=(ReceiveFrame.CANData[3] << 8) + ReceiveFrame.CANData[2];
			if(u32_temp>SPEED_MAX){
				u32_temp = SPEED_MAX;
			}
			if(u32_temp<SPEED_MIN){
				u32_temp = SPEED_MIN;
			}

#if MOTOR_DIR==1		//310
			vcu_speedDirCmd = -1;
#else
			vcu_speedDirCmd = 1;
#endif

			startUpCnt++;
			if(startUpCnt>5){	//500ms
				startUpCnt = 5;
				startUpFlg = 1;
			}

			if(((ReceiveFrame.CANData[1])&0x010) == 0x10) {
				if((startUpFlg==1) && (EnstartUpFlg==1)){//20250625��
				    u_motor_ctrl.bit.enableCAN = 1;
				    UnderLVFlag = 1;
				    fault_cnt.recSpd_cnt++;//ʹ�ܺ����
				    if(fault_cnt.recSpd_cnt > 300)//20S
				    {
				        fault_cnt.recSpd_cnt = 300;
				    }
				}
			}else{
				if(fabsf(motorSpd_Lpf) <= SPEED_MIN){	//<1000RPM
				    u_motor_ctrl.bit.enableCAN = 0;
					startUpFlg = 0;
					fault_cnt.recSpd_cnt = 0;
				}
				u32_temp = 0;
				UnderLVFlag = 0;
			}

            vcu_speedCmd = u32_temp;
            u_speed_can = vcu_speedCmd;
            u_sci_enable.bit.can_enable = u_motor_ctrl.bit.enableCAN ;

			if(checkErrCnt>0){
				checkErrCnt--;
			}else{
				u_fault_sta.bit.checkErr = 0;
			}
    	}else{
    		checkErrCnt++;
    		if(checkErrCnt > 10){
				u_fault_sta.bit.checkErr = 1;
				checkErrCnt=10;
    		}else{
    		}
    	}

        J1939_Module.flag_rece1 = 0;
    }

}

#endif

#endif



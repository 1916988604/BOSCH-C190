#ifndef	APP_FAULT_BOSH_C
#define	APP_FAULT_BOSH_C

#include "app_include.h"

#if (PMSM_DEBUG == 8)

extern volatile MOTOR_Vars_t motorVars_M1;
extern volatile MOTOR_Handle motorHandle_M1;

#define UDC_OVerr     760//Vdc
#define UDC_OVrec     720//Vdc
#define UDC_LVerr     390//Vdc
#define UDC_LVrec     430//Vdc
#define UDC_PoewrDown 450//Vdc

#define UDC_CURerr  900//9.0A      //ĸ�ߵ���������,*100
#define UDC_CURwarn 700//7.0A
#define UDC_CURrec  450//4.5A

#define OUTCURerr   17      //A
#define OUTCURwarn  14      //A
#define OUTCURrec   10      //A
#define SPEED_OS    7500    //���ٵ�

#define SPEED_noLoadErr     3500    //RPM;  //��ת�����ʼ�ٶ�
#define CUR_noLoadErr       0.5//A
#define ROTORLock_cCUR      5//3       //A
#define ROTORLock_speed     300     //RPM   //��ת�����жϵ�

#define IGBT_OTerr      110       //IGBT���µ�,��
#define IGBT_OTwarn     105        //IGBT���±�����,��
#define IGBT_OTrec      100     //IGBT���»ָ���,��

#define speedRevCheck   100     //��ת�жϵ�

#define OVPWR_PUMP1 2600//W  //���ʱ�����
#define OVPWR_PUMP2 2800//W

#define PhaseLossCur 0.1//A
int EnstartUpFlg;
int StallFlg=0;
int OffestFlg=0;
int UnderLVFlag=0;

//��ʼ��
void  f_faultCheck_Init(void)
{
    u_fault_sta.all = 0;
    fault_cnt.canErr_cnt = 0;
    fault_cnt.igbt_OT_cnt = 0;
    fault_cnt.load_no_cnt = 0;
    fault_cnt.oc_cnt = 0;
    fault_cnt.oc_warn_cnt = 0;
    fault_cnt.ol_cnt = 0;
    fault_cnt.udc_lv_cnt = 0;
    fault_cnt.udc_ov_cnt = 0;
    fault_cnt.zeroSpd_cnt = 0;
    fault_cnt.os_cnt = 0;
    fault_cnt.recSpd_cnt = 0;
    fault_cnt.udcoc_cnt = 0;
    fault_cnt.phaseCnc_cnt = 0;
    fault_cnt.oc_warn3_cnt = 0;
    fault_cnt.sersOpn_cnt = 0;
    fault_cnt.pwrWarn_cnt = 0;
    fault_recCnt.zeroSpd_cnt = 0;
    fault_recCnt.load_no_cnt = 0;
    fault_cnt.idc_warn3_cnt = 0;


    fault_cnt.udc_errChk = 0;
    fault_cnt.spd_errChk = 0;
    fault_cnt.is_errChk = 0;
    fault_cnt.power_errChk = 0;
    u_motor_ctrl.all = 0;
    EnstartUpFlg = 0;
    SPEED_noLoadPower = 0;
}

//���ϼ��
void  f_faultCheck(void)
{
    float f_temp;
    static unsigned int can_errCnt=0;
    static unsigned int loadNc_errCnt=0;
    static unsigned int oc_clrCnt=0;
    static unsigned int udcoc_clrCnt=0;

    static unsigned int udcLvFlgt=0;

    fault_cnt.udc_errChk = motorVars_M1.adcData.VdcBus_V;
    fault_cnt.spd_errChk = motorSpd_Lpf;
    fault_cnt.is_errChk = fabsf(motorVars_M1.Is_A);
    fault_cnt.power_errChk = motorPwr_Lpf;

    //�����ʹ���
    if((fault_cnt.udc_errChk > UDC_LVerr) && (fault_cnt.udc_errChk < UDC_PoewrDown) && ((motorVars_M1.flagEnableRunAndIdentify==1))){
        fault_cnt.oc_warn_cnt++;
        if(fault_cnt.oc_warn_cnt > 3){
            u_fault_sta.bit.spdLowErr = 1;
            fault_cnt.oc_warn_cnt = 4;
        }
    }else{
        u_fault_sta.bit.spdLowErr = 0;
        fault_cnt.oc_warn_cnt = 0;
    }

	//ĸ�߹�ѹ
	if(fault_cnt.udc_errChk > UDC_OVerr){
		fault_cnt.udc_ov_cnt++;
		if(fault_cnt.udc_ov_cnt > 3){
			u_fault_sta.bit.udc_ov = 1;
			fault_cnt.udc_ov_cnt = 4;
		}
	}else if(fault_cnt.udc_errChk < UDC_OVrec){
		if(u_fault_sta.bit.udc_ov == 1){
			fault_cnt.udc_ov_cnt++;
			if(fault_cnt.udc_ov_cnt > 304){		//3s recover
				fault_cnt.udc_ov_cnt = 0;
				u_fault_sta.bit.udc_ov = 0;
			}
		}else{
			fault_cnt.udc_ov_cnt = 0;
			u_fault_sta.bit.udc_ov = 0;
		}
	}

	//ĸ��Ƿѹ
	if(fault_cnt.udc_errChk > UDC_LVerr){
		udcLvFlgt = 1;
	}
	if((udcLvFlgt==1)&&(motorVars_M1.flagEnableRunAndIdentify==1)&&(UnderLVFlag==1)){
	    if(fault_cnt.udc_errChk < UDC_LVerr){
	        fault_cnt.udc_lv_cnt++;
	        if(fault_cnt.udc_lv_cnt > 3){
	            u_fault_sta.bit.udc_lv = 1;
	            fault_cnt.udc_lv_cnt = 4;
	        }
	    }else if(fault_cnt.udc_errChk > UDC_LVrec){
	        if(u_fault_sta.bit.udc_lv){
	            fault_cnt.udc_lv_cnt++;
	            if(fault_cnt.udc_lv_cnt > 304){     //3s recover
	                fault_cnt.udc_lv_cnt = 0;
	                u_fault_sta.bit.udc_lv = 0;
	            }
	        }else{
	            fault_cnt.udc_lv_cnt = 0;
	            u_fault_sta.bit.udc_lv = 0;
	        }
	    }
	}else{
	    if(u_fault_sta.bit.udc_lv == 1){
	        if(fault_cnt.udc_errChk > UDC_LVrec){
	            fault_cnt.udc_lv_cnt++;
	            if(fault_cnt.udc_lv_cnt > 304){     //3s recover
	                fault_cnt.udc_lv_cnt = 0;
	                u_fault_sta.bit.udc_lv = 0;
	            }
	        }
	    }else{
	        fault_cnt.udc_lv_cnt = 0;
	        u_fault_sta.bit.udc_lv = 0;
	    }
	}

	//��һ���ϸ�ѹ��ʱ���,δ�����ɲ���������
    if((udcLvFlgt==1) && (motorVars_M1.flagEnableOffsetCalc==1) && (OffestFlg==0))
    {

        fault_cnt.oc_warn3_cnt++;
        if(fault_cnt.oc_warn3_cnt > 79)//800ms
        {
            fault_cnt.oc_warn3_cnt = 80;
            DINT;
            runMotor1OffsetsCalculation(motorHandle_M1);//ADC����/��ѹoffsetУ��
            EINT;
            EnstartUpFlg = 1;
        }
    }
    else
    {
        fault_cnt.oc_warn3_cnt = 0;
    }

    if((fault_cnt.recSpd_cnt < 300) && (StallFlg==0))//ʹ��20S�ڶ�ת��������
    {
        if(fabsf(fault_cnt.spd_errChk) > ROTORLock_speed){
            StallFlg = 1;
        }
        //��ת����������
        if((fabsf(fault_cnt.spd_errChk) < ROTORLock_speed)&&(fault_cnt.is_errChk > ROTORLock_cCUR)&&(u_fault_sta.bit.spdHighErr2==0)){
            fault_cnt.zeroSpd_cnt++;
            if(fault_cnt.zeroSpd_cnt > 200){
                u_fault_sta.bit.spdHighErr2 = 1;
                fault_cnt.zeroSpd_cnt = 200;//2s����
                fault_recCnt.zeroSpd_cnt++;
            }
        }else{
            if(fault_cnt.zeroSpd_cnt > 0){
                fault_cnt.zeroSpd_cnt--;
                if(fault_recCnt.zeroSpd_cnt<4){

                }else{
                    u_fault_sta.bit.zeroSpd = 1;

                }
            }else{
                if(fault_recCnt.zeroSpd_cnt<4){//����3��
                    u_fault_sta.bit.spdHighErr2 = 0;
                }
            }
        }
    }else
    {
        //��ת������������
        if((fabsf(fault_cnt.spd_errChk) < ROTORLock_speed)&&(fault_cnt.is_errChk > ROTORLock_cCUR)){
            fault_cnt.zeroSpd_cnt++;
            if(fault_cnt.zeroSpd_cnt > 200){
                u_fault_sta.bit.zeroSpd = 1;
                fault_cnt.zeroSpd_cnt = 200;
            }
        }else{
            fault_cnt.zeroSpd_cnt=0;
            if(fault_cnt.zeroSpd_cnt > 0){
                fault_cnt.zeroSpd_cnt--;
            }else{
                //u_fault_sta.bit.zeroSpd = 0;
            }
        }
    }

	//��ת
	if((fabsf(fault_cnt.spd_errChk) > SPEED_noLoadErr)&&(fault_cnt.is_errChk < CUR_noLoadErr)){
		fault_cnt.load_no_cnt++;
		if(fault_cnt.load_no_cnt>500){	//5s
			u_fault_sta.bit.load_no = 1;
			fault_cnt.load_no_cnt = 500;
		}
	}else{
		fault_cnt.load_no_cnt=0;
	}

    //2000rpm���ϲŽ��п�ת���
//    if(fabsf(fault_cnt.spd_errChk) >= 2000){
//
//        SPEED_noLoadPower = (fabsf(fault_cnt.spd_errChk) * fabsf(fault_cnt.spd_errChk) * 6.9 - 20000 * fabsf(fault_cnt.spd_errChk) + 22500000) / 100000;
//
//        if(fault_cnt.power_errChk < SPEED_noLoadPower){
//            fault_cnt.load_no_cnt++;
//            if(fault_cnt.load_no_cnt>500){  //5s
//                 u_fault_sta.bit.load_no = 1;
//                 fault_cnt.load_no_cnt = 500;
//            }
//        }else{
//            fault_cnt.load_no_cnt=0;
//        }
//
//    }else{
//        fault_cnt.load_no_cnt = 0;
//    }

	//Igbt�¶ȴ������̶�·
	if(Temp_IGBT.igbtTemp > 160 || Temp_IGBT.igbtTemp < -50){//-50
		fault_cnt.sersOpn_cnt++;
		if(fault_cnt.sersOpn_cnt > 300){	//3s
			u_fault_sta.bit.sersorOpen = 1;
			fault_cnt.sersOpn_cnt = 300;
		}
	}else{
			fault_cnt.sersOpn_cnt = 0;
	}

	//���¶ȴ��������������¼����¹���
	if((Temp_IGBT.igbtTemp < 155) && (Temp_IGBT.igbtTemp > -45))
	{
	    //IGBT����
	    if(Temp_IGBT.igbtTemp > IGBT_OTerr){
	        fault_cnt.igbt_OT_cnt++;
	        if(fault_cnt.igbt_OT_cnt>100){
	            u_fault_sta.bit.igbt_OT = 1;
                fault_cnt.igbt_OT_cnt = 100;
	        }
	    }else{
	        fault_cnt.igbt_OT_cnt = 0;
	        if(Temp_IGBT.igbtTemp < IGBT_OTrec){
	            u_fault_sta.bit.igbt_OT = 0;
	        }
	    }

	    if(Temp_IGBT.igbtTemp > IGBT_OTwarn){
	        fault_cnt.igbt_OT2_cnt++;
	        if(fault_cnt.igbt_OT2_cnt>100){
	            u_fault_sta.bit.igbt_OTwarn = 1;
	            fault_cnt.igbt_OT2_cnt = 100;
	        }
	    }else{
	        fault_cnt.igbt_OT2_cnt = 0;
	        if(Temp_IGBT.igbtTemp < IGBT_OTrec){
	            u_fault_sta.bit.igbt_OTwarn = 0;
	        }
	    }
	}


	if(fault_cnt.power_errChk>OVPWR_PUMP1){//4900w
		fault_cnt.udcoc_cnt++;
		if(fault_cnt.udcoc_cnt>200){			//2s
			u_fault_sta.bit.udc_oc = 1;
			fault_cnt.udcoc_cnt = 200;
		}
	}else if(fault_cnt.power_errChk<OVPWR_PUMP1){
		fault_cnt.udcoc_cnt = 0;
		u_fault_sta.bit.udc_oc = 0;
	}else{
		fault_cnt.udcoc_cnt = 0;
	}

	if(fault_cnt.power_errChk>OVPWR_PUMP2){//5000w
		fault_cnt.pwrWarn_cnt++;
		if(fault_cnt.pwrWarn_cnt>200){			//2s
			u_fault_sta.bit.ol = 1;
			fault_cnt.pwrWarn_cnt = 200;
		}
	}else if(fault_cnt.power_errChk<OVPWR_PUMP1){
        if(u_fault_sta.bit.ol)
        {
            fault_cnt.pwrWarn_cnt = 0;
            //u_fault_sta.bit.ol = 0;
        }
	}else{
		fault_cnt.pwrWarn_cnt = 0;
	}

//    //��������
//    if(((fault_cnt.is_errChk > OUTCURerr)&&(u_fault_sta.bit.oc==0))){
//        fault_cnt.oc_warn_cnt++;
//        if(fault_cnt.oc_warn_cnt > 3){
//            u_fault_sta.bit.oc = 1;
//            fault_cnt.oc_warn_cnt = 1000;//10s����
//            fault_cnt.oc_cnt++;
//        }
//    }else{
//        if(fault_cnt.oc_warn_cnt>0){
//            fault_cnt.oc_warn_cnt--;
//        }else{
//            if(fault_cnt.oc_cnt<4){//3��
//                u_fault_sta.bit.oc = 0;
//            }
//        }
//    }

    //����
    if(fault_cnt.is_errChk > OUTCURerr){
        fault_cnt.oc_cnt++;
        if(fault_cnt.oc_cnt > 3){
            u_fault_sta.bit.oc = 1;
            fault_cnt.oc_cnt = 4;
        }
    }else{
        fault_cnt.oc_cnt = 0;
    }


    if(Temp_IGBT.idc > UDC_CURerr){
        fault_cnt.idc_warn3_cnt++;
        if(fault_cnt.idc_warn3_cnt>3){
            u_fault_sta.bit.idc_warn=1;
            fault_cnt.idc_warn3_cnt = 4;
        }
    }else{
        fault_cnt.idc_warn3_cnt = 0;
    }


    //ȱ�����
    if( (((motorVars_M1.adcData.I_A.value[0] > (motorVars_M1.adcData.I_A.value[1] *2.0f)) || (motorVars_M1.adcData.I_A.value[0] > (motorVars_M1.adcData.I_A.value[2] *2.0f))) && (motorVars_M1.adcData.I_A.value[0] > PhaseLossCur))  ||\
        (((motorVars_M1.adcData.I_A.value[1] > (motorVars_M1.adcData.I_A.value[0] *2.0f)) || (motorVars_M1.adcData.I_A.value[1] > (motorVars_M1.adcData.I_A.value[2] *2.0f))) && (motorVars_M1.adcData.I_A.value[1] > PhaseLossCur))  ||\
        (((motorVars_M1.adcData.I_A.value[2] > (motorVars_M1.adcData.I_A.value[0] *2.0f)) || (motorVars_M1.adcData.I_A.value[2] > (motorVars_M1.adcData.I_A.value[1] *2.0f))) && (motorVars_M1.adcData.I_A.value[2] > PhaseLossCur)) ){
        //fault_cnt.phaseCnc_cnt++;
        if(fault_cnt.phaseCnc_cnt > 300){//3s
            //fault_cnt.phaseCnc_cnt = 301;
            //u_fault_sta.bit.spdLowErr2 = 1;
        }
    }else{
        //fault_cnt.phaseCnc_cnt = 0;
    }
/*
    if( (motorVars_M1.flagEnableRunAndIdentify==1)){
        fault_cnt.phaseCnc_cnt++;
        if(fault_cnt.phaseCnc_cnt > 300){//3s
            fault_cnt.phaseCnc_cnt = 301;
            u_fault_sta.bit.spdLowErr2 = 1;
        }
    }else{
        fault_cnt.phaseCnc_cnt = 0;
    }
*/
    f_temp = 3025;//�ת��50%

	if((u_fault_sta.bit.igbt_OT) || (u_fault_sta.bit.oc) ||  (u_fault_sta.bit.sersorOpen)\
			|| (u_fault_sta.bit.udc_lv)|| (u_fault_sta.bit.udc_ov)|| (u_fault_sta.bit.zeroSpd)|| (u_fault_sta.bit.ol)\
			||(u_fault_sta.bit.load_no) ||(udcLvFlgt==0) ||(motorVars_M1.faultMtrNow.bit.moduleOverCurrent) || (motorVars_M1.faultMtrNow.bit.currentOffset)\
			|| (motorVars_M1.faultMtrNow.bit.voltageOffset)  || (u_fault_sta.bit.spdHighErr2) || (u_fault_sta.bit.spdLowErr2) || (u_fault_sta.bit.idc_warn)){
            u_motor_ctrl.bit.run_enable = 0;
            vcu_speedRampCmd = 0;
			loadNc_errCnt = 0;
			can_errCnt = 0;
	}else if((u_fault_sta.bit.igbt_OTwarn == 1) || (u_fault_sta.bit.udc_oc)){//1������ 1������
		vcu_speedRampCmd = speed_ramp_cmd;//vcu_speedCmd;
		u_motor_ctrl.bit.run_enable = u_motor_ctrl.bit.enable;
		loadNc_errCnt = 0;
		can_errCnt = 0;
	}else if((u_fault_sta.bit.canErr)||(u_fault_sta.bit.checkErr)){
#if (Durable==0)
		loadNc_errCnt=0;
   		can_errCnt++;
   		if(can_errCnt<1000)//10s
   		{
   			vcu_speedRampCmd = f_temp;
   			u_motor_ctrl.bit.run_enable = u_motor_ctrl.bit.enable;
   		}else{
   			can_errCnt = 1001;
   			vcu_speedRampCmd = 0;
   			u_motor_ctrl.bit.run_enable = 0;
   		}
#else
        loadNc_errCnt=0;
        vcu_speedRampCmd = speed_ramp_cmd;
        u_motor_ctrl.bit.run_enable = u_motor_ctrl.bit.enable;
#endif
	}else{
        vcu_speedRampCmd = speed_ramp_cmd;
        u_motor_ctrl.bit.run_enable = u_motor_ctrl.bit.enable;
		loadNc_errCnt = 0;
		can_errCnt = 0;
	}
}

#endif
#endif






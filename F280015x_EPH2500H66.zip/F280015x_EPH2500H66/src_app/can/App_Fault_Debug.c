#ifndef	APP_FAULTDEBUG_C
#define	APP_FAULTDEBUG_C

#include "app_include.h"


#if (PMSM_DEBUG == 0)

extern volatile MOTOR_Vars_t motorVars_M1;

#define	UDC_OVerr	860//285     //vac
#define	UDC_OVrec	840//270     //vac
#define	UDC_LVerr	400//140     //vac
#define	UDC_LVrec	420//150     //vac

#define	UDC_CURerr	1800	//18.0		//ĸ�ߵ���������,*100
#define	UDC_CURwarn 1500	//15.0
#define	UDC_CURrec	1000	//10.0

#define	OUTCURerr	25      //A
#define	OUTCURwarn	20      //A
#define	OUTCURrec	14      //A
#define	SPEED_OS	7500	//���ٵ�

#define	SPEED_noLoadErr		3500    //RPM;	//��ת�����ʼ�ٶ�
#define	CUR_noLoadErr		0.5     //A
#define	ROTORLock_cCUR	    5       //A
#define	ROTORLock_speed		300     //RPM	//��ת�����жϵ�

#define	IGBT_OTerr		105//128		//IGBT���µ�,��
#define	IGBT_OTwarn		100//120		//IGBT���±�����,��
#define	IGBT_OTrec		95//110		//IGBT���»ָ���,��

#define	speedRevCheck	100	    //��ת�жϵ�

//��ʼ��
void  f_faultCheck_Init(void)
{
	u_fault_sta.all = 0;
	fault_cnt.canErr_cnt = 0;
	fault_cnt.igbt_OT_cnt = 0;
	fault_cnt.load_no_cnt = 0;
	fault_cnt.oc_cnt = 0;
	fault_cnt.ol_cnt = 0;
	fault_cnt.udc_lv_cnt = 0;
	fault_cnt.udc_ov_cnt = 0;
	fault_cnt.zeroSpd_cnt = 0;
	fault_cnt.os_cnt = 0;
	fault_cnt.recSpd_cnt = 0;
	fault_cnt.udcoc_cnt = 0;
	fault_cnt.phaseCnc_cnt = 0;
	fault_recCnt.zeroSpd_cnt = 0;
	fault_recCnt.load_no_cnt = 0;

    fault_cnt.udc_errChk = 0;
    fault_cnt.spd_errChk = 0;
    fault_cnt.is_errChk = 0;
    u_motor_ctrl.all = 0;
}

//���ϼ�� 10ms
void  f_faultCheck(void)
{
	//long u32_temp;
	float f_temp;
	//static unsigned int can_errCnt=0;
	//static unsigned int loadNc_errCnt=0;
	//static unsigned int oc_clrCnt=0;
	//static unsigned int udcoc_clrCnt=0;

	static unsigned int udcLvFlgt=0;

	fault_cnt.udc_errChk = motorVars_M1.adcData.VdcBus_V;
    fault_cnt.spd_errChk = motorSpd_Lpf;
    fault_cnt.is_errChk = fabsf(motorVars_M1.Is_A);

	//ĸ�߹�ѹ
	if(fault_cnt.udc_errChk  > UDC_OVerr){
		fault_cnt.udc_ov_cnt++;
		if(fault_cnt.udc_ov_cnt > 200){//2s
			//u_fault_sta.bit.udc_ov = 1;
			fault_cnt.udc_ov_cnt = 201;
		}
	}else if(fault_cnt.udc_errChk  < UDC_OVrec){
		if(u_fault_sta.bit.udc_ov == 1){
			fault_cnt.udc_ov_cnt++;
			if(fault_cnt.udc_ov_cnt > 501){		//3s recover
				fault_cnt.udc_ov_cnt = 0;
				u_fault_sta.bit.udc_ov = 0;
			}
		}else{
			fault_cnt.udc_ov_cnt = 0;
			u_fault_sta.bit.udc_ov = 0;
		}
	}

	//ĸ��Ƿѹ
	if(fault_cnt.udc_errChk  > UDC_LVerr){
		udcLvFlgt = 1;
	}
	if((udcLvFlgt==1) && (motorVars_M1.flagEnableRunAndIdentify==1)){
		if(fault_cnt.udc_errChk  < UDC_LVerr){
			fault_cnt.udc_lv_cnt++;
			if(fault_cnt.udc_lv_cnt > 200){//2s
				//u_fault_sta.bit.udc_lv = 1;
				fault_cnt.udc_lv_cnt = 201;
			}
		}else if(fault_cnt.udc_errChk  > UDC_LVrec){
			if(u_fault_sta.bit.udc_lv){
				fault_cnt.udc_lv_cnt++;
				if(fault_cnt.udc_lv_cnt > 501){		//3s recover
					fault_cnt.udc_lv_cnt = 0;
					u_fault_sta.bit.udc_lv = 0;
				}
			}else{
				fault_cnt.udc_lv_cnt = 0;
				u_fault_sta.bit.udc_lv = 0;
			}
		}
	}else{
		if(u_fault_sta.bit.udc_lv == 1){
			if(fault_cnt.udc_errChk  > UDC_LVrec){
				fault_cnt.udc_lv_cnt++;
				if(fault_cnt.udc_lv_cnt > 501){		//3s recover
					fault_cnt.udc_lv_cnt = 0;
					u_fault_sta.bit.udc_lv = 0;
				}
			}
		}else{
			fault_cnt.udc_lv_cnt = 0;
			u_fault_sta.bit.udc_lv = 0;
		}
	}

    //��ת����
    if((fabsf(fault_cnt.spd_errChk) < ROTORLock_speed)&&(fault_cnt.is_errChk > ROTORLock_cCUR)&&(u_fault_sta.bit.zeroSpd==0)){
        fault_cnt.zeroSpd_cnt++;
        if(fault_cnt.zeroSpd_cnt > 300){
            u_fault_sta.bit.zeroSpd = 1;
            fault_cnt.zeroSpd_cnt = 1000;//10s����
            fault_recCnt.zeroSpd_cnt++;
        }
    }else{
        if(fault_cnt.zeroSpd_cnt > 0){
            fault_cnt.zeroSpd_cnt--;
        }else{
            if(fault_recCnt.zeroSpd_cnt<5){//����5��
                u_fault_sta.bit.zeroSpd = 0;
            }
        }
    }

    //��ת
    if((fabsf(fault_cnt.spd_errChk) > SPEED_noLoadErr)&&(fault_cnt.is_errChk < CUR_noLoadErr)&&(u_fault_sta.bit.load_no==0)){
           fault_cnt.load_no_cnt++;
           if(fault_cnt.load_no_cnt > 300){   //3S
               //u_fault_sta.bit.load_no = 1;
               fault_cnt.load_no_cnt = 1000;    //10S
               fault_recCnt.load_no_cnt++;
        }
    }else{
        if(fault_cnt.load_no_cnt > 0){
               fault_cnt.load_no_cnt--;
        }else{
            if(fault_recCnt.load_no_cnt<5){
                u_fault_sta.bit.load_no = 0;
            }
        }
    }

	//IGBT����
	if(Temp_IGBT.igbtTemp > IGBT_OTerr){//105��
		fault_cnt.igbt_OT_cnt++;
		if(fault_cnt.igbt_OT_cnt>100){//1s
			u_fault_sta.bit.igbt_OT = 1;
			u_fault_sta.bit.igbt_OTwarn = 1;
		}
	}else if(Temp_IGBT.igbtTemp > IGBT_OTwarn){//100��
		fault_cnt.igbt_OT_cnt++;
		if(fault_cnt.igbt_OT_cnt>100){//1s
			u_fault_sta.bit.igbt_OTwarn = 1;
		}
	}else if(Temp_IGBT.igbtTemp < IGBT_OTrec){//95��
		fault_cnt.igbt_OT_cnt = 0;
		u_fault_sta.bit.igbt_OT = 0;
		u_fault_sta.bit.igbt_OTwarn = 0;
	}else{
		fault_cnt.igbt_OT_cnt = 0;
	}

    //����
    if( ( (fault_cnt.is_errChk > OUTCURerr)&&(u_fault_sta.bit.oc_warn==0)) || \
          (motorVars_M1.faultMtrNow.bit.moduleOverCurrent==1) ){
        fault_cnt.oc_warn_cnt++;
        if(fault_cnt.oc_warn_cnt > 3){
            u_fault_sta.bit.oc = 1;
            fault_cnt.oc_warn_cnt = 1000;//10s����
            fault_cnt.oc_cnt++;
        }
    }else{
        if(fault_cnt.oc_warn_cnt>0){
            fault_cnt.oc_warn_cnt--;
        }else{
            if(fault_cnt.oc_cnt<5){//5��
                u_fault_sta.bit.oc = 0;
                motorVars_M1.faultMtrNow.bit.moduleOverCurrent = 0;
                motorVars_M1.flagClearFaults = 1;
            }
        }
    }

#if   (MOTOR_NUMBER==3)||(MOTOR_NUMBER==4)||(MOTOR_NUMBER==5)
	u_fault_sta.bit.hilErr = Temp_IGBT.hvilFlg;
#endif

	f_temp = 1600;//���ת�ٵ�50%
#if MOTOR_DIR==1
	f_temp = -f_temp;
#endif

	if((u_fault_sta.bit.udc_lv) || (u_fault_sta.bit.udc_ov) || (u_fault_sta.bit.igbt_OT) || (u_fault_sta.bit.load_no) \
	        || (u_fault_sta.bit.zeroSpd) || (u_fault_sta.bit.oc) || (udcLvFlgt==0)  || (motorVars_M1.faultMtrNow.all !=0)){//
	        u_motor_ctrl.bit.run_enable = 0;
			vcu_speedRampCmd = 0;
	}else if((u_fault_sta.bit.igbt_OTwarn == 1)){
		vcu_speedRampCmd = f_temp;		//1600RPM
        u_motor_ctrl.bit.run_enable = u_motor_ctrl.bit.enable;
	}else{
		vcu_speedRampCmd = speed_ramp_cmd;
        u_motor_ctrl.bit.run_enable = u_motor_ctrl.bit.enable;
	}
}

#endif
#endif






#ifndef APP_CANSHINHOOMEGAS_C
#define APP_CANSHINHOOMEGAS_C

#include "app_include.h"


extern volatile MOTOR_Vars_t motorVars_M1;

//��׼CAN��Ϣ
#if (PMSM_DEBUG == 101)
    const Uint32 mail_id[32] = {0x300,0x4179,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,0x4180,
                                0x400,0x401,0x402,0x4192,0x4193,0x4194,0x4195,0x4196,0x4197,0x4198,
                                0x4199,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,0x4200,
                                0x4200,0x4200};

/****************************************************************************************
** ��������:  mbox1-10������;  mbox10-20������;  30:UDS BOOT rx; 31:UDS BOOT tx; 32:����
****************************************************************************************/
void  J1939_Module_Mailbox_Config(void)
{
    CAN_setupMessageObject(myCAN0_BASE, 1, mail_id[0], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_RX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 2, mail_id[1], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_RX, 0, 0,8);

    CAN_setupMessageObject(myCAN0_BASE, 11, mail_id[10], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 12, mail_id[11], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 13, mail_id[12], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 14, mail_id[13], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 15, mail_id[14], CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
}

/****************************************************************************************
** �����������ʼ��
****************************************************************************************/
void J1939_Common_Data_Init(void)
{
    unsigned int i;

    J1939_Module.u16_send_count1 = 0;  //����֡1������
    J1939_Module.u16_send_count1_flag  = 0;
    J1939_Module.u16_send_count2 = 0;   //����֡2������
    J1939_Module.u16_send_count2_flag  = 0;
    J1939_Module.u16_send_count3 = 0;   //����֡3������
    J1939_Module.u16_send_count3_flag  = 0;

    J1939_Module.flag_rece1 = 0;

    Agreement_data.MOT_SEND_CNT1 = 100 ;  //100ms
    Agreement_data.MOT_SEND_CNT2 = 100 ;  //100ms
    Agreement_data.MOT_SEND_CNT3 = 100 ;  //100ms

    for(i=0;i<8;i++){
        ReceiveFrame.CANData[i]=0;
        ReceiveFrame1.CANData[i]=0;
        SendFrame.CANData[i]=0;
    }
}

void Time_Count(void)       //10ms os
{
    static Uint16 excan_num=0;

    if(excan_num != sys_param.AddressCan){    //����CANID����
        excan_num = sys_param.AddressCan;
        if(excan_num<256){
            CAN_setupMessageObject(myCAN0_BASE, 1, (mail_id[0]+sys_param.AddressCan), CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_RX, 0, 0,8);
            CAN_setupMessageObject(myCAN0_BASE, 11, (mail_id[10]+sys_param.AddressCan*3), CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
            CAN_setupMessageObject(myCAN0_BASE, 12, (mail_id[11]+sys_param.AddressCan*3), CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
            CAN_setupMessageObject(myCAN0_BASE, 13, (mail_id[12]+sys_param.AddressCan*3), CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
        }
    }else{
        if(J1939_Module.u16_send_count1 < Agreement_data.MOT_SEND_CNT1)
        {
            J1939_Module.u16_send_count1++;
            if(J1939_Module.u16_send_count1 == Agreement_data.MOT_SEND_CNT1)
            {
                J1939_Module.u16_send_count1 = 0;
                J1939_Module.u16_send_count1_flag = 1;
            }
        }
        if(J1939_Module.u16_send_count2 < Agreement_data.MOT_SEND_CNT2)
        {
            J1939_Module.u16_send_count2++;
            if(J1939_Module.u16_send_count2 == Agreement_data.MOT_SEND_CNT2)
            {
                J1939_Module.u16_send_count2 = 0;
                J1939_Module.u16_send_count2_flag = 1;
            }
        }
        if(J1939_Module.u16_send_count3 < Agreement_data.MOT_SEND_CNT3)
        {
            J1939_Module.u16_send_count3++;
            if(J1939_Module.u16_send_count3 == Agreement_data.MOT_SEND_CNT3)
            {
                J1939_Module.u16_send_count3 = 0;
                J1939_Module.u16_send_count3_flag = 1;
            }
        }
    }
}

/****************************************************************************************
** ��������:  MOT��EVCU����
****************************************************************************************/
void Mot_Send_To_Evcu(void)   //10ms os
{
    if(J1939_Module.u16_send_count1_flag == 1)
    {
        J1939_Module.u16_send_count1_flag = 0;
        SysCanSendData(11);
    }
    if(J1939_Module.u16_send_count2_flag == 1)
    {
        J1939_Module.u16_send_count2_flag = 0;
        SysCanSendData(12);
    }
    if(J1939_Module.u16_send_count3_flag == 1)
    {
        J1939_Module.u16_send_count3_flag = 0;
        SysCanSendData(13);
    }
}

void SysCanSendData(Uint16 num)
{
    unsigned long  uIntTemp,uIntTemp1;
    Uint16 errCode,stateBase;
    static  int rollcnt346=0,rollcnt441=0,rollcnt442=0;

    if(num == 11)
    {
        uIntTemp = sci_motor_spd;
        SendFrame.CANData[0] = (uIntTemp >> 6)& 0x0FF;
        uIntTemp1 = (uIntTemp & 0x03F)<<2;

        if(sci_motor_udcVol < 35)       //35V
        {
            uIntTemp = 0;
        }else{
            uIntTemp = sci_motor_udcVol;    //udc,//0.1v�ֱ���
        }
        SendFrame.CANData[2] = uIntTemp & 0x0FF;
        uIntTemp1 = (uIntTemp >> 8) & 0x003;
        SendFrame.CANData[1] = uIntTemp + uIntTemp1;

        SendFrame.CANData[3] = sci_motor_idc;

        if(sci_motor_fault!=0){
            stateBase = 5;
        }else if(motor_runFlg_sci==1){      //����
            stateBase = 2;
        }else if(sci_motor_udcVol > 200){       //>200V��Ϊ��ѹ����
            stateBase = 0;
        }else{
            stateBase = 4;
        }
        SendFrame.CANData[4] = sci_motor_fault;
        SendFrame.CANData[5] = 0;//mcuTmpValue+40;
        SendFrame.CANData[6] = (rollcnt346 << 4) + stateBase;
        rollcnt346++;
        if(rollcnt346>15){
            rollcnt346 = 0;
        }
        uIntTemp = SendFrame.CANData[0] ^ SendFrame.CANData[1] ^ SendFrame.CANData[2] ^ SendFrame.CANData[3] ^ \
                   SendFrame.CANData[4] ^ SendFrame.CANData[5] ^ SendFrame.CANData[6];
        SendFrame.CANData[7] = uIntTemp;

        CAN_sendMessage(myCAN0_BASE, 11, 8, SendFrame.CANData);
    }
    else if(num == 12)
    {
        SendFrame.CANData[0] = sci_motor_igbtT + 40;        //ctrl TEMPE
        SendFrame.CANData[1] = (Uint16)(temperature + 40);      //NTC TEMPE
        SendFrame.CANData[2] = HW_VER_NUMBER;
        SendFrame.CANData[3] = SW_VER_NUMBER;
        SendFrame.CANData[4] = sci_motor_hardVer;
        SendFrame.CANData[5] = sci_motor_softVer;
        SendFrame.CANData[6] = (rollcnt441 << 4);
        rollcnt441++;
        if(rollcnt441>15){
            rollcnt441 = 0;
        }
        uIntTemp = SendFrame.CANData[0] ^ SendFrame.CANData[1] ^ SendFrame.CANData[2] ^ SendFrame.CANData[3]^\
                   SendFrame.CANData[4] ^ SendFrame.CANData[5] ^ SendFrame.CANData[6];
        SendFrame.CANData[7] = uIntTemp;

        CAN_sendMessage(myCAN0_BASE, 12, 8, SendFrame.CANData);
    }
    else if(num == 13)
    {
        uIntTemp = sci_motor_flow;
        SendFrame.CANData[0] = (uIntTemp>>1) & 0x0FF;
        uIntTemp1 = (uIntTemp & 0x01) << 7;
        uIntTemp = sci_motor_lift;
        SendFrame.CANData[2] = uIntTemp & 0x0FF;
        SendFrame.CANData[1] = uIntTemp1 + ((uIntTemp>>8) & 0x0FF);

        uIntTemp = sci_motor_power;
        SendFrame.CANData[3] = (uIntTemp>>8) & 0x0FF;
        SendFrame.CANData[4] = uIntTemp & 0x0FF;
        SendFrame.CANData[5] = (Uint16)(tempeMediumEx+40);      //NTC2 TEMPE
        SendFrame.CANData[6] = rollcnt442;
        rollcnt442++;
        if(rollcnt442>15){
            rollcnt442=0;
        }
        uIntTemp = SendFrame.CANData[0] ^ SendFrame.CANData[1] ^ SendFrame.CANData[2] ^ SendFrame.CANData[3]^\
                           SendFrame.CANData[4] ^ SendFrame.CANData[5] ^ SendFrame.CANData[6];
        SendFrame.CANData[7] = uIntTemp;

        CAN_sendMessage(myCAN0_BASE, 13, 8, SendFrame.CANData);
    }
}

//���մ���
void  Mot_Receive_From_Evcu(void)   //200us
{
    unsigned int i;
    if( (CAN_readMessage(myCAN0_BASE, 1, rxMsgData)) && (J1939_Module.flag_rece1 == 0) )
     {
        for(i=0;i<8;i++){
            ReceiveFrame.CANData[i] = rxMsgData[i];
        }
        J1939_Module.flag_rece1 = 1;
     }
     if( (CAN_readMessage(myCAN0_BASE, 2, rxMsgData)) && (J1939_Module.flag_rece2 == 0) )
     {
        for(i=0;i<8;i++){
            ReceiveFrame1.CANData[i] = rxMsgData[i];
        }
        J1939_Module.flag_rece2 = 1;
     }
}

void Evcu_Receive_Process(void)     //10ms os
{
    long u32_temp;
    static int rollcntbak=0;
    static int rollcntFlg=0;
    int rollcntOK;

    static int canErrtime=0;
    static int checkErrCnt=0;

    canErrtime++;
    if(canErrtime>1000){        //10s
        canErrtime = 1000;
        u_fault_sta.bit.canErr = 1;
    }else{
        u_fault_sta.bit.canErr = 0;
    }

    if(J1939_Module.flag_rece1 == TRUE)
    {
        canErrtime = 0;
        if(rollcntFlg == 0){
            rollcntbak = ReceiveFrame.CANData[2] >> 4;
            rollcntOK = 1;
            rollcntFlg = 1;
        }else{
            rollcntFlg = 1;
            u32_temp = ReceiveFrame.CANData[2] >> 4;
            if((u32_temp == (rollcntbak + 1)) || (rollcntbak == 15)&&(u32_temp==0)){
                rollcntOK = 1;
            }else{
                rollcntOK = 0;
            }
            rollcntbak = ReceiveFrame.CANData[2] >> 4;
        }

        u32_temp = (ReceiveFrame.CANData[0]) ^ (ReceiveFrame.CANData[1]) ^ (ReceiveFrame.CANData[2])\
                ^ (ReceiveFrame.CANData[3]) ^ (ReceiveFrame.CANData[4]);
#if CRC_FLG==0
        if(1){
#else
        if((u32_temp == ReceiveFrame.CANData[5])&&(rollcntOK==1)){
#endif
            u32_temp=(ReceiveFrame.CANData[0] << 2) + (ReceiveFrame.CANData[1]>>6);
            if((((ReceiveFrame.CANData[2])&0x03) == 2) || (((ReceiveFrame.CANData[2])&0x03) == 3)){
                u_motor_ctrl.bit.enableCAN = 1;
            }else{
                u32_temp = 0;
                u_motor_ctrl.bit.enableCAN = 0;
            }

            if(u32_temp>1000){
                u32_temp = 1000;        //100.0%
            }
#if MOTOR_DIR==1        //310
            vcu_speedDirCmd = -1;
#else
            vcu_speedDirCmd = 1;
#endif
            vcu_speedCmd = u32_temp;
            u_speed_can = vcu_speedCmd;
            u_fault_sta.bit.checkErr = 0;
        }else{
            checkErrCnt++;
            if(checkErrCnt > 10){
                u_fault_sta.bit.checkErr = 1;
                checkErrCnt = 10;
            }else{
            }
        }
        J1939_Module.flag_rece1 = 0;
    }
}

#endif

#endif



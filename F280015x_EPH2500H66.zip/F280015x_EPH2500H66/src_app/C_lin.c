/*
 * C_lin.c
 *
 *  Created on: 2024��9��27��
 *      Author: shujixiang
 */

#ifndef SRC_APP_LIN_C_
#define SRC_APP_LIN_C_

#include <app_include.h>


volatile uint32_t level0Count = 0;
volatile uint32_t level1Count = 0;
volatile uint32_t vectorOffset = 0;

uint16_t txData[8] = {0x11, 0x34, 0x56, 0x78, 0x9A, 0xAB, 0xCD, 0xEF};
uint16_t rxData[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

unsigned char u8_SIDData[3]={0x3c,0x3d,0};

#pragma CODE_SECTION(level0ISR, ".TI.ramfunc");
#pragma CODE_SECTION(level1ISR, ".TI.ramfunc");
//
// Function Prototypes
//
__interrupt void level0ISR(void);
__interrupt void level1ISR(void);


void Lin_init()
{
    level0Count = 0;
    level1Count = 0;
    vectorOffset = 0;
}


void Lin_Deal()
{
    long  tempLin,tempLin2;

    if(level1Count==1){
        level1Count = 0;
        if((rxData[0]==0x14) && (rxData[1]==0x01)){
            if((rxData[3]==0x50)&&(rxData[2]==0x07)&&(rxData[6]==0x0FF)&&(rxData[7]==0x00)){
                txData[0]=0x50;
                if(rxData[4]==0x00){      //�汾�Ŷ�ȡ
                    txData[1]=0x00;
                    txData[2]=boot_ver;
                    txData[3]=SW_VER_NUMBER;
                    txData[4]=u8_SIDData[0];
                    txData[5]=u8_SIDData[1];
                    txData[6]=LIN_ID_COMMREC;
                    txData[7]=LIN_ID_COMMSEND;
                }else if(rxData[4]==0x01){    //��ѹ���������¶ȶ�ȡ
                    txData[1]=0x01;
                    txData[2] = 0;//((unsigned int)drvFOC.f16Udcb) >> 8;    //UDC
                    txData[3] = 0;//((unsigned int)drvFOC.f16Udcb) & 0x0FF;
                    txData[4] = 0;//meas.measured.f16Idcb.filt >> 8;
                    txData[5] = 0;     //meas.measured.f16Idcb.filt & 0x0FF;
                    txData[6] = 0;//meas.measured.f16Temp.filt >> 8;
                    txData[7] = 0;//meas.measured.f16Temp.filt & 0x0FF;
                }else if(rxData[4]==0x02){    //״̬�����ϣ��ٶ�ֵ��ȡ
                    txData[1]=0x02;
                    txData[2] = 0;//permFaults.stateMachine.R >> 8;
                    txData[3] = 0;//permFaults.stateMachine.R & 0x0FF;
                    txData[4] = 0;//permFaults.motor.R >> 8;
                    txData[5] = 0;//permFaults.motor.R  & 0x0FF;
                    txData[6] = 0;//permFaults.mcu.R >> 8;
                    txData[7] = 0;//permFaults.mcu.R & 0x0FF;
                }else if(rxData[4]==0x03){    //�ٶ�ֵ,���ʣ�VS��ȡ
                    txData[1]=0x03;
                    tempLin = 0;//drvFOC.pospeControl.wRotEl/MOTOR_PP_SHIFT;
                    txData[2] = tempLin >> 8;
                    txData[3] = tempLin & 0x0FF;
                    txData[4] = 0;//outpower>>8;
                    txData[5] = 0;//outpower&0x0FF;
                    tempLin = 0;
                    txData[6] = tempLin>>8;
                    txData[7] = tempLin & 0x0FF;
                }else if(rxData[4]==0x04){    //id,id_fbk,iq��ȡ
                    txData[1]=0x04;
                    tempLin = 0;//drvFOC.iDQReq.f16Arg1;    //id
                    txData[2] = tempLin >> 8;
                    txData[3] = tempLin & 0x0FF;
                    tempLin = 0;//drvFOC.iDQFbck.f16Arg1;   //id_fbk
                    txData[4] = tempLin>>8;
                    txData[5] = tempLin&0x0FF;
                    tempLin = 0;//drvFOC.iDQReq.f16Arg2;    //iq
                    txData[6] = tempLin>>8;
                    txData[7] = tempLin & 0x0FF;
                }else if(rxData[4]==0x05){    //iq_fbk,vd,vq��ȡ
                    txData[1]=0x05;
                    tempLin = 0;//drvFOC.iDQFbck.f16Arg2;   //iq_fbk
                    txData[2] = tempLin >> 8;
                    txData[3] = tempLin & 0x0FF;
                    tempLin = 0;//drvFOC.uDQReq.f16Arg1;    //vd
                    txData[4] = tempLin>>8;
                    txData[5] = tempLin&0x0FF;
                    tempLin = 0;//drvFOC.uDQReq.f16Arg2;    //vq
                    txData[6] = tempLin>>8;
                    txData[7] = tempLin & 0x0FF;
                }else if(rxData[4]==0x06){
                    txData[1]=0x06;
                    tempLin = 0;//drvFOC.SpeedLoop.pPIpAWQ.f16PropGain; //kp_spd
                    txData[2] = tempLin >> 8;
                    txData[3] = tempLin & 0x0FF;
                    tempLin = 0;//drvFOC.SpeedLoop.pPIpAWQ.f16IntegGain;    //ki_spd
                    txData[4] = tempLin>>8;
                    txData[5] = tempLin&0x0FF;
                    tempLin = 0;//drvFOC.CurrentLoop.pPIrAWD.f16CC1sc;  //id_kp
                    txData[6] = tempLin>>8;
                    txData[7] = tempLin & 0x0FF;
                }else if(rxData[4]==0x07){
                    txData[1]=0x07;
                    tempLin = 0;//drvFOC.CurrentLoop.pPIrAWD.f16CC2sc;  //id_ki
                    txData[2] = 0;//tempLin >> 8;
                    txData[3] = tempLin & 0x0FF;
                    tempLin = 0;//drvFOC.CurrentLoop.pPIrAWQ.f16CC1sc;  //iq_kp
                    txData[4] = tempLin>>8;
                    txData[5] = tempLin&0x0FF;
                    tempLin = 0;//drvFOC.CurrentLoop.pPIrAWQ.f16CC2sc;  //iq_ki
                    txData[6] = tempLin>>8;
                    txData[7] = tempLin & 0x0FF;
                }else if(rxData[4]==0x08){
                    txData[1]=0x08;
                    tempLin = 0;//drvFOC.iDQFbck.f16Arg1;   //is
                    tempLin = 0;//tempLin*drvFOC.iDQFbck.f16Arg1;
                    tempLin2 = 0;//drvFOC.iDQFbck.f16Arg2;
                    tempLin2 = 0;//tempLin2*drvFOC.iDQFbck.f16Arg2;
                    tempLin = tempLin + tempLin2;
                    txData[2] = tempLin >> 8;
                    txData[3] = tempLin & 0x0FF;

                    tempLin = 0;//drvFOC.uDQReq.f16Arg1;        //vs
                    tempLin = 0;//tempLin*drvFOC.uDQReq.f16Arg1;
                    tempLin2 = 0;//drvFOC.uDQReq.f16Arg2;
                    tempLin2 = 0;//tempLin2*drvFOC.uDQReq.f16Arg2;
                    tempLin = tempLin + tempLin2;
                    txData[4] = tempLin>>8;
                    txData[5] = tempLin&0x0FF;
                    tempLin = 0;
                    txData[6] = tempLin>>8;
                    txData[7] = tempLin & 0x0FF;
                }else{      //Ĭ��Ϊ�汾���ϴ�
                    txData[1]=0x00;
                    txData[2]=boot_ver;
                    txData[3]=SW_VER_NUMBER;
                    txData[4]=u8_SIDData[0];
                    txData[5]=u8_SIDData[1];
                    txData[6]=LIN_ID_COMMREC;
                    txData[7]=LIN_ID_COMMSEND;
                }
            }else if((rxData[3]==0x60)&&(rxData[2]==0x08)&&(rxData[7]==0x0FF)){
                  u_speed_lin = ((rxData[4]<<8) + rxData[5]);
                  u_sci_enable.bit.lin_enable = (rxData[6]>>1) & 0x01;
                  if((rxData[6]&0x01)==1){
                        //cntrState.usrControl.btSpeedDown=0;
                        //cntrState.usrControl.btSpeedUp=1;
                  }else{
                        //cntrState.usrControl.btSpeedDown=1;
                        //cntrState.usrControl.btSpeedUp=0;
                  }
            }
        }
    }
    if(level1Count==2){
        level1Count = 0;
        u_speed_lin = ((rxData[3]<<8) + rxData[4]);
        u_sci_enable.bit.lin_enable = (rxData[5]>>1) & 0x01;
    }
}



//�ӻ����ͷ���
__interrupt void
level0ISR(void)
{
    if(LIN_getRxIdentifier(LINA_BASE)==LIN_ID_DIAGSEND_CRC){
        LIN_sendData(LINA_BASE, txData);
    }else if(LIN_getRxIdentifier(LINA_BASE)==LIN_ID_COMMSEND_CRC){
        txData[0]=0x00; //��ѹ��
        txData[1]=0x00; //��ѹ��
        txData[2]=0x00; //�¶�
        txData[3]=0x00; //�ٶȸ�
        txData[4]=0x00; //�ٶȵ�
        txData[5]=0x00; //����ת
        txData[6]=0x00; //���ϸ�
        txData[7]=0x00; //���ϵ�
        LIN_sendData(LINA_BASE, txData);
    }

    vectorOffset = LIN_getInterruptLine0Offset(LINA_BASE);
    LIN_clearInterruptStatus(LINA_BASE, LIN_INT_ALL);
    LIN_clearGlobalInterruptStatus(LINA_BASE, LIN_INTERRUPT_LINE0);

    // Acknowledge this interrupt located in group 6
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP6);
}

/**********************************************************/
//���շ���
__interrupt void
level1ISR(void)
{

    if(LIN_getRxIdentifier(LINA_BASE)==LIN_ID_DIAGREC_CRC){   //������������
        LIN_getData(LINA_BASE,rxData);
        level1Count=1;
    }else if(LIN_getRxIdentifier(LINA_BASE)==LIN_ID_COMMREC){
        LIN_getData(LINA_BASE,rxData);
        level1Count=2;
    }

    // Read the low priority interrupt vector
    vectorOffset = LIN_getInterruptLine1Offset(LINA_BASE);
    LIN_clearInterruptStatus(LINA_BASE, LIN_INT_ALL);
    LIN_clearGlobalInterruptStatus(LINA_BASE, LIN_INTERRUPT_LINE1);

    // Acknowledge this interrupt located in group 6
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP6);
}


#endif




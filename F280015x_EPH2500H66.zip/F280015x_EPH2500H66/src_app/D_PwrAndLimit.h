
#ifndef APP_PWRANDLIMIT_H_
#define APP_PWRANDLIMIT_H_

typedef  struct	sPID
{
	float  kp;
	float  ki;
	float  integral_sum;
	float  outlimit_upper;
	float  outlimit_lower;
	float  out_value;
	float  integral_max;
	float  power_max;
}_sPID_;


#ifdef  APP_PWRANDLIMIT_C_
    #define APP_PWRANDLIMIT
#else
    #define APP_PWRANDLIMIT  extern
#endif


APP_PWRANDLIMIT void powerAndLmtInit();
APP_PWRANDLIMIT float pmsm_pi_controller(float given, float feedback, _sPID_ *pid);
APP_PWRANDLIMIT void powerCal();

APP_PWRANDLIMIT struct  sPID    sPID_pwrLmt;
APP_PWRANDLIMIT struct  sPID    sPID_liquidLmt;
APP_PWRANDLIMIT float outpower;
APP_PWRANDLIMIT float outpowerCal_k;


#endif /* APP_PWRANDLIMIT_H_ */


#ifndef APP_SPEEDRAMP_H_
#define APP_SPEEDRAMP_H_

#if USER_MOTOR1 == ep25_40w_motor
#define     UP_STEP_SPEED     12
#define     DOWN_STEP_SPEED   12
#elif USER_MOTOR1 == ep220_400w_motor
#define     UP_STEP_SPEED     3
#define     DOWN_STEP_SPEED   3
#elif USER_MOTOR1 == BOSCH_C250_5000w_motor
#define     UP_STEP_SPEED     50
#define     DOWN_STEP_SPEED   50
#elif USER_MOTOR1 == BOSCH_C190_2500w_motor
#define     UP_STEP_SPEED     50
#define     DOWN_STEP_SPEED   50
#else
#define     UP_STEP_SPEED     50
#define     DOWN_STEP_SPEED   50
#endif

#define min(a,b)                (((a) < (b)) ? (a) : (b))
#define max(a,b)                (((a) > (b)) ? (a) : (b))


#ifdef  APP_SPEEDRAMP_C_
    #define APP_SPEEDRAMP
#else
    #define APP_SPEEDRAMP  extern
#endif

APP_SPEEDRAMP void speedRamp();
APP_SPEEDRAMP void LinearRamp(float cmd, float* ref, float upStep, float downStep, float upLimit, float downLimit);
APP_SPEEDRAMP void speedRamp_init();

APP_SPEEDRAMP float speed_ramp_cmd;

#endif /* APP_SPEEDRAMP_H_ */

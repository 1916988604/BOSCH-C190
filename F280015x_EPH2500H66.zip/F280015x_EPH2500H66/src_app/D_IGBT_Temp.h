
#ifndef APP_IGBT_TEMP_H_
#define APP_IGBT_TEMP_H_

#define     IGBT_TEMPSENSOR     0       //0:ptc;    1:ntc

typedef  struct	TEMP_CAL
{
	float  igbtTemp;
	unsigned int  igbtFiltCnt;
	float  igbtAdcData;

	float  idc;
	unsigned int  idcFiltCnt;
	float  idcAdcData;

	float  ntcTemp;
	unsigned int  ntcFiltCnt;
	float  ntcAdcData;

	float	hvilFlg;
	unsigned int  hvilFiltCnt;
	float  hvilAdcData;

    float   V_LN;
    unsigned int  vLNCnt;
    float   V_LNFlg;
    float   V_LN_Lpf;
    unsigned int  vLNCntLpf;
    float   V_LNFlgLpf;
}_TEMP_CAL_;


#ifdef  APP_IGBT_TEMP_C
    #define APP_IGBT_TEMP
#else
    #define APP_IGBT_TEMP  extern
#endif

APP_IGBT_TEMP struct	TEMP_CAL	Temp_IGBT;
APP_IGBT_TEMP void f_igbtTemp_Cal(void);
APP_IGBT_TEMP void f_igbtTemp_Init(void);


#endif /* APP_IGBT_TEMP_H_ */

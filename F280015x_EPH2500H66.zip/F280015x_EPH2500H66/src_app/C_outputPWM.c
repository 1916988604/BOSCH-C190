
//���PWM����

#ifndef SRC_APP_OUTPUTPWM_C_
#define SRC_APP_OUTPUTPWM_C_

#include "app_include.h"
#include "board.h"
LINE_STRUCT aoLine = LINE_STRTUCT_DEFALUTS;
/*************************************************************************************************/
//���������outpower��motor_err_sci��motor_runFlg_sci,motor_warnStop_sci,motor_warnFlg_sci
//������Դ��������SCIͨѶ����

//���������u16PWMSta
//������Դ����ʾ��SCIͨѶ����

//�����PWM�ź�
/*************************************************************************************************/
 void outPwmInit(void)
 {
     motor_err_sci = 0;
     motor_runFlg_sci = 0;
     motor_warnStop_sci = 0;
     motor_warnFlg_sci = 0;
 }

void outPwm(void)
{

    float tmpAo;
    float outCoeff;

#if   SCI_DtoC_EN==0
    sci_motor_power = (Uint16)motorPwr_Lpf;
    sci_motor_flow = var_QH_cal.Q_pump;
    sci_motor_lift = var_QH_cal.H_pump;
    sci_motor_spd = (Uint16)motorSpd_Lpf;
#endif

    if(debug_cmd.debugEn == 1){
        outCoeff = debug_cmd.PWMoutValue;
    }
#if PWMOUT_MODE_NUM==0
    else if(motor_err_sci == 1){
        outCoeff = 90;
    }else if(motor_runFlg_sci == 0){
        outCoeff = 95;
    }else if(motor_warnStop_sci == 1){      //һֱ��Ч
        outCoeff = 85;
    }else if(motor_warnFlg_sci == 1){
        outCoeff = 70;
    }
#else
    else if(fault_recCnt.load_no_cnt>3){  //����3�κ�
        outCoeff = 2;
    }else if(fault_cnt.oc_cnt>3){      //����3�κ�
        outCoeff = 6;
    }else if(fault_recCnt.zeroSpd_cnt>3){ //��ת3�κ�
        outCoeff = 21;
    }else if(((fault_recCnt.load_no_cnt>0)&&(fault_recCnt.load_no_cnt<=3)) || \
            ((fault_cnt.oc_cnt>0)&&(fault_cnt.oc_cnt<=3))                  || \
            ((fault_recCnt.zeroSpd_cnt>0)&&(fault_recCnt.zeroSpd_cnt<=3))){        //����\��������\��תǰ3��
        outCoeff = 80;
    }else if((u_fault_sta.bit.igbt_OT == 1) || (u_fault_sta.bit.igbt_OTwarn == 1)){//����ͣ��
        outCoeff = 26;
    }else if(u_fault_sta.bit.udc_lv == 1){//Ƿѹ
        outCoeff = 11;
    }else if(u_fault_sta.bit.udc_ov == 1){//��ѹ
        outCoeff = 16;
    }else if((pwmInEnable==0) && (u_fault_sta.all==0) && (motorVars_M1.faultMtrNow.all==0)){//�����޹���
        outCoeff = 29;
    }
#endif
    else{
        aoLine.mode = 0;    // ���޷�
        aoLine.x1 = 0;
        if(pwmOutMode == PWR_OUT_STA){
            aoLine.y1 = 0;
            aoLine.y2 = 70;
            aoLine.x2 = AO_PWM_PWR_MAX;
            aoLine.x = sci_motor_power;
        }else if(pwmOutMode == Q_OUT_STA){
            aoLine.y1 = 0;
            aoLine.y2 = 70;
            aoLine.x2 = AO_PWM_Q_MAX;
            aoLine.x = sci_motor_flow;
        }else if(pwmOutMode == H_OUT_STA){
            aoLine.y1 = 0;
            aoLine.y2 = 70;
            aoLine.x2 = AO_PWM_H_MAX;
            aoLine.x = sci_motor_lift;
        }else if(pwmOutMode == SPEED_OUT_STA){
            aoLine.y1 = 30;
            aoLine.y2 = 80;
            aoLine.x2 = AO_PWM_SPEED_MAX;
            aoLine.x = fabsf(motorSpd_Lpf);
        }else{
            aoLine.y1 = 0;
            aoLine.y2 = 70;
            aoLine.x2 = AO_PWM_H_MAX;
            aoLine.x = sci_motor_lift;
        }

        aoLine.calc(&aoLine);
        outCoeff = (Uint16)aoLine.y;
    }

    if(outCoeff>100){
        outCoeff = 100;
    }else if(outCoeff<0){
        outCoeff = 0;
    }
    outCoeff = 100-outCoeff;
    tmpAo = (outCoeff * AO_PWM_PERIOD)/100;
    EPWM_setCounterCompareValue(myEPWM0_BASE, EPWM_COUNTER_COMPARE_A, (Uint16)tmpAo);  // ��һ������Ч
    EPWM_setCounterCompareValue(myEPWM0_BASE, EPWM_COUNTER_COMPARE_B, (Uint16)tmpAo);  // ��һ������Ч
}


#endif /* SRC_APP_OUTPUTPWM_C_ */

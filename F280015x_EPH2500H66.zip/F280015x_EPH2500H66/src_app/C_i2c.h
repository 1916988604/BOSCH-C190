
#ifndef SRC_APP_C_I2C_H_
#define SRC_APP_C_I2C_H_

#include "gpio.h"


#ifdef  SRC_APP_I2C_C_
    #define SRC_APP_I2C_C
#else
    #define SRC_APP_I2C_C  extern
#endif

SRC_APP_I2C_C void Delay_us(unsigned int i); //n us ��ʱ
SRC_APP_I2C_C void I2CStart(void);          //��ʼ
SRC_APP_I2C_C void I2Cask(void);            //Ӧ��
SRC_APP_I2C_C void I2CStop(void);           //ֹͣ
SRC_APP_I2C_C void I2CWrByte(unsigned char oneByte);            //дһ���ֽ�
SRC_APP_I2C_C void pwDisplay(uint8_t pwaddr,uint8_t pwdata);    //��ʾ
SRC_APP_I2C_C unsigned char ScanKey(void); //������
SRC_APP_I2C_C void SmgDisplay(void);        //��ʾ


#endif /* SRC_APP_C_I2C_H_ */





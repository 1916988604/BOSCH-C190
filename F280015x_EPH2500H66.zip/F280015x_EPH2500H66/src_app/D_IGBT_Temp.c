#ifndef	APP_IGBT_TEMP_C
#define	APP_IGBT_TEMP_C

#include "app_include.h"
Uint16 tempZero= 1104;   //idc offest
/*************************************************************************************************/
//���������Temp_IGBT.igbtAdcData�� Temp_IGBT.ntcAdcData�� Temp_IGBT.idcAdcData�� Temp_IGBT.hvilAdcData
//������Դ��������AD�������

//�����Temp_IGBT.igbtTemp�� Temp_IGBT.idc�� Temp_IGBT.ntcTemp�� Temp_IGBT.hvilFlg
/*************************************************************************************************/
// CRM60 IPM�Ĳ�������DSP������ѹ���¶ȵĶ�Ӧ��ϵ����3V��׼
/*const Uint16 voltageTempCRM60[] =
{// ��ѹmV      �¶ȡ�
     451 ,   //  0
     542 ,   //  4
     632 ,   //  8
     723 ,   //  12
     813 ,   //  16
     903 ,   //  20
     994 ,   //  24
     1084    ,   //  28
     1175    ,   //  32
     1265    ,   //  36
     1355    ,   //  40
     1446    ,   //  44
     1536    ,   //  48
     1627    ,   //  52
     1717    ,   //  56
     1807    ,   //  60
     1898    ,   //  64
     1988    ,   //  68
     2079    ,   //  72
     2169    ,   //  76
     2259    ,   //  80
     2350    ,   //  84
     2440    ,   //  88
     2531    ,   //  92
     2621    ,   //  96
     2711    ,   //  100
     2802    ,   //  104
     2892    ,   //  108
     2983    ,   //  112
     3073    ,   //  116
     3163    ,   //  120
     3254    ,   //  124
     3344    ,   //  128
     3435    ,   //  132
     3525    ,   //  136
     3615    ,   //  140
     3706    ,   //  144
     3796    ,   //  148
     3887    ,   //  152
     3977    ,   //  156
     4067    ,   //  160
};*/

// CRM60 IPM�Ĳ�������DSP������ѹ���¶ȵĶ�Ӧ��ϵ����3.3V��׼
const Uint16 voltageTempCRM60[] =
{// ��ѹmV      �¶ȡ�
    410 ,   //  0   1
    493 ,   //  4   2
    575 ,   //  8   3
    657 ,   //  12  4
    739 ,   //  16  5
    821 ,   //  20  6
    903 ,   //  24  7
    986 ,   //  28  8
    1068    ,   //  32  9
    1150    ,   //  36  10
    1232    ,   //  40  11
    1314    ,   //  44  12
    1397    ,   //  48  13
    1479    ,   //  52  14
    1561    ,   //  56  15
    1643    ,   //  60  16
    1725    ,   //  64  17
    1807    ,   //  68  18
    1890    ,   //  72  19
    1972    ,   //  76  20
    2054    ,   //  80  21
    2136    ,   //  84  22
    2218    ,   //  88  23
    2301    ,   //  92  24
    2383    ,   //  96  25
    2465    ,   //  100 26
    2547    ,   //  104 27
    2629    ,   //  108 28
    2711    ,   //  112 29
    2794    ,   //  116 30
    2876    ,   //  120 31
    2958    ,   //  124 32
    3040    ,   //  128 33
    3122    ,   //  132 34
    3204    ,   //  136 35
    3287    ,   //  140 36
    3369    ,   //  144 37
    3451    ,   //  148 38
    3533    ,   //  152 39
    3615    ,   //  156 40
    3698    ,   //  160 41
};


void  f_igbtTemp_Init(void)
{
	Temp_IGBT.igbtTemp = 25;
	Temp_IGBT.ntcTemp = 25;
	Temp_IGBT.idc = 0;
	Temp_IGBT.hvilFlg = 0;
	Temp_IGBT.hvilFiltCnt = 0;

	Temp_IGBT.igbtAdcData = 1003;//1003:25��;
	Temp_IGBT.ntcAdcData= 714;   //714:25��;
	Temp_IGBT.idcAdcData = 1104; //��Ư 1104:0.89V;
    Temp_IGBT.hvilAdcData = 0;

    Temp_IGBT.V_LN = 0;
    Temp_IGBT.vLNCnt = 0;
}

//extern float uln_data[21];
void  f_igbtTemp_Cal(void)		//10ms
{
    float temp;
	static float IGBT_Temp[5]={0,0,0,0,0};
	static int tempZeroFlg=0;
#if PCBA_TYPE == driverES_PCBA
    const Uint16 *p;
    Uint16 size;

    //ģ���¶�
    p = voltageTempCRM60;
    size = sizeof(voltageTempCRM60);
    temp = GetTemperatureCalc(aiDeal[0], p, size, 2);
    IGBT_Temp[0] = IGBT_Temp[0] * 0.9 + temp * 0.1;
    if(IGBT_Temp[0] < 0){
        IGBT_Temp[0] = 0;
    }

    Temp_IGBT.igbtTemp = IGBT_Temp[0];
    Temp_IGBT.V_LN = aiDeal[1] / 4095;
    Temp_IGBT.V_LN = Temp_IGBT.V_LN * 3.3;
    Temp_IGBT.V_LN = Temp_IGBT.V_LN / 0.0066;//0.006622517

    if(u16_PreRelaySta.bit.pfcCtrlOn == 1){//PFC����
        Temp_IGBT.V_LN = Temp_IGBT.V_LN * 1.1;
    }else{
        Temp_IGBT.V_LN = Temp_IGBT.V_LN / 1.41;
    }

    if(motorVars_M1.adcData.VdcBus_V<1){
        Temp_IGBT.idc = 0;
    }else{
        //IGBT_Temp[2] = motorVars_M1.Irms_A[0];
        //IGBT_Temp[2] = IGBT_Temp[2]*motorVars_M1.Vs_V;
        //IGBT_Temp[2] = IGBT_Temp[2]/motorVars_M1.adcData.VdcBus_V;
        IGBT_Temp[2] = motorPwr_Lpf;
        IGBT_Temp[2] = IGBT_Temp[2] / (Temp_IGBT.V_LN + 30) * 1.03;
        Temp_IGBT.idc = IGBT_Temp[2] *100;
    }

#elif PCBA_TYPE == driverC250_PCBA
    Temp_IGBT.igbtAdcData = aiDeal[0];
    Temp_IGBT.idcAdcData  = aiDeal[2];
    Temp_IGBT.ntcAdcData  = aiDeal[1];

    if(Temp_IGBT.igbtAdcData > 1146){
        Temp_IGBT.igbtTemp = -40;
    }else if(Temp_IGBT.igbtAdcData > 1140){               //-40 - (-30)
        temp = -178 * Temp_IGBT.igbtAdcData + 200100;
        temp = temp/100;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 1123){               //-30 - (-15)
        temp = -950 * Temp_IGBT.igbtAdcData + 1053900;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 1093){               //0 - (-15)
        temp = -509 * Temp_IGBT.igbtAdcData + 557900;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 998){               //0 - 25
        temp = -266 * Temp_IGBT.igbtAdcData + 292100;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData> 839){               //25 - 50
        temp = -158 * Temp_IGBT.igbtAdcData + 184200;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 527){               //50 - 90
        temp = -127 * Temp_IGBT.igbtAdcData + 158000;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 336){               //90 - 120
        temp = -156 * Temp_IGBT.igbtAdcData + 173500;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 210){                //120 - 150
        temp = -236 * Temp_IGBT.igbtAdcData + 200600;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 143){                //150 - 175
        temp = -372 * Temp_IGBT.igbtAdcData + 229500;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 101){                //175 - 200
        temp = -571 * Temp_IGBT.igbtAdcData + 258400;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else{
        Temp_IGBT.igbtTemp = 200;
    }

/*
    //�¶ȱ궨(IGBT��·ʵ��)
      if(Temp_IGBT.igbtAdcData>1151){
        Temp_IGBT.igbtTemp = -60;
    }else if(Temp_IGBT.igbtAdcData > 1150){               //-60 - (-50)
        temp = -547 * Temp_IGBT.igbtAdcData + 624140;
        temp = temp/100;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 1146){               //-50 - (-40)
        temp = -303 * Temp_IGBT.igbtAdcData + 343480;
        temp = temp/100;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 1140){               //-40 - (-30)
        temp = -178 * Temp_IGBT.igbtAdcData + 200100;
        temp = temp/100;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 1123){               //-30 - (-15)
        temp = -950 * Temp_IGBT.igbtAdcData + 1053900;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 1093){               //0 - (-15)
        temp = -509 * Temp_IGBT.igbtAdcData + 557900;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 998){               //0 - 25
        temp = -226 * Temp_IGBT.igbtAdcData + 292100;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData> 839){               //25 - 50
        temp = -158 * Temp_IGBT.igbtAdcData + 184200;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 527){               //50 - 90
        temp = -127 * Temp_IGBT.igbtAdcData + 158000;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 336){               //90 - 120
        temp = -156 * Temp_IGBT.igbtAdcData + 173500;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 210){                //120 - 150
        temp = -236 * Temp_IGBT.igbtAdcData + 200600;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 143){                //150 - 175
        temp = -372 * Temp_IGBT.igbtAdcData + 229500;
        temp = temp/1000;
        temp_IGBT.igbtTemp = (int)temp;
    }else if(Temp_IGBT.igbtAdcData > 101){                //175 - 200
        temp = -571 * Temp_IGBT.igbtAdcData + 258400;
        temp = temp/1000;
        Temp_IGBT.igbtTemp = (int)temp;
    }else{
        Temp_IGBT.igbtTemp = 200;
    }
*/
    IGBT_Temp[0] = IGBT_Temp[0] * 7 + Temp_IGBT.igbtTemp * 3;
    IGBT_Temp[0] = IGBT_Temp[0]/10;

    if(IGBT_Temp[0] < -40){
        IGBT_Temp[0] = -40;
    }

    Temp_IGBT.igbtTemp = (int)IGBT_Temp[0];


#endif

/*����ƽ���޷��˳�Ч��*/
	/*tempZeroFlg++;
	if(tempZeroFlg<17){
	    tempZeroSum =+ Temp_IGBT.idcAdcData;
		Temp_IGBT.idc = 0;
	}else if(tempZeroFlg==17){
	    tempZero = tempZeroSum * 0.0625;
	}else{
		tempZeroFlg = 200;
		temp = (tempZero- Temp_IGBT.idcAdcData)*0.245238;
		IGBT_Temp[2] = temp * 0.10 + IGBT_Temp[3] * 0.90;
		IGBT_Temp[3] = IGBT_Temp[2];

		if(IGBT_Temp[3] > 1000){
			Temp_IGBT.idc = 1000;
		}else if(IGBT_Temp[3]<0){
			Temp_IGBT.idc = 0;
		}else{
			Temp_IGBT.idc = IGBT_Temp[3];
		}
	}*/

    tempZeroFlg++;
    if(tempZeroFlg<3){
        tempZero = Temp_IGBT.idcAdcData;
        if(tempZero > 1104){
            tempZero = 1114;
        }
        Temp_IGBT.idc = 0;
    }else{
        tempZeroFlg = 200;
        temp = -(Temp_IGBT.idcAdcData -tempZero)*325/420;
        IGBT_Temp[2] = temp * 13 + IGBT_Temp[3] * 87;
        IGBT_Temp[2] = IGBT_Temp[2]/100;
        IGBT_Temp[3] = IGBT_Temp[2];

        if(IGBT_Temp[3] > 950){  //ĸ�ߵ�����ʾ����9.5A
            Temp_IGBT.idc = 950;
        }else if(IGBT_Temp[3] < 0){
            Temp_IGBT.idc = 0;
        }else{
            Temp_IGBT.idc = (int)IGBT_Temp[3];
        }
    }

    //NTC,�����¶�
    if(Temp_IGBT.ntcAdcData>3502){
        Temp_IGBT.ntcTemp = 200;
    }else if(Temp_IGBT.ntcAdcData > 3402){                //176 - (200)
        temp = 252 * Temp_IGBT.ntcAdcData - 682500;
        temp = temp/1000;
        Temp_IGBT.ntcTemp = (int)temp;
    }else if(Temp_IGBT.ntcAdcData > 3242){                //150 - (176)
        temp = 158 * Temp_IGBT.ntcAdcData - 362500;
        temp = temp/1000;
        Temp_IGBT.ntcTemp = (int)temp;
    }else if(Temp_IGBT.ntcAdcData > 2921){                //121 - (150)
        temp = 94 * Temp_IGBT.ntcAdcData - 154500;
        temp = temp/1000;
        Temp_IGBT.ntcTemp = (int)temp;
    }else if(Temp_IGBT.ntcAdcData > 2381){                //90 - (120)
        temp = 56 * Temp_IGBT.ntcAdcData - 43500;
        temp = temp/1000;
        Temp_IGBT.ntcTemp = (int)temp;
    }else if(Temp_IGBT.ntcAdcData > 805){             //31 - (90)
        temp = 37 * Temp_IGBT.ntcAdcData + 1100;
        temp = temp/1000;
        Temp_IGBT.ntcTemp = (int)temp;
    }else if(Temp_IGBT.ntcAdcData > 265){             //0 - (31)
        temp = 56 * Temp_IGBT.ntcAdcData - 15100;
        temp = temp/1000;
        Temp_IGBT.ntcTemp = (int)temp;
    }else if(Temp_IGBT.ntcAdcData > 108){             //0 - (-19)
        temp = 119 * Temp_IGBT.ntcAdcData - 32800;
        temp = temp/1000;
        Temp_IGBT.ntcTemp = (int)temp;
    }else if(Temp_IGBT.ntcAdcData > 34){              //-19 - (-40)
        temp = 271 * Temp_IGBT.ntcAdcData - 49500;
        temp = temp/1000;
        Temp_IGBT.ntcTemp = (int)temp;
    }else{
        Temp_IGBT.ntcTemp = -40;
    }

	//NTC,�����¶�
    IGBT_Temp[1] = IGBT_Temp[1] * 3 + Temp_IGBT.ntcTemp * 7;
    IGBT_Temp[1] = IGBT_Temp[1]/10;
    if(IGBT_Temp[1] < -40){
        IGBT_Temp[1] = -40;
    }

    if(Temp_IGBT.igbtTemp < 0){//0�����£���ⲻ׼
        Temp_IGBT.ntcTemp = Temp_IGBT.igbtTemp;
    }else{
        Temp_IGBT.ntcTemp = (int)IGBT_Temp[1];
    }

    //����
	if(Temp_IGBT.hvilAdcData > 2000){
		Temp_IGBT.hvilFiltCnt++;
		if(Temp_IGBT.hvilFiltCnt > 3){
			Temp_IGBT.hvilFlg = 1;
			Temp_IGBT.hvilFiltCnt = 3;
		}
	}else{
		Temp_IGBT.hvilFiltCnt = 0;
		Temp_IGBT.hvilFlg = 0;
	}
}

#endif




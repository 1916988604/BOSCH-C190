#ifndef DIAGNOSTIC_C_
#define DIAGNOSTIC_C_

#include "DiagnosticTimer.h"
#include "NetworkLayer.h"
#include "diagnostic.h"
#if USE_J1939_DTC
#include "J1939TP.h"
#endif
#include "EEpromDriver.h"
#include "../user/inc/Dsp280015x.h"
#include "../user/inc/mcuSel.h"

//extern uint32 Update_EraseFlash(void);
//extern uint32 Example_ProgramUsingAutoECC(uint32 address, uint8_t* data, uint16 Length);
//extern uint32 iap_start_adddress;
//extern uint32 total_iap_length;

#define SERVICE_NUMBER 	25
typedef void (*ServiceHandler)(uint8_t N_TAType,uint16_t length, uint8_t *MessageData);
//typedef far word* far EEProm_TAddress;

typedef enum{
    SESSION_CONTROL            = 0x10,
    RESET_ECU                  = 0x11,
    SECURITY_ACCESS            = 0x27,
    COMMUNICATION_CONTROL      = 0x28,
    TESTER_PRESENT             = 0x3E,
    GET_TIME_PARAM             = 0x83,
    SECURITY_DATA_TRANSMISSION = 0x84,
    CONTROL_DTC_SETTING        = 0x85,
    RESPONSE_ON_EVENT          = 0x86,
    LINK_CONTROL               = 0x87,
    READ_DATA_BY_ID            = 0x22,
    READ_MEMORY_BY_ADDRESS     = 0x23,
    READ_SCALING_DATA_BY_ID    = 0x24,
    READ_DATA_PERIOD_ID        = 0x2A,
    DYNAMICALLY_DEFINE_DATA_ID = 0x2C,
    WRITE_DATA_BY_ID           = 0x2E,
    WRITE_MEMORY_BY_ADDRESS    = 0x3D,
    CLEAR_DTC_INFO             = 0x14,
    READ_DTC_INFO              = 0X19,
    IO_CONTROL_BY_ID           = 0x2F,
    ROUTINE_CONTROL            = 0x31,
    REQUEST_DOWNLOAD           = 0x34,
    REQUEST_UPLOAD             = 0x35,
    TRANSMIT_DATA              = 0x36,
    REQUEST_TRANSFER_EXIT      = 0x37,
}ServiceName;

typedef enum{
	PR      = 0x00,//positive response
	GR      = 0x10,//general reject
	SNS     = 0x11,//service not supported
	SFNS    = 0x12,//sub-function not supported
	IMLOIF  = 0x13,//incorrect message length or invalid format
	RTL     = 0x14,//response too long
	BRR     = 0x21,//busy repeat request
	CNC     = 0x22,//condifitons not correct
	RSE     = 0x24,//request sequence error
	NRFSC   = 0x25,
	FPEORA  = 0x26,
	ROOR    = 0x31,//reqeust out of range
	SAD     = 0x33,//security access denied
	IK      = 0x35,//invalid key
	ENOA    = 0x36,//exceed number of attempts
	RTDNE   = 0x37,//required time delay not expired
	UDNA    = 0x70,//upload download not accepted
	TDS     = 0x71,//transfer data suspended
	GPF     = 0x72,//general programming failure
	WBSC    = 0x73,//wrong block sequence coutner
	RCRRP   = 0x78,//request correctly received-respone pending
	SFNSIAS = 0x7e,//sub-function not supported in active session
	SNSIAS  = 0x7F,//service not supported in active session
	VTH     = 0x92,//voltage too high
	VTL     = 0x93,//voltage too low
}NegativeResposeCode;



typedef enum{
	WAIT_SEED_REQ,
	WAIT_KEY,
	WAIT_DELAY,
	UNLOCKED,
}SecurityUnlockStep;

typedef enum{
	REPORT_DTCNUMBER_BY_MASK = 1,
	REPORT_DTCCODE_BY_MASK = 2,
	REPORT_DTCSNAPSHOT_BY_ID = 3,
	REPORT_DTCSNAPSHOT_BY_DTCNUMBER = 4,
	REPORT_DTCSNAPSHOT_BY_RECORDNUMBER = 5,
	REPORT_DTCEXTEND_DATA_BY_DTCNUMBER = 6,
	REPORT_DTCNUMBER_BY_SEVERITYMASK,
	REPORT_DTC_BY_SEVERITYMASK,
	REPORT_SEVERITYID_OF_DTC,
	REPORT_SUPPORTED_DTC = 0x0A,
	REPORT_FIRST_FAILED_DTC,
	REPORT_FIRST_CONFIRMED_DTC,
	REPORT_MOST_FAILED_DTC,
	REPORT_MOST_CONFIRMED_DTC,
	REPORT_MIRRORDTC_BY_MASK,
	REPORT_MIRRORDTC_EXTENDED_BY_DTC_NUMBER,
	REPORT_MIRRORDTC_NUMBER_BY_MASK,
	REPORT_OBDDTC_NUMBER_BY_MASK,
	REPORT_OBDDTC_BY_MASK,
}DTCSubFunction;


typedef enum{
	POWERTRAIN,
	CHASSIS,
	BODY,
	NETWORK,
}DTCAlphanumeric ;


typedef union{
	struct{
		uint8_t TestFailed:1;
		uint8_t TestFailedThisMonitoringCycle:1;
		uint8_t PendingDTC:1;
		uint8_t ConfirmedDTC:1;
		uint8_t TestNotCompleteSinceLastClear:1;
		uint8_t TestFailedSinceLastClear:1;
		uint8_t TestNotCompleteThisMonitoringCycle:1;
		uint8_t WarningIndicatorRequested:1;
	}DTCbit;
	uint8_t DTCStatusByte;
}DTCStatusType;

typedef struct _J1939DTC{
	uint32_t SPN;
	uint8_t  FMI;
	uint8_t  CM;
	uint8_t  OC;
}J1939DTC;

typedef struct _DtcNode{
	uint32_t      DTCCode;
	DetectFun     DetectFunction;//鏁呴殰妫�娴嬪嚱鏁�
	uint16_t      EEpromAddr;
	uint8_t       TripLimitTimes;
	DTCStatusType DTCStatus;
	uint8_t       OldCounter;
	uint8_t       GoneCounter;
	uint8_t       TripCounter;//鏁呴殰寰呭畾璁℃暟鍣�
	uint8_t       FaultOccurrences;//鏁呴殰鍑虹幇娆℃暟
	uint16_t      SnapShotEEpromAddr;//蹇収淇℃伅鍦板潃
	//uint16_t ExtenedDataEEpromAddr;//鎵╁睍鏁版嵁鍦板潃
	#if USE_J1939_DTC
	DTCLevel dtcLevel;
	J1939DTC DM1Code;
	#endif
	#if USE_MALLOC
	struct _DtcNode* next;
	#endif
}DTCNode;

typedef struct _DidNode{
	uint16_t      ID;
	uint8_t       dataLength;
	uint8_t*      dataPointer;
	IoControl     Callback;
	DIDType       didType;
	ReadWriteAttr RWAttr;
	uint32_t      EEpromAddr;
	bool          SupportWriteInFactoryMode;
	#if USE_MALLOC
	struct _DidNode* next;
	#endif
}DIDNode;

typedef struct _GroupNode{
	uint32_t GroupID;
	struct _GroupNode* next;
}DTCGroupNode;

typedef struct _Snapshot{
	uint8_t  snapshotRecord;
	uint16_t snapshotID;
	uint8_t* dataPointer;
	uint8_t  dataLength;
}Snapshot;

typedef struct{
	bool            support;
	ServiceName     serviceName;
	uint8_t         PHYDefaultSession_Security:4;//security suppport in default session physical address
	uint8_t         PHYProgramSeesion_Security:4;//security suppport in program session physical address
	uint8_t         PHYExtendedSession_Security:4;//security suppport in extened session physical address
	uint8_t         FUNDefaultSession_Security:4;//security suppport in default session function address
	uint8_t         FUNProgramSeesion_Security:4;//security suppport in program session function address
	uint8_t         FUNExtendedSession_Security:4;//security suppport in extened session function address
	ServiceHandler  serviceHandle;
}SessionService;

typedef struct{
	bool            valid;
	SecurityLevel   level;
	SecurityFun     UnlockFunction;
	uint8_t         seedID;
	uint8_t         keyID;
	uint8_t         FaultCounter;
	uint16_t        FaultCounterAddr;
	uint8_t         FaultLimitCounter;
	uint32_t        UnlockFailedDelayTime;
	uint8_t         subFunctionSupported;
	DiagTimer       SecurityLockTimer;						//瑙ｉ攣澶辫触3娆″悗鍐嶆瑙ｉ攣寤舵椂瀹氭椂鍣�
	uint8_t         KeySize;
}SecurityUnlock;

/* Private macro -------------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/

void ServiceNegReponse(uint8_t serviceName,uint8_t RejectCode);
void Diagnostic_ReadDTCPositiveResponse(uint8_t DTCSubFunction,uint8_t DTCStatausMask);
void Service10Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service11Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service27Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service28Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service3EHandle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service83Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service84Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service85Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service86Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service87Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service22Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service23Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service24Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service2AHandle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service2CHandle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service2EHandle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service3DHandle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service14Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service19Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service2FHandle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service31Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service34Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service35Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service36Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
void Service37Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData);
DIDNode* SearchDidNode(uint16_t DID);
void Diagnostic_ClearDTC(uint32_t Group);
void Diagnostic_SaveAllDTC(void);
void Diagnostic_LoadAllDTC(void);
DTCNode* GetDTCNodeByCode(uint32_t dtcCode);


/*========================diagnositc version================================*/
//const uint8_t DriverVersion[] = {1,0,1};
uint8_t DriverVersion[] = {1,0,1};
uint8_t NMVersion[] = {0,0,0};
uint8_t DiagnosticVersion[] = {1,0,1};
uint8_t DatabaseVersion[] = {0,0};
/*========================about security acces================================*/


/*========================about security acces================================*/
static uint8_t Seed[4];										//淇濆瓨瑙ｉ攣绉嶅瓙
static uint8_t key[4];										//淇濆瓨瑙ｉ攣瀵嗗寵
//static uint32_t retLen;
static SecurityLevel m_SecurityLevel = LEVEL_ZERO;			//褰撳墠瑙ｉ攣绛夌骇
static SecurityUnlockStep m_UnlockStep = WAIT_SEED_REQ;	    //褰撳墠瑙ｉ攣姝ラ顎�
SecurityUnlock UnlockList[3];
/*========================about security acces================================*/

/*========================sesion , id , buf and so on================================*/
static NegativeResposeCode m_NRC;					//鍚﹀畾鍝嶅簲鐮�
SessionType m_CurrSessionType;							//褰撳墠鍥炶瘽绫诲瀷
bool ResponsePending;									//鏄惁鍙戦�佽繃78璐熷搷搴�
bool suppressResponse;
uint16_t ResponseLength;
uint8_t CurrentService;
static uint8_t DiagnosticBuffTX[200];							//鍙戦�佹暟鎹殑缂撳瓨
//static uint8_t J1939BufTX[90];
static DiagTimer S3serverTimer;							  //S3瀹氭椂鍣�
static uint16_t P2CanServerMax =  0x32;						//鍥炶瘽鍙傛暟
static uint16_t P2ECanServerMax = 0x1F4;					//鍥炶瘽鍙傛暟
static uint32_t TesterPhyID;
static uint32_t TesterFunID;
static uint32_t TesterPhyID1;
static uint32_t TesterFunID1;
static uint32_t EcuID1;
static uint32_t EcuID;
static uint8_t N_Ta;
static uint8_t N_Sa;
static uint8_t SessionSupport;      //bit0: default session 01 support
						            //bit1: program session 02 support
                                    //bit2: extended session 03 support
						            //bit3: sub02 supported in defaultsession
						            //bit4: sub03 supported in program
						            //bit5: supressPosRespnse support
#define Service10Sub01Supported()   ((SessionSupport & 0x01) != 0)
#define Service10Sub02Supported()   ((SessionSupport & 0x02) != 0)
#define Service10Sub03Supported()   ((SessionSupport & 0x04) != 0)
#define Service10Sub01To02OK()      ((SessionSupport & 0x08) != 0)
#define Service10Sub02To03OK()      ((SessionSupport & 0x10) != 0)
#define Service10SupressSupproted() ((SessionSupport & 0x20) != 0)
/*========================sesion , id , buf and so on================================*/

/*========================about program================================*/
static uint8_t m_BlockIndex = 0;
static uint32_t ProgramAddress = 0;
static uint32_t ProgramLength = 0;
static uint32_t ProgramLengthComplete = 0;
//static bool IsUpdating = FALSE;
static bool WaitConfirmBeforeJump = FALSE;				//
static bool WaitConfirmBeforeErase = FALSE;				//鎿﹂櫎鍓嶇瓑寰�78璐熷弽棣堢殑纭淇℃伅
/*========================about program================================*/

/*========================about DTC and DIDs================================*/	
#if USE_MALLOC
static DTCNode* DTCHeader;
static DIDNode* DIDHeader;
static DTCGroupNode *GroupHeader;
#else
static DTCNode DTCS[MAX_DTC_NUMBER];
static uint8_t DTCAdded;
static DIDNode DIDS[MAX_DID_NUMBER];
static uint8_t DIDAdded;
static Snapshot SnapShots[MAX_SNAPSHOT_NUMBER];
static uint8_t SnapShotAdded = 0;
static uint16_t EepromWriteArray[0x20]={0};
static uint16_t EepromReadArray[0x20]={0};
//static Snapshot ExtendedData[MAX_EXTENDED_DATA_NUMBER];
//static uint8_t ExtendedDataAdded = 0;
static uint8_t AgedCounterRecord = 0;
static uint8_t AgingCounterRecord = 0;
static uint8_t OccurenceCounterRecord = 0;
static uint8_t PendingCounterRecord = 0;

static DTCGroupNode DTCGROUPS[MAX_GROUP_NUMBER];
static uint8_t DTCGroupAdded;
#endif
#if USE_J1939_DTC
static bool DiagDM1Enable = TRUE;
#endif
static bool DtcAvailibaleMask;
static DiagTimer DtcTimer;
static uint32_t ModuleEEpromStartAddr;
//static uint16_t EEpromSizeForUse;
static uint16_t EEpromUsed;
#define DTC_BYTE_NUMBER_TO_SAVE	5
bool EnableDTCDetect;						//浣胯兘鏁呴殰鐮佹娴�
bool HighVoltage;								//杩囩數鍘嬫爣蹇�
bool LowVoltage;								//娆犵數鍘嬫爣蹇�
bool SaveDTCInBlock;
static uint8_t DTCSaved;
static uint8_t DM1DTCNumber;					//J1939 DTC number
//static DiagTimer J1939Timer;					//j1939 timer
static DiagTimer DTCSavedTimer;
/*========================about DTC and DIDs================================*/

/*========================about reset================================*/
static uint8_t ResetTypeSupport;      //bit0: 01 sub function supported
						              //bit1: 02 sub function supported
						              //bit2: 03 sub function supported
						              //bit3: 04 sub function supported
						              //bit4: 05 sub function supported
						              //bit5:posresonpse supress supported
#define Service11SupressSupported()  ((ResetTypeSupport & 0x20) != 0)
#define Service11Sub01Supported()    ((ResetTypeSupport & 0x01) != 0)
#define Service11Sub02Supported()    ((ResetTypeSupport & 0x02) != 0)
#define Service11Sub03Supported()    ((ResetTypeSupport & 0x04) != 0)
#define Service11Sub04Supported()    ((ResetTypeSupport & 0x08) != 0)
#define Service11Sub05Supported()    ((ResetTypeSupport & 0x10) != 0)
static ResetCallBack ResetCallBackFun;
static EcuResetType m_EcuResetType;						//ECU澶嶄綅绫诲瀷
static bool WaitConfimBeforeReset = FALSE;
/*========================about reset===============================*/

/*========================about tester present===============================*/
static uint8_t TesterPresentSuppport;//posresonpse supress supported
#define Service3ESupressSupported()   ((TesterPresentSuppport & 0x01) != 0)
#define Service85SupressSupported()   ((TesterPresentSuppport & 0x02) != 0)
/*========================about tester present===============================*/

/*========================about commulication control===============================*/	

static uint8_t CommTypeSupport;//bit0:00 sub function supported
							   //bit1:01 sub function supported
							   //bit2:02 sub function supported
							   //bit3:03 sub function supported
							   //bit4:01 type supported
							   //bit5:02 type supported
							   //bit6:03 type supported
							   //bit6:posresponse supress supported
#define Service28Sub00Suppoted() ((CommTypeSupport & 0x01) != 0)
#define Service28Sub01Suppoted() ((CommTypeSupport & 0x02) != 0)
#define Service28Sub02Suppoted() ((CommTypeSupport & 0x04) != 0)
#define Service28Sub03Suppoted() ((CommTypeSupport & 0x08) != 0)
#define Service28Type01Suppoted() ((CommTypeSupport & 0x10) != 0)
#define Service28Type02Suppoted() ((CommTypeSupport & 0x20) != 0)
#define Service28Type03Suppoted() ((CommTypeSupport & 0x40) != 0)
#define Service28SupressSupported() ((CommTypeSupport & 0x80) != 0)
static CommCallBack commCallBack;
/*========================about commulication control===============================*/	

/*========================about factory mode use ===============================*/
void Diagnostic_DTCDefaultValue(void);
/*========================about factory mode use===============================*/
//鏉冮檺绠＄悊
SessionService ServiceList[SERVICE_NUMBER] = {
//          servicename                 PHY01               PHY02               PHY03               FUN01               FUN02               FUN03               鏈嶅姟閫氶亾
	{FALSE, SESSION_CONTROL,			LEVEL_ZERO,			LEVEL_ZERO,			LEVEL_ZERO,			LEVEL_ZERO,			LEVEL_ZERO,			LEVEL_ZERO,			Service10Handle},//0X10
	{FALSE, RESET_ECU,					LEVEL_UNSUPPORT,	LEVEL_ZERO,			LEVEL_ZERO,			LEVEL_UNSUPPORT,	LEVEL_ZERO,			LEVEL_ZERO,			Service11Handle},//0X11
	{FALSE, SECURITY_ACCESS,			LEVEL_UNSUPPORT,	LEVEL_ZERO,			LEVEL_ZERO,			LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service27Handle},//0X27
	{FALSE, COMMUNICATION_CONTROL,		LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_ZERO,			LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_ZERO,			Service28Handle},//0X28
	{FALSE, TESTER_PRESENT,				LEVEL_ZERO,			LEVEL_ZERO,			LEVEL_ZERO,			LEVEL_ZERO,			LEVEL_ZERO,			LEVEL_ZERO,			Service3EHandle},//0X3E
	{FALSE, GET_TIME_PARAM,				LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service83Handle},//0X83
	{FALSE, SECURITY_DATA_TRANSMISSION,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service84Handle},//0X84
	{FALSE, CONTROL_DTC_SETTING,		LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_ZERO,			LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_ZERO,			Service85Handle},//0X85
	{FALSE, RESPONSE_ON_EVENT,			LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service86Handle},//0X86
	{FALSE, LINK_CONTROL,				LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service87Handle},//0X87
	{FALSE, READ_DATA_BY_ID,			LEVEL_ZERO,			LEVEL_UNSUPPORT,	LEVEL_ZERO,			LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service22Handle},//0X22
	{FALSE, READ_MEMORY_BY_ADDRESS,	    LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service23Handle},//0X23
	{FALSE, READ_SCALING_DATA_BY_ID,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service24Handle},//0X24
	{FALSE, READ_DATA_PERIOD_ID,		LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service2AHandle},//0X2A
	{FALSE, DYNAMICALLY_DEFINE_DATA_ID,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service2CHandle},//0X2C
	{FALSE, WRITE_MEMORY_BY_ADDRESS,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service3DHandle},//0X3D
	{FALSE, WRITE_DATA_BY_ID,			LEVEL_UNSUPPORT,	LEVEL_ONE,			LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service2EHandle},//0X2E
	{FALSE, CLEAR_DTC_INFO,				LEVEL_ZERO,			LEVEL_UNSUPPORT,	LEVEL_ZERO,			LEVEL_ZERO,			LEVEL_UNSUPPORT,	LEVEL_ZERO,			Service14Handle},//0X14
	{FALSE, READ_DTC_INFO,				LEVEL_ZERO,			LEVEL_UNSUPPORT,	LEVEL_ZERO,			LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service19Handle},//0X19
	{FALSE, IO_CONTROL_BY_ID,			LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_ONE,			LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service2FHandle},//0X2F
	{FALSE, ROUTINE_CONTROL,			LEVEL_UNSUPPORT,	LEVEL_ONE,			LEVEL_ONE,			LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service31Handle},//0X31
	{FALSE, REQUEST_DOWNLOAD,			LEVEL_UNSUPPORT,	LEVEL_ONE,			LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service34Handle},//0X34
	{FALSE, REQUEST_UPLOAD,				LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service35Handle},//0X35
	{FALSE, TRANSMIT_DATA,				LEVEL_UNSUPPORT,	LEVEL_ONE,			LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service36Handle},//0X36
	{FALSE, REQUEST_TRANSFER_EXIT,		LEVEL_UNSUPPORT,	LEVEL_ONE,			LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	LEVEL_UNSUPPORT,	Service37Handle},//0X37
};

static const uint32_t crc32Table[256] = {
    0x00000000, 0x77073096, 0xEE0E612C, 0x990951BA, 0x076DC419, 0x706AF48F, 0xE963A535,
    0x9E6495A3, 0x0EDB8832, 0x79DCB8A4, 0xE0D5E91E, 0x97D2D988, 0x09B64C2B, 0x7EB17CBD,
    0xE7B82D07, 0x90BF1D91, 0x1DB71064, 0x6AB020F2, 0xF3B97148, 0x84BE41DE, 0x1ADAD47D,
    0x6DDDE4EB, 0xF4D4B551, 0x83D385C7, 0x136C9856, 0x646BA8C0, 0xFD62F97A, 0x8A65C9EC,
    0x14015C4F, 0x63066CD9, 0xFA0F3D63, 0x8D080DF5, 0x3B6E20C8, 0x4C69105E, 0xD56041E4,
    0xA2677172, 0x3C03E4D1, 0x4B04D447, 0xD20D85FD, 0xA50AB56B, 0x35B5A8FA, 0x42B2986C,
    0xDBBBC9D6, 0xACBCF940, 0x32D86CE3, 0x45DF5C75, 0xDCD60DCF, 0xABD13D59, 0x26D930AC,
    0x51DE003A, 0xC8D75180, 0xBFD06116, 0x21B4F4B5, 0x56B3C423, 0xCFBA9599, 0xB8BDA50F,
    0x2802B89E, 0x5F058808, 0xC60CD9B2, 0xB10BE924, 0x2F6F7C87, 0x58684C11, 0xC1611DAB,
    0xB6662D3D, 0x76DC4190, 0x01DB7106, 0x98D220BC, 0xEFD5102A, 0x71B18589, 0x06B6B51F,
    0x9FBFE4A5, 0xE8B8D433, 0x7807C9A2, 0x0F00F934, 0x9609A88E, 0xE10E9818, 0x7F6A0DBB,
    0x086D3D2D, 0x91646C97, 0xE6635C01, 0x6B6B51F4, 0x1C6C6162, 0x856530D8, 0xF262004E,
    0x6C0695ED, 0x1B01A57B, 0x8208F4C1, 0xF50FC457, 0x65B0D9C6, 0x12B7E950, 0x8BBEB8EA,
    0xFCB9887C, 0x62DD1DDF, 0x15DA2D49, 0x8CD37CF3, 0xFBD44C65, 0x4DB26158, 0x3AB551CE,
    0xA3BC0074, 0xD4BB30E2, 0x4ADFA541, 0x3DD895D7, 0xA4D1C46D, 0xD3D6F4FB, 0x4369E96A,
    0x346ED9FC, 0xAD678846, 0xDA60B8D0, 0x44042D73, 0x33031DE5, 0xAA0A4C5F, 0xDD0D7CC9,
    0x5005713C, 0x270241AA, 0xBE0B1010, 0xC90C2086, 0x5768B525, 0x206F85B3, 0xB966D409,
    0xCE61E49F, 0x5EDEF90E, 0x29D9C998, 0xB0D09822, 0xC7D7A8B4, 0x59B33D17, 0x2EB40D81,
    0xB7BD5C3B, 0xC0BA6CAD, 0xEDB88320, 0x9ABFB3B6, 0x03B6E20C, 0x74B1D29A, 0xEAD54739,
    0x9DD277AF, 0x04DB2615, 0x73DC1683, 0xE3630B12, 0x94643B84, 0x0D6D6A3E, 0x7A6A5AA8,
    0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1, 0xF00F9344, 0x8708A3D2, 0x1E01F268,
    0x6906C2FE, 0xF762575D, 0x806567CB, 0x196C3671, 0x6E6B06E7, 0xFED41B76, 0x89D32BE0,
    0x10DA7A5A, 0x67DD4ACC, 0xF9B9DF6F, 0x8EBEEFF9, 0x17B7BE43, 0x60B08ED5, 0xD6D6A3E8,
    0xA1D1937E, 0x38D8C2C4, 0x4FDFF252, 0xD1BB67F1, 0xA6BC5767, 0x3FB506DD, 0x48B2364B,
    0xD80D2BDA, 0xAF0A1B4C, 0x36034AF6, 0x41047A60, 0xDF60EFC3, 0xA867DF55, 0x316E8EEF,
    0x4669BE79, 0xCB61B38C, 0xBC66831A, 0x256FD2A0, 0x5268E236, 0xCC0C7795, 0xBB0B4703,
    0x220216B9, 0x5505262F, 0xC5BA3BBE, 0xB2BD0B28, 0x2BB45A92, 0x5CB36A04, 0xC2D7FFA7,
    0xB5D0CF31, 0x2CD99E8B, 0x5BDEAE1D, 0x9B64C2B0, 0xEC63F226, 0x756AA39C, 0x026D930A,
    0x9C0906A9, 0xEB0E363F, 0x72076785, 0x05005713, 0x95BF4A82, 0xE2B87A14, 0x7BB12BAE,
    0x0CB61B38, 0x92D28E9B, 0xE5D5BE0D, 0x7CDCEFB7, 0x0BDBDF21, 0x86D3D2D4, 0xF1D4E242,
    0x68DDB3F8, 0x1FDA836E, 0x81BE16CD, 0xF6B9265B, 0x6FB077E1, 0x18B74777, 0x88085AE6,
    0xFF0F6A70, 0x66063BCA, 0x11010B5C, 0x8F659EFF, 0xF862AE69, 0x616BFFD3, 0x166CCF45,
    0xA00AE278, 0xD70DD2EE, 0x4E048354, 0x3903B3C2, 0xA7672661, 0xD06016F7, 0x4969474D,
    0x3E6E77DB, 0xAED16A4A, 0xD9D65ADC, 0x40DF0B66, 0x37D83BF0, 0xA9BCAE53, 0xDEBB9EC5,
    0x47B2CF7F, 0x30B5FFE9, 0xBDBDF21C, 0xCABAC28A, 0x53B39330, 0x24B4A3A6, 0xBAD03605,
    0xCDD70693, 0x54DE5729, 0x23D967BF, 0xB3667A2E, 0xC4614AB8, 0x5D681B02, 0x2A6F2B94,
    0xB40BBE37, 0xC30C8EA1, 0x5A05DF1B, 0x2D02EF8D                                      };

/*****************************************************************
 **fun    : Appendix A CRC32鏍￠獙绠楁硶
 **name   : CRC32_Calculate
 **param0 : data:  寰呰绠楁暟鎹寚閽�
 **param1 : length:鏁版嵁闀垮害(瀛楄妭鏁�)
 **param2 : crcInit:CRC鍒濆鍊硷紝 閫氬父0xFFFFFFFF
 **return : 璁＄畻鍚庡緱鍒扮殑CRC32鏍￠獙鍊�
 ****************************************************************/
uint32_t CRC32_Calculate(const uint8_t* data, uint32_t length, uint32_t crcTnit)
{
    uint32_t crc = crcTnit;
    while(length--)
    {
        uint8_t dataH = (*data >> 8) & 0xFF;
        uint8_t dataL = *data  & 0xFF;

        //鍏堝皢褰撳墠浣�8 bit 涓庤〃绱㈠紩
        uint8_t tableindex = (uint8_t)((crc ^ dataH) & 0xFF);
        crc = (crc >> 8) ^ crc32Table[tableindex];

        uint8_t tableindex1 = (uint8_t)((crc ^ dataL) & 0xFF);
        crc = (crc >> 8) ^ crc32Table[tableindex1];
        data++;
    }
    return (crc ^ 0xFFFFFFFF);
}



/* Private functions ---------------------------------------------------------*/
/* Public functions ----------------------------------------------------------*/

/*========interface for application layer setting diagnostic parameters==============*/

/*****************************************************************
 **fun    : 鍒濆鍖栧畨鍏ㄨ闂�
 **name   : InitAddSecurityAlgorithm
 **param0 : level:瀹夊叏绛夌骇
 **param1 : AlgoritthmFun:瀹夊叏璁块棶绠楁硶
 **param2 : SeedSubFunctionNum:璁块棶seed鐨処D
 **param3 : KeySubFunctionNum:璁块棶keey鐨処D
 **param4 : FaultCounter:璁块棶澶辫触娆℃暟
 **param5 : FaultLimitCounter锛氳闂け璐ラ檺鍒舵鏁�
 **param6 : UnlockFailedDelayTimeMS:璁块棶澶辫触闄愬埗娆℃暟鍚庡欢杩熻闂椂闂�
 **param7 : SubFuntioncSupportedInSession:浼氳瘽鏀寔
 **param8 : KeySize:keey鐨勫瓧鑺傚ぇ灏�
 **return : TRUE:鍒濆鍖栨垚鍔�
            FALSE:鍒濆鍖栦笉鎴愬姛
 ****************************************************************/
bool InitAddSecurityAlgorithm(SecurityLevel level, SecurityFun AlgoritthmFun, byte SeedSubFunctionNum, byte KeySubFunctionNum, uint8_t* FaultCounter, uint8_t FaultLimitCounter, uint32_t UnlockFailedDelayTimeMS, SubFunSuppInSession SubFuntioncSupportedInSession, uint8_t KeySize)
{
	uint8_t i;
	for(i = 0 ; i < 3 ; i++)
	{
		if(UnlockList[i].valid == FALSE)
		{
			UnlockList[i].UnlockFunction = AlgoritthmFun;
			UnlockList[i].seedID = SeedSubFunctionNum;
			UnlockList[i].keyID = KeySubFunctionNum;
			UnlockList[i].level = level;
			UnlockList[i].valid = TRUE;
			UnlockList[i].FaultCounterAddr = (ModuleEEpromStartAddr + EEpromUsed);
			//UnlockList[i].FaultCounterAddr = EepromWriteArray;
			EEpromUsed += 1;
			UnlockList[i].FaultLimitCounter = FaultLimitCounter;//瑙ｉ攣澶辫触3娆″悗杩涘叆寤惰繜
			UnlockList[i].UnlockFailedDelayTime = UnlockFailedDelayTimeMS;
			UnlockList[i].subFunctionSupported = SubFuntioncSupportedInSession;
			UnlockList[i].KeySize = KeySize;
			return TRUE;
		}
	}
	return FALSE;
}


/*****************************************************************
 **fun    : 宸ュ巶瀹夊叏璁块棶绠楁硶
 **name   : FactorySecuritySeedToKey
 **param0 : seed:绉嶅瓙
 **return : 0x12345678
 ****************************************************************/
/*uint32_t FactorySecuritySeedToKey(uint32_t seed)
{
	return 0x12345678;
}
*/
void FactorySecuritySeedToKey(uint8_t *seed, uint8_t *key, uint8_t size)
{
    uint8_t i;
    for(i = 0; i < size; i++)
    {
        *(key+i)=*(seed+i)+1;
    }
}

/*****************************************************************
 **fun    : 宸ュ巶瀹夊叏绛夌骇璁块棶鍒濆鍖�
 **name   : InitFactorySecuriyAlgorithm
 **param0 : seed:绉嶅瓙
 **return : 0x12345678
 ****************************************************************/
void InitFactorySecuriyAlgorithm(void)
{
	InitAddSecurityAlgorithm(LEVEL_FOUR, FactorySecuritySeedToKey, 0x71, 0x72, NULL, 3, 10000, SUB_FACTORY, 4);
}


/*****************************************************************
 **fun    : 鏀寔鐨刄DS鏈嶅姟璁块棶
 **name   : InitSetSessionSupportAndSecurityAccess
 **param0 : support:鏀寔or涓嶆敮鎸�
 **param1 : service:鏈嶅姟ID
 **param2 : PHYDefaultSession_Security:鐗╃悊ID榛樿浼氳瘽鐨勫畨鍏ㄧ瓑绾�
 **param3 : PHYProgramSeesion_Security:鐗╃悊ID缂栫▼浼氳瘽鐨勫畨鍏ㄧ瓑绾�
 **param4 : PHYExtendedSession_Security:鐗╃悊ID鎵╁睍浼氳瘽鐨勫畨鍏ㄧ瓑绾�
 **param5 : FUNDefaultSession_Security:鍔熻兘ID榛樿浼氳瘽鐨勫畨鍏ㄧ瓑绾�
 **param6 : FUNProgramSeesion_Security:鍔熻兘ID缂栫▼浼氳瘽鐨勫畨鍏ㄧ瓑绾�
 **param7 : FUNExtendedSession_Security:鍔熻兘ID鎵╁睍浼氳瘽鐨勫畨鍏ㄧ瓑绾�
 **return : TRUE:鍒濆鍖栨垚鍔�
            FALSE:鍒濆鍖栦笉鎴愬姛
 ****************************************************************/
bool InitSetSessionSupportAndSecurityAccess(bool support, uint8_t service, uint8_t PHYDefaultSession_Security, uint8_t PHYProgramSeesion_Security, uint8_t PHYExtendedSession_Security, uint8_t FUNDefaultSession_Security, uint8_t FUNProgramSeesion_Security, uint8_t FUNExtendedSession_Security)
{
	uint8_t i;
	if(support == FALSE)
	{
		//warning ,we suggest set service supported when init,or we can not access this service
	}
	for(i = 0; i < SERVICE_NUMBER; i++)
	{
		if(ServiceList[i].serviceName ==  service)
		{
			ServiceList[i].FUNDefaultSession_Security = FUNDefaultSession_Security;
			ServiceList[i].FUNExtendedSession_Security = FUNExtendedSession_Security;
			ServiceList[i].FUNProgramSeesion_Security = FUNProgramSeesion_Security;
			ServiceList[i].PHYDefaultSession_Security = PHYDefaultSession_Security;
			ServiceList[i].PHYExtendedSession_Security = PHYExtendedSession_Security;
			ServiceList[i].PHYProgramSeesion_Security = PHYProgramSeesion_Security;
			ServiceList[i].support = support;
			return TRUE;	
		}
	}
	return FALSE;
}


/*****************************************************************
 **fun    : 鍒濆鍖朌ID鏁版嵁
 **name   : InitAddDID
 **param0 : DID:DID鏍囪瘑绗�
 **param1 : DataLength:鏁版嵁闀垮害
 **param2 : DataPointer:鏁版嵁鎸囬拡
 **param3 : DidType:DID鏍囪瘑绗︾被鍨�
 **param4 : ControlFun:鎺у埗鍑芥暟
 **param5 : RWAttr:read鐨勫湴鍧�
 **param6 : EEaddr:瀛樺偍鍦‥EPROM鍦板潃
 **param7 : SupportWriteInFactoryMode:鏀寔宸ュ巶涓嬬嚎鍐�
 **return : 鏃�
 ****************************************************************/
void InitAddDID(uint16_t DID, uint8_t DataLength, uint8_t* DataPointer, DIDType DidType, IoControl ControlFun, ReadWriteAttr RWAttr, uint16_t EEaddr, bool SupportWriteInFactoryMode)
{
	#if USE_MALLOC
	DIDNode* didNode = (DIDNode*)malloc(sizeof(DIDNode));
	DIDNode* temp = DIDHeader;
	didNode->ID = DID;
	didNode->dataLength = DataLength;
	didNode->Callback = ControlFun;
	didNode->didType = DidType;
	didNode->RWAttr = RWAttr;
	didNode->next = NULL;
	if(didNode->RWAttr == READWRITE && DidType == EEPROM_DID)
	{
		didNode->dataPointer = (byte*)(ModuleEEpromStartAddr + EEpromUsed);
		EEpromUsed += DataLength;
	}
	else
	{
		didNode->dataPointer = DataPointer;
	}

	if(temp == NULL)
	{
		DIDHeader = didNode;
	}
	else
	{
		while(temp->next != NULL)
		{
			temp = temp->next;
		}
		temp->next = didNode;
	}
	#else
	if(DIDAdded < MAX_DID_NUMBER)
	{
		DIDS[DIDAdded].ID = DID;
		DIDS[DIDAdded].dataLength = DataLength;
		DIDS[DIDAdded].Callback = ControlFun;
		DIDS[DIDAdded].didType = DidType;
		DIDS[DIDAdded].RWAttr = RWAttr;
		DIDS[DIDAdded].SupportWriteInFactoryMode = SupportWriteInFactoryMode;
		if(DidType == EEPROM_DID)
		{
			if(EEaddr == 0)
			{
				DIDS[DIDAdded].EEpromAddr = ModuleEEpromStartAddr + EEpromUsed;
				EEpromUsed += DataLength;
			}
			else
			{
				DIDS[DIDAdded].EEpromAddr = EEaddr;
			}
		}
		else
		{
			DIDS[DIDAdded].dataPointer = DataPointer;
		}

		DIDAdded++;
	}
	#endif
}

#if USE_J1939_DTC
bool InitAddDTC(uint32_t DTCCode,DetectFun MonitorFun,byte DectecPeroid, byte ValidTimes,DTCLevel dtcLevel,uint32_t spn, uint8_t fmi)
#else
bool InitAddDTC(uint32_t DTCCode,DetectFun MonitorFun,byte DectecPeroid, byte ValidTimes,DTCLevel dtcLevel)
#endif
{
	#if USE_MALLOC
	DTCNode* dtcNode = (DTCNode*)malloc(sizeof(DTCNode));
	DTCNode* temp = DTCHeader;
	dtcNode->DTCCode = DTCCode;
	dtcNode->DetectFunction = MonitorFun;
	dtcNode->dtcLevel = dtcLevel;
	dtcNode->EEpromAddr = ModuleEEpromStartAddr + EEpromUsed;
	dtcNode->next = NULL;
	EEpromUsed += DTC_BYTE_NUMBER_TO_SAVE;

	if(temp == NULL)
	{
		DTCHeader = dtcNode;
	}
	else
	{
		while(temp->next != NULL)
		{
			temp = temp->next;
		}
		temp->next = dtcNode;
	}
	return TRUE;
	#else
	if(DTCAdded < MAX_DTC_NUMBER)
	{
		DTCS[DTCAdded].DTCCode = DTCCode;
		DTCS[DTCAdded].DetectFunction = MonitorFun;
		DTCS[DTCAdded].TripLimitTimes = ValidTimes;
		#if USE_J1939_DTC
		DTCS[DTCAdded].dtcLevel = dtcLevel;
		DTCS[DTCAdded].DM1Code.SPN = spn;
		DTCS[DTCAdded].DM1Code.FMI = fmi;
		//DTCS[DTCAdded].DM1Code.CM = 0;
		DTCS[DTCAdded].DM1Code.OC = 0;
		#endif
		DTCS[DTCAdded].EEpromAddr = ModuleEEpromStartAddr + EEpromUsed;
		EEpromUsed += DTC_BYTE_NUMBER_TO_SAVE;

		DTCAdded++;
		return TRUE;
	}
	else
	{
		return FALSE;
	}
	#endif
}

void InitAddDTCSnapShot(uint8_t recordNumber , uint16_t ID , uint8_t* datap , uint8_t size)
{
	if(SnapShotAdded < MAX_SNAPSHOT_NUMBER)
	{
		SnapShots[SnapShotAdded].snapshotRecord = recordNumber;
		SnapShots[SnapShotAdded].snapshotID = ID;
		SnapShots[SnapShotAdded].dataPointer = datap;
		SnapShots[SnapShotAdded].dataLength = size;
		SnapShotAdded++;
	}
}

void InitSetAgingCounterRecordNumber(uint8_t RecordNumer)
{
	AgingCounterRecord = RecordNumer;
}

void InitSetAgedCounterRecordNumber(uint8_t RecordNumer)
{
	AgedCounterRecord = RecordNumer;
}

void InitSetOccurrenceCounterRecordNumber(uint8_t RecordNumer)
{
	OccurenceCounterRecord = RecordNumer;
}

void InitSetPendingCounterRecordNumber(uint8_t RecordNumer)
{
	PendingCounterRecord = RecordNumer;
}

#if 0
void InitAddDTCExtendedData(uint16_t ID , uint8_t* datap , uint8_t size)
{
	if(ExtendedDataAdded < MAX_EXTENDED_DATA_NUMBER)
	{
		ExtendedData[ExtendedDataAdded].snapshotID = ID;
		ExtendedData[ExtendedDataAdded].dataPointer = datap;
		ExtendedData[ExtendedDataAdded].dataLength = size;
		ExtendedDataAdded++;
	}
}
#endif

void InitSetDTCAvailiableMask(uint8_t AvailiableMask)
{
	DtcAvailibaleMask = AvailiableMask;
}

void InitAddDTCGroup(uint32_t Group)
{
	#if USE_MALLOC
	DTCGroupNode* temp = GroupHeader;
	DTCGroupNode* groupNode = (DTCGroupNode*)malloc(sizeof(DTCGroupNode));
	groupNode->GroupID = Group;
	groupNode->next = NULL;
	if(temp == NULL)
	{
		GroupHeader = groupNode;
	}
	else
	{
		while(temp->next != NULL)
		{
			temp = temp->next;
		}
		temp->next = groupNode;
	}
	#else
	if(DTCGroupAdded < MAX_GROUP_NUMBER)
	{
		DTCGROUPS[DTCGroupAdded].GroupID = Group;
		DTCGroupAdded++;
	}
	#endif
}

void InitSetSysResetParam(bool support01, bool support02, bool support03, bool support04, bool support05, ResetCallBack callback, bool supressPosResponse)
{
	ResetTypeSupport = support01 | (support02<<1) | (support03 << 2) | (support04 << 3) | (support05 << 4) | (supressPosResponse << 5);
	ResetCallBackFun = callback;
}

void InitSetCommControlParam(bool supportSubFun00, bool supportSubFun01 , bool supportSubFun02 , bool supportSubFun03 , bool supportType01, bool supportType02, bool supportType03, CommCallBack callback, bool supressPosResponse)
{
	CommTypeSupport = supportSubFun00 | (supportSubFun01 << 1) | (supportSubFun02 << 2)  | (supportSubFun03 << 3) | (supportType01 << 4) | (supportType02 << 5) | (supportType03 << 6) | (supressPosResponse << 7);
	commCallBack = callback;
}

void InitSetSessionControlParam(bool supportSub01, bool supportSub02,bool supportSub03, bool sub02SupportedInDefaultSession, bool sub03SupportedInProgramSession, bool supressPosResponse)
{
	SessionSupport = supportSub01 | (supportSub02 << 1 ) | (supportSub03 << 2) | (sub02SupportedInDefaultSession << 3) | (sub03SupportedInProgramSession << 4) | (supressPosResponse << 5);
}

void InitSetTesterPresentSupress(bool supressPosResponse)
{
	TesterPresentSuppport = (supressPosResponse & 0x01);
}

void InitSetDTCControlSupress(bool supressPosResponse)
{
	TesterPresentSuppport |= (supressPosResponse << 1);
}

void InitSetCanDriverVersionDID(uint16_t m_DID)
{
	InitAddDID(m_DID, 3, DriverVersion, REALTIME_DID, NULL, READWRITE, 0, FALSE);
}

void InitSetCanNMVersionDID(uint16_t m_DID)
{
	InitAddDID(m_DID, 3, NMVersion, REALTIME_DID, NULL, READONLY, 0, FALSE);
}

void InitSetCanDiagnosticVersionDID(uint16_t m_DID)
{
	InitAddDID(m_DID,3 , DiagnosticVersion , REALTIME_DID , NULL , READONLY , 0 , FALSE);
}

void InitSetCanDataBaseVersionDID(uint16_t m_DID)
{
	InitAddDID(m_DID,2 , DatabaseVersion , REALTIME_DID , NULL , READONLY , 0 , FALSE);
}

void InitSetCurrentSessionDID(uint16_t m_DID)
{
	InitAddDID(m_DID,1 , &m_CurrSessionType , REALTIME_DID , NULL , READONLY , 0 , FALSE);
}



/************set netwrok layer parameters********/
void Diagnostic_SetNLParam(uint8_t TimeAs, uint8_t TimeBs, uint8_t TimeCr, uint8_t TimeAr, uint8_t TimeBr, uint8_t TimeCs, 
	uint8_t BlockSize, uint8_t m_STmin, uint8_t FillData)
{
	NetworkLayer_SetParam(TimeAs, TimeBs, TimeCr, TimeAr, TimeBs, TimeCs, BlockSize, m_STmin, HALF_DUPLEX, DIAGNOSTIC, N_Sa,  N_Ta, PHYSICAL, 0, FillData);
}

void Diagnostic_Set2ndReqAndResID(uint32_t requestId1, uint32_t responseId1,uint32_t funRequestId1)
{
	TesterPhyID1 = requestId1;
	EcuID1 = responseId1;
	TesterFunID1 = funRequestId1;
	NetworkLayer_SetSecondID(requestId1 , funRequestId1 , responseId1);
}

/*****************************************************************
 **fun            : 璇婃柇閰嶇疆鍒濆鍖栵紝
 **name           : Diagnostic_Init
 **requestId      : 鐗╃悊ID
 **responseId     : ECU鍝嶅簲 ID
 **funRequestId   : 鍔熻兘ID
 **EEPromStartAddr: EEPROM寮�濮嬪湴鍧�
 **EEpromSize     : 绌洪棿澶у皬
 **sendFun        : 鍙戦�佸嚱鏁版帴鍙�
 **p2CanServerMax : 璇婃柇浠姹傚拰 ECU 鍝嶅簲闂寸殑鏃堕棿闂撮殧
 **p2ECanServerMax: 璇婃柇浠帴鏀跺埌鍚﹀畾鐮佷负 78h 鐨勫惁瀹氬搷搴旀姤鏂囧悗绛夊緟鐨勫寮鸿秴鏃舵椂闂撮棿闅�(鍗矱CU鍙戦��0x78鍚﹀畾鍝嶅簲鐨勯棿闅旀椂闂�)
 ****************************************************************/
void Diagnostic_Init(uint32_t requestId, uint32_t responseId, uint32_t funRequestId, uint32_t EEPromStartAddr, uint16_t EEpromSize, SendCANFun sendFun, uint16_t p2CanServerMax, uint16_t p2ECanServerMax)
{
	TesterPhyID = requestId;
	EcuID = responseId;
	TesterFunID = funRequestId;
	
	N_Ta = (uint8_t)EcuID;
	N_Sa = (uint8_t)(EcuID >> 8);
	NetworkLayer_InitParam(TesterPhyID, TesterFunID, EcuID, sendFun);
    #if USE_J1939_DTC
	TPCMSetParamBAM(sendFun);
    #endif
	P2CanServerMax = p2CanServerMax;
	P2ECanServerMax = p2ECanServerMax;
	
	EnableDTCDetect = TRUE;
	SaveDTCInBlock = FALSE;
	DM1DTCNumber = 0;
	HighVoltage = FALSE;
	ResponsePending = FALSE;
	m_CurrSessionType = ECU_DEFAULT_SESSION;
	
	WaitConfirmBeforeJump = FALSE;
	WaitConfimBeforeReset = FALSE;
	SessionSupport = 0;

	#if USE_MALLOC
	DTCHeader = NULL;//DIDList.next = NULL;
	DIDHeader = NULL;//DTCList.next = NULL;
	GroupHeader = NULL;//DTCGroupList.next = NULL;
	#else
	DTCAdded = 0;
	DIDAdded = 0;
	DTCGroupAdded = 0;
	#endif
	ResetTypeSupport = 0;
	ResetCallBackFun = NULL;
	CommTypeSupport = 0;
	commCallBack = NULL;
	ModuleEEpromStartAddr = EEPromStartAddr;
	//EEpromSizeForUse = EEpromSize;
	EEpromUsed = 0;
	memset(UnlockList, 0, sizeof(UnlockList));
	Diagnostic_EEProm_Init();

}
/*========interface for application layer setting diagnostic parameters==============*/
void GenerateSeed(uint8_t *seed, uint32_t length)
{
	uint32_t SystemTick = DiagTimer_GetTickCount();
	#if 0
	seed[0] = 0x01;//0x49;
	seed[1] = 0x02;//0xB4;
	seed[2] = 0x03;//0xE0;
	seed[3] = 0x04;//0x6C;
	#else
	seed[0] = (uint8_t)SystemTick ^ (uint8_t)(SystemTick >> 3);
	seed[1] = (uint8_t)SystemTick ^ (uint8_t)(SystemTick >> 7);
	seed[2] = (uint8_t)SystemTick ^ (uint8_t)(SystemTick >> 11);
	seed[3] = (uint8_t)(SystemTick>>3) ^ (uint8_t)(SystemTick >> 11);
	#endif
}

void GotoSession(SessionType session)
{
	if(session != ECU_DEFAULT_SESSION)
	{
		DiagTimer_Set(&S3serverTimer, 5000);
	}
	else
	{
		/***********when s3 timeout,session change, comunication recover********/
		if(commCallBack != NULL)
		{
			//commCallBack(0x00, 0x03);
		    commCallBack(ERXTX, NWMCM_NCM);
		}
		
		/***********when s3 timeout,session change, DTC enable***********/
		EnableDTCDetect = TRUE;
	}
	m_CurrSessionType = session;
	m_SecurityLevel = LEVEL_ZERO;//session change ECU lock even if from extended session to extended session
	if(m_UnlockStep != WAIT_DELAY)
	{
		m_UnlockStep = WAIT_SEED_REQ;//by ukign 2016.04.01
	}

	if(m_CurrSessionType == ECU_PAOGRAM_SESSION)
	{
		//WaitConfirmBeforeJump = TRUE;//CXL 淇敼
	}
}

void Service10PosResponse(SessionType session)
{
	DiagnosticBuffTX[0] = 0x50;
	DiagnosticBuffTX[1] = session;
	DiagnosticBuffTX[2] = (uint8_t)(P2CanServerMax >> 8);
	DiagnosticBuffTX[3] = (uint8_t)P2CanServerMax;
	DiagnosticBuffTX[4] = (uint8_t)(P2ECanServerMax >> 8);
	DiagnosticBuffTX[5] = (uint8_t)P2ECanServerMax;
	ResponseLength = 6;
}


void Service10Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
    uint8_t SubFunction;
    uint8_t suppressPosRspMsgIndicationBit;
	m_NRC = PR;
	//printf("service 10 handler\r\n");
	if(length == 2)
	{
		if(Service10SupressSupproted())
		{
			SubFunction = *(MessageData + 1) & 0x7F;
			suppressPosRspMsgIndicationBit = *(MessageData + 1) & 0x80;
		}
		else
		{
			SubFunction = *(MessageData + 1);
			suppressPosRspMsgIndicationBit = 0;
		}
		
		switch(SubFunction)/* get sub-function parameter value without bit 7 */
		{
			case ECU_DEFAULT_SESSION: /* test if sub-function parameter value is supported */
				if(!Service10Sub01Supported())
				{
					m_NRC = SFNS;
				}
				break;
			case ECU_EXTENED_SESSION: /* test if sub-function parameter value is supported */
				if(!Service10Sub03Supported())
				{
					m_NRC = SFNS;
				}
				else
				{
					if(m_CurrSessionType == ECU_PAOGRAM_SESSION && !Service10Sub02To03OK())
					{
						m_NRC = SFNSIAS;
					}
				}
				break;
			case ECU_PAOGRAM_SESSION: /* test if sub-function parameter value is supported */
				if(!Service10Sub02Supported())
				{
					m_NRC = SFNS;
				}
				else
				{
					if(m_CurrSessionType == ECU_DEFAULT_SESSION && !Service10Sub01To02OK())
					{
						m_NRC = SFNSIAS;
					}
				}
				break;
			case ECU_FACTORY_SESSION:
				if(N_TAType == PHYSICAL)
				{
					if(m_CurrSessionType == ECU_EXTENED_SESSION)
					{
						
					}
					else
					{
						m_NRC = SFNS;
					}
				}
				else
				{
					m_NRC = SFNS;
				}
				break;
			default:
				m_NRC = SFNS; /* NRC 0x12: sub-functionNotSupported *///
		}
	}
	else
	{
		m_NRC = IMLOIF;
	}
	
	if((suppressPosRspMsgIndicationBit) && (m_NRC == 0x00) && (ResponsePending == FALSE))
	{
		suppressResponse = TRUE; /* flag to NOT send a positive response message */
	}
	else
	{
		suppressResponse = FALSE; /* flag to send the response message */
		Service10PosResponse((SessionType)SubFunction);
	}

	if(m_NRC == PR)
	{
		GotoSession((SessionType)SubFunction);
	}
}

void Service11Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	uint8_t SubFunction;
	uint8_t suppressPosRspMsgIndicationBit;
	m_NRC = PR;
	if(length == 2)
	{
		if(Service11SupressSupported())
		{
			SubFunction = *(MessageData + 1) & 0x7F;
			m_EcuResetType = (EcuResetType)SubFunction;
			suppressPosRspMsgIndicationBit = *(MessageData + 1) & 0x80;
		}
		else
		{
			SubFunction = *(MessageData + 1);
			m_EcuResetType = (EcuResetType)SubFunction;
			suppressPosRspMsgIndicationBit = 0;
		}
		
		switch(SubFunction)/* get sub-function parameter value without bit 7 */
		{
			case HARD_RESET:
				{
					if(!Service11Sub01Supported())
					{
						m_NRC = SFNS;
					}
				}
				break;
			case KEY_OFF_ON_RESET: /* test if sub-function parameter value is supported */
				{
					if(!Service11Sub02Supported())
					{
						m_NRC = SFNS;
					}
				}
				break;
			case SOFT_RESET: /* test if sub-function parameter value is supported */
				{
					if(!Service11Sub03Supported())
					{
						m_NRC = SFNS;
					}
				}
				break;
			case ENABLE_RAPID_POWER_SHUTDOWN:
				{
					if(!Service11Sub04Supported())
					{
						m_NRC = SFNS;
					}
				}
				break;
			case DISABLE_RAPID_POWER_SHUTDOWN:
				{
					if(!Service11Sub05Supported())
					{
						m_NRC = SFNS;
					}
				}
				break;
			default:
				m_NRC = SFNS; /* NRC 0x12: sub-functionNotSupported */
		}
	}
	else
	{
		m_NRC = IMLOIF;
	}
	
	if((suppressPosRspMsgIndicationBit) && (m_NRC == 0x00) && (ResponsePending == FALSE))
	{
		suppressResponse = TRUE; /* flag to NOT send a positive response message */
	}
	else
	{
		suppressResponse = FALSE; /* flag to send the response message */		
		DiagnosticBuffTX[0] = CurrentService + 0x40;
		DiagnosticBuffTX[1] = SubFunction;
		ResponseLength = 2;
	}

	if(m_NRC == PR)
	{
		if(suppressResponse == FALSE)//闇�瑕佹鍝嶅簲鏃讹紝绛夌骇鍝嶅簲缁撴潫
		{
			WaitConfimBeforeReset = TRUE;
		}
		else//涓嶉渶瑕佹鍝嶅簲鏃剁洿鎺ュ浣�
		{
			if(ResetCallBackFun != NULL)
			{
				ResetCallBackFun(m_EcuResetType);
			}
		}
	}
}

void Service27Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	uint8_t SubFunction ;
	uint8_t suppressPosRspMsgIndicationBit;
	m_NRC = PR;
	if(length >= 2)//min length check
	{
		uint8_t index = 0;
		bool subFunctionExist = FALSE;
		bool subFunctionSupInSession = FALSE;
		SubFunction = *(MessageData + 1) & 0x7F;
		suppressPosRspMsgIndicationBit = *(MessageData + 1) & 0x80;
		while(index < 3 && (!subFunctionExist))
		{
			if(UnlockList[index].valid == TRUE && (UnlockList[index].seedID == SubFunction || UnlockList[index].keyID == SubFunction))
			{
				subFunctionExist = TRUE;
				if(m_CurrSessionType == ECU_DEFAULT_SESSION)
				{
					if(UnlockList[index].subFunctionSupported & SUB_DEFAULT)
					{
						subFunctionSupInSession = TRUE;
					}
					else
					{
						subFunctionSupInSession = FALSE;
					}
				}
				else if(m_CurrSessionType == ECU_PAOGRAM_SESSION)
				{
					if(UnlockList[index].subFunctionSupported & SUB_PROGRAM)
					{
						subFunctionSupInSession = TRUE;
					}
					else
					{
						subFunctionSupInSession = FALSE;
					}
				}
				else if(m_CurrSessionType == ECU_EXTENED_SESSION)
				{
					if(UnlockList[index].subFunctionSupported & SUB_EXTENDED)
					{
						subFunctionSupInSession = TRUE;
					}
					else
					{
						subFunctionSupInSession = FALSE;
					}
				}
				else if(m_CurrSessionType == ECU_FACTORY_SESSION)
				{
					if(UnlockList[index].subFunctionSupported & SUB_FACTORY)
					{
						subFunctionSupInSession = TRUE;
					}
					else
					{
						subFunctionSupInSession = FALSE;
					}
				}
			}
			else
			{
				index++;
			}
		}
		
		if(subFunctionExist && subFunctionSupInSession)//sub function check ok
		{
			if(UnlockList[index].seedID == SubFunction)//request seed
			{
				if(length == 2)//length check again
				{
					if(m_UnlockStep == WAIT_DELAY)
					{
						m_NRC = RTDNE;
					}
					else if(m_UnlockStep == UNLOCKED && m_SecurityLevel == UnlockList[index].level)//by ukign 20160401,when ECU unlocked,retrun seed is all zero
					{
						DiagnosticBuffTX[0] = 0x67;
						DiagnosticBuffTX[1] = SubFunction;
						DiagnosticBuffTX[2] = 0;
						DiagnosticBuffTX[3] = 0;
						DiagnosticBuffTX[4] = 0;
						DiagnosticBuffTX[5] = 0;
						ResponseLength = UnlockList[index].KeySize + 2;
					}
					else
					{
						GenerateSeed(Seed,4);
						DiagnosticBuffTX[0] = 0x67;
						DiagnosticBuffTX[1] = SubFunction;
						DiagnosticBuffTX[2] = Seed[0];
						DiagnosticBuffTX[3] = Seed[1];
						if(UnlockList[index].KeySize == 2)
						{
							
						}
						else if(UnlockList[index].KeySize == 4)
						{
							DiagnosticBuffTX[4] = Seed[2];
							DiagnosticBuffTX[5] = Seed[3];
						}
						m_UnlockStep = WAIT_KEY;
						ResponseLength = UnlockList[index].KeySize + 2;
					}
				}
				else
				{
					m_NRC = IMLOIF;
				}
			}
			else if(SubFunction ==  UnlockList[index].keyID)//send key
			{
				if(length == UnlockList[index].KeySize + 2)
				{
					if(m_UnlockStep == WAIT_KEY)
					{
						//uint32_t key1 = UnlockList[index].UnlockFunction(*(uint32_t*)Seed); 
						//*((uint32_t*)key) = UnlockList[index].UnlockFunction(*(uint32_t*)Seed);
					    //uint8_t size=UnlockList[index].KeySize;
					    UnlockList[index].UnlockFunction(Seed, key, UnlockList[index].KeySize);
						//Diagnostic_EEProm_Read(UnlockList[index].FaultCounterAddr, 1, &UnlockList[index].FaultCounter);//CXL 淇敼
						if(((key[0] == *(MessageData + 2) && key[1] == *(MessageData + 3)) && UnlockList[index].KeySize == 2) ||
							((key[0] == *(MessageData + 2) && key[1] == *(MessageData + 3) && key[2] == *(MessageData + 4) && key[3] == *(MessageData + 5)) && UnlockList[index].KeySize == 4))
						{
							m_UnlockStep = UNLOCKED;
							UnlockList[index].FaultCounter = 0;
							m_SecurityLevel = UnlockList[index].level;
							DiagnosticBuffTX[0] = 0x67;
							DiagnosticBuffTX[1] = SubFunction;
							ResponseLength = 2;
						}
						else 
						{
							UnlockList[index].FaultCounter++;
							if(UnlockList[index].FaultCounter >= 3)
							{
								m_NRC = ENOA;
								m_UnlockStep = WAIT_DELAY;
								DiagTimer_Set(&UnlockList[index].SecurityLockTimer, UnlockList[index].UnlockFailedDelayTime);
							}
							else
							{
								m_NRC = IK;
								m_UnlockStep = WAIT_SEED_REQ;
							}
						}
						//Diagnostic_EEProm_Write(UnlockList[index].FaultCounterAddr, 1, &UnlockList[index].FaultCounter);CXL淇敼
					}
					else if(m_UnlockStep == WAIT_DELAY)
					{
						m_NRC = RTDNE;
					}
					else if(m_UnlockStep == WAIT_SEED_REQ)//send key before request seed order error
					{
						m_NRC = RSE;
					}
					else//unlocked condition error
					{
						m_NRC = RSE;
					}
				}
				else
				{
					m_NRC = IMLOIF;
				}
			}
		}
		else
		{
			if(!subFunctionExist)
			{
				m_NRC = SFNS;
			}
			else if(!subFunctionSupInSession)
			{
				m_NRC = SFNSIAS;
			}
		}
	}
	else
	{
		m_NRC = IMLOIF;
	}
	
	if ( (suppressPosRspMsgIndicationBit) && (m_NRC == 0x00) && (ResponsePending == FALSE))
	{
		suppressResponse = TRUE; /* flag to NOT send a positive response message */
	}
	else
	{
		suppressResponse = FALSE; /* flag to send the response message */
	}

}

void Service28Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
    uint8_t SubFunction;
    uint8_t ControlParam;
	uint8_t suppressPosRspMsgIndicationBit;
	m_NRC = PR;
	if(length == 3)
	{
		if(Service28SupressSupported())
		{
			SubFunction = *(MessageData + 1) & 0x7F;
			suppressPosRspMsgIndicationBit = *(MessageData + 1) & 0x80;
		}
		else
		{
			SubFunction = *(MessageData + 1);
			suppressPosRspMsgIndicationBit = 0;
		}
		ControlParam = *(MessageData + 2);
		
		switch(SubFunction)/* get sub-function parameter value without bit 7 */
		{
			case ERXTX:
				{
					if(!Service28Sub00Suppoted())
					{
						m_NRC = SFNS;
					}
				}
				break;
			case ERXDTX: /* test if sub-function parameter value is supported */
				{
					if(!Service28Sub01Suppoted())
					{
						m_NRC = SFNS;
					}
				}
				break;
			case DRXETX: /* test if sub-function parameter value is supported */
				{
					if(!Service28Sub02Suppoted())
					{
						m_NRC = SFNS;
					}
				}
				break;
			case DRXTX: /* test if sub-function parameter value is supported */
				{
					if(!Service28Sub03Suppoted())
					{
						m_NRC = SFNS;
					}
				}
				break;
			default:
				m_NRC = SFNS; /* NRC 0x12: sub-functionNotSupported */
		}
		
		if(m_NRC == 0)
		{
			#if 1
			switch(ControlParam)
			{
				case NCM:
					{
						if(!Service28Type01Suppoted())
						{
							m_NRC = ROOR;
						}
					}
					break;
				case NWMCM: /* test if sub-function parameter value is supported */
					{
						if(!Service28Type02Suppoted())
						{
							m_NRC = ROOR;
						}
					}
					break;
				case NWMCM_NCM: /* test if sub-function parameter value is supported */
					{
						if(!Service28Type03Suppoted())
						{
							m_NRC = ROOR;
						}
					}
					break;
				default:
					m_NRC = ROOR; /* NRC 0x12: sub-functionNotSupported */
			}
			#endif
		}
		
	}
	else
	{
		m_NRC = IMLOIF;
	}
	
	if((suppressPosRspMsgIndicationBit) && (m_NRC == 0x00) && (ResponsePending == FALSE))
	{
		suppressResponse = TRUE; /* flag to NOT send a positive response message */
	}
	else
	{
		suppressResponse = FALSE; /* flag to send the response message */
	}

	if(m_NRC == 0x00)
	{
		if(commCallBack != NULL)
		{
			commCallBack((CommulicationType)SubFunction, (communicationParam)ControlParam);
		}
		DiagnosticBuffTX[0] = CurrentService + 0x40;
		DiagnosticBuffTX[1] = SubFunction;
		DiagnosticBuffTX[2] = ControlParam;//CXL 淇敼
		ResponseLength = 3;
	}
}

void Service3EHandle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
    uint8_t SubFunction;
    uint8_t suppressPosRspMsgIndicationBit;
	m_NRC = PR;
	if(length == 2)
	{
		if(Service3ESupressSupported())
		{
			SubFunction = *(MessageData + 1) & 0x7F;
			suppressPosRspMsgIndicationBit = *(MessageData + 1) & 0x80;
		}
		else
		{
			SubFunction = *(MessageData + 1);
			suppressPosRspMsgIndicationBit = 0;
		}

		if((SubFunction != 0))
		{
			m_NRC = SFNS;
		}
		else
		{
			DiagnosticBuffTX[0] = CurrentService+ 0x40;
			DiagnosticBuffTX[1] = SubFunction;
			ResponseLength = 2;
		}

	}
	else
	{
		m_NRC = IMLOIF;
	}
	
	if((suppressPosRspMsgIndicationBit) && (m_NRC == 0x00) && (ResponsePending == FALSE))
	{
		suppressResponse = TRUE; /* flag to NOT send a positive response message */
	}
	else
	{
		suppressResponse = FALSE; /* flag to send the response message */
	}
}

void Service83Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	
}

void Service84Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	
}

void Service85Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
    uint8_t SubFunction;
    uint8_t suppressPosRspMsgIndicationBit;
	m_NRC = PR;
	if(length == 2)
	{
		if(Service85SupressSupported())
		{
			SubFunction = *(MessageData + 1) & 0x7F;
			suppressPosRspMsgIndicationBit = *(MessageData + 1) & 0x80;
		}
		else
		{
			SubFunction = *(MessageData + 1);
			suppressPosRspMsgIndicationBit = 0;
		}
		
		switch(SubFunction)/* get sub-function parameter value without bit 7 */
		{
			case 0x01:
				{
					EnableDTCDetect = TRUE;
					DiagnosticBuffTX[0] = CurrentService + 0x40;
					DiagnosticBuffTX[1] = SubFunction;
					ResponseLength = 2;
				}
				break;
			case 0x02: /* test if sub-function parameter value is supported */
				{
					EnableDTCDetect = FALSE;
					DiagnosticBuffTX[0] = CurrentService + 0x40;
					DiagnosticBuffTX[1] = SubFunction;
					ResponseLength = 2;
				}
				break;
			default:
				m_NRC = SFNS; /* NRC 0x12: sub-functionNotSupported */
		}
	}
	else
	{
		m_NRC = IMLOIF;
	}
	
	if ((suppressPosRspMsgIndicationBit) && (m_NRC == 0x00) && (ResponsePending == FALSE))
	{
		suppressResponse = TRUE; /* flag to NOT send a positive response message */
	}
	else
	{
		suppressResponse = FALSE; /* flag to send the response message */
	}
}

void Service86Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	
}

void Service87Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	
}

/*****************************************************************
 **fun    : 鏌ヨDID鏁版嵁鍒楄〃
 **name   : SearchDidNode
 **param0 : DID:褰撳墠DID
 **return : 鏃�
 ****************************************************************/
DIDNode* SearchDidNode(uint16_t DID)
{
	#if USE_MALLOC
	DIDNode *tmpNode = DIDHeader;
	while(tmpNode != NULL)
	{
		if(tmpNode->ID == DID)
		{
			return tmpNode;
		}
		else
		{
			tmpNode = tmpNode->next;
		}
	}
	return NULL;
	#else
	uint8_t i;
	for(i = 0; i < DIDAdded; i++)
	{
		if(DIDS[i].ID == DID)
		{
			return DIDS + i;
		}
	}
	return NULL;
	#endif
}

void Service22Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	bool suppressPosRspMsgIndicationBit = FALSE;
	m_NRC = PR;
	if(length == 3)
	{
		uint16_t DID = (*(MessageData + 1) << 8) + *(MessageData + 2);
		DIDNode* didNode = SearchDidNode(DID);
		if(didNode == NULL)
		{
			m_NRC = ROOR;//PID not in our PID list
		}
		else if(didNode->didType == IO_DID)
		{
			if(didNode->RWAttr == WRITEONLY)
			{
				m_NRC = ROOR;//mabe a IO Control DID
			}
			else
			{
				DiagnosticBuffTX[0] = 0x62;
				DiagnosticBuffTX[1] = *(MessageData + 1);
				DiagnosticBuffTX[2] = *(MessageData + 2);
				memcpy(DiagnosticBuffTX + 3, didNode->dataPointer, didNode->dataLength);
				
				ResponseLength = didNode->dataLength + 3;
			}
		}
		else
		{
			if(didNode->RWAttr == WRITEONLY)
			{
				m_NRC = ROOR;//this DID maybe supported by 2E service but not supported by 22 service
			}
			else
			{
				DiagnosticBuffTX[0] = 0x62;
				DiagnosticBuffTX[1] = *(MessageData + 1);
				DiagnosticBuffTX[2] = *(MessageData + 2);
				if(didNode->didType == EEPROM_DID)
				{
					Diagnostic_EEProm_Read(didNode->EEpromAddr, didNode->dataLength, DiagnosticBuffTX+3);
				    //Diagnostic_EEProm_Read(EepromReadArray, didNode->dataLength, DiagnosticBuffTX+3);
				}
				else
				{
					memcpy(DiagnosticBuffTX+3 , didNode->dataPointer ,didNode->dataLength);
				}
				ResponseLength = didNode->dataLength+1 + 3;//CXL 淇敼
			}
		}
	}
	else
	{
		m_NRC = IMLOIF;
	}

	if((suppressPosRspMsgIndicationBit) && (m_NRC == 0x00) && (ResponsePending == FALSE))
	{
		suppressResponse = TRUE; /* flag to NOT send a positive response message */
	}
	else
	{
		suppressResponse = FALSE; /* flag to send the response message */
	}
}

void Service23Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	
}

void Service24Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	
}

void Service2AHandle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	
}

void Service2CHandle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	
}


void Service2EHandle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	bool suppressPosRspMsgIndicationBit = FALSE;
	m_NRC = PR;
	if(length >= 3)
	{
		uint16_t DID = (*(MessageData + 1) << 8) + *(MessageData + 2);
		DIDNode* didNode = SearchDidNode(DID);
		if(didNode == NULL)
		{
			m_NRC = ROOR;//PID not in our PID list
		}
		else if(didNode->didType == IO_DID)
		{
			m_NRC = ROOR;//mabe a IO Control DID
		}
		else if(didNode->didType == REALTIME_DID)
		{
			if(didNode->dataLength + 3 == length)
			{
				if(m_CurrSessionType != ECU_FACTORY_SESSION)
				{
					memcpy(didNode->dataPointer, MessageData + 3, didNode->dataLength);
					DiagnosticBuffTX[0] = 0x6E;
					DiagnosticBuffTX[1] = *(MessageData + 1);
					DiagnosticBuffTX[2] = *(MessageData + 2);
					ResponseLength = 3;
				}
				else
				{
					m_NRC = ROOR;//fatcory mode not support realtime DID write
				}
			}
			else
			{
				m_NRC = IMLOIF;
			}
		}
		else if(didNode->didType == EEPROM_DID)
		{
			if(didNode->RWAttr == READONLY)
			{
				if(didNode->SupportWriteInFactoryMode == TRUE && m_CurrSessionType == ECU_FACTORY_SESSION)
				{
					if(m_SecurityLevel == LEVEL_FOUR)
					{
						if(didNode->dataLength + 3 == length)
						{
							//Diagnostic_EEProm_Write(didNode->EEpromAddr, didNode->dataLength , MessageData + 3);
						    Diagnostic_EEProm_Write(EepromWriteArray, didNode->dataLength , MessageData + 3);
							DiagnosticBuffTX[0] = 0x6E;
							DiagnosticBuffTX[1] = *(MessageData + 1);
							DiagnosticBuffTX[2] = *(MessageData + 2);
							ResponseLength = 3;
						}
						else
						{
							m_NRC = IMLOIF;
						}
					}
					else
					{
						m_NRC = SAD;
					}
				}
				else
				{
					m_NRC = ROOR;//this DID maybe supported by 22 service but not supported by 2E service
				}
			}
			else 
			{
				if(didNode->dataLength + 3 == length)
				{
					if(m_CurrSessionType == ECU_FACTORY_SESSION)
					{
						m_NRC = ROOR;
					}
					else
					{
						//Diagnostic_EEProm_Write(didNode->EEpromAddr, didNode->dataLength , MessageData + 3);
					    Diagnostic_EEProm_Write(EepromWriteArray, didNode->dataLength, MessageData + 3);
						DiagnosticBuffTX[0] = 0x6E;
						DiagnosticBuffTX[1] = *(MessageData + 1);
						DiagnosticBuffTX[2] = *(MessageData + 2);
						ResponseLength = 3;
					}
				}
				else
				{
					m_NRC = IMLOIF;
				}
			}
		}
	}
	else
	{
		m_NRC = IMLOIF;
	}
	
	if((suppressPosRspMsgIndicationBit) && (m_NRC == 0x00) && (ResponsePending == FALSE))
	{
		suppressResponse = TRUE; /* flag to NOT send a positive response message */
	}
	else
	{
		suppressResponse = FALSE; /* flag to send the response message */
	}
}


void Service3DHandle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	
}

bool SearchDTCGroup(uint32_t group)
{
	#if USE_MALLOC
	DTCGroupNode *temp = GroupHeader;
	bool GroupFound = FALSE;
	while(temp !=NULL && GroupFound == FALSE)
	{
		if(temp->GroupID == group)
		{
			return TRUE;
		}
		else
		{
			temp = temp->next;
		}
	}
	return FALSE;
	
	#else
	
	uint8_t i;
	for(i = 0; i < DTCGroupAdded; i++)
	{
		if(DTCGROUPS[i].GroupID == group)
		{
			return TRUE;
		}
	}
	return FALSE;
	#endif
}


void Service14Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	m_NRC = PR;
	suppressResponse = FALSE;
	uint32_t Group;
	uint32_t  Test;
	if(length == 4)
	{
	    Test = *(MessageData + 1);
		Group  = Test << 16;//(uint32)(*(MessageData + 1) << 16);
		Group += *(MessageData + 2) << 8;
		Group += *(MessageData + 3);
		Group = Group & 0xFFFFFF;
		
		if(SearchDTCGroup(Group))//14229-1 page 183,send pos even if no DTCS are stored
		{
			DiagnosticBuffTX[0] = CurrentService + 0x40;
			ResponseLength = 1;
			Diagnostic_ClearDTC(Group);
		}
		else
		{
			m_NRC = ROOR;
		}
	}
	else
	{
		m_NRC = IMLOIF;
	}
}

void SearchDTCByMaskAndFillResponse(uint8_t mask)
{
	#if USE_MALLOC
	DTCNode* tmpNode = DTCHeader;
	while(tmpNode != NULL)
	{
		if((tmpNode->DTCStatus.DTCStatusByte & mask & DtcAvailibaleMask) != 0)
		{
			DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(tmpNode->DTCCode >> 16);
			DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(tmpNode->DTCCode >> 8);
			DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(tmpNode->DTCCode);
			DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(tmpNode->DTCStatus.DTCStatusByte & DtcAvailibaleMask);
		}
		tmpNode = tmpNode->next;		
	}
	#else
	uint8_t i;
	for(i = 0 ; i < DTCAdded;i++)
	{
		if((DTCS[i].DTCStatus.DTCStatusByte & mask & DtcAvailibaleMask) != 0)
		{
			DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(DTCS[i].DTCCode >> 16);
			DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(DTCS[i].DTCCode >> 8);
			DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(DTCS[i].DTCCode);
			DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(DTCS[i].DTCStatus.DTCStatusByte & DtcAvailibaleMask);
		}
	}
	#endif
}

void FillAllDTCResponse()
{
	#if USE_MALLOC
	DTCNode* tmpNode = DTCHeader;
	while(tmpNode != NULL)
	{
		DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(tmpNode->DTCCode >> 16);
		DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(tmpNode->DTCCode >> 8);
		DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(tmpNode->DTCCode);
		DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(tmpNode->DTCStatus.DTCStatusByte & DtcAvailibaleMask);
		tmpNode = tmpNode->next;		
	}
	#else
	uint8_t i;
	for(i = 0 ; i < DTCAdded;i++)
	{
		DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(DTCS[i].DTCCode >> 16);
		DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(DTCS[i].DTCCode >> 8);
		DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(DTCS[i].DTCCode);
		DiagnosticBuffTX[ResponseLength++] =  (uint8_t)(DTCS[i].DTCStatus.DTCStatusByte & DtcAvailibaleMask);
	}
	#endif
}

uint16_t GetDTCNumberByMask(uint8_t mask)
{
	#if USE_MALLOC
	DTCNode* tmpNode = DTCHeader;
	uint16_t number = 0;
	while(tmpNode != NULL)
	{
		if((tmpNode->DTCStatus.DTCStatusByte & mask & DtcAvailibaleMask) != 0)
		{
			number++;
		}
		tmpNode = tmpNode->next;		
	}
	return number;
	#else
	uint8_t i;
	uint16_t number = 0;
	for(i = 0; i < DTCAdded ; i++)
	{

		if((DTCS[i].DTCStatus.DTCStatusByte & mask & DtcAvailibaleMask) != 0)
		{
			number++;
		}
	}
	return number;
	#endif
}

DTCNode* GetDTCNodeByCode(uint32_t dtcCode)
{
	#if USE_MALLOC
	return NULL;
	#else
	uint8_t i;
	for(i = 0 ; i < DTCAdded;i++)
	{	
		if((DTCS[i].DTCCode & 0xFFFFFF) == (dtcCode & 0xFFFFFF))
		{
			return DTCS+i;
		}
	}
	return NULL;
	#endif
}

void FillDTCSnapshotReponse(uint16_t EEPromAddr, uint8_t ReordMask)
{
	uint8_t i;
	uint8_t snapshotRecordNumber = 0;
	ResponseLength = 8;
	if(ReordMask != 0xFF)
	{
		for(i = 0 ; i < SnapShotAdded ; i++)
		{
			if(SnapShots[i].snapshotRecord == ReordMask)
			{
				snapshotRecordNumber++;
				DiagnosticBuffTX[ResponseLength] = (uint8_t)(SnapShots[i].snapshotID >> 8);
				DiagnosticBuffTX[ResponseLength + 1] = (uint8_t)(SnapShots[i].snapshotID);
				ResponseLength += 2;
				Diagnostic_EEProm_Read(&EEPromAddr, SnapShots[i].dataLength, DiagnosticBuffTX + ResponseLength);
				ResponseLength += SnapShots[i].dataLength;
			}
		}
		DiagnosticBuffTX[7]  = snapshotRecordNumber;
	}
	else
	{
		uint8_t currentRecord = SnapShots[0].snapshotRecord;
		uint8_t currentRecordNumber = 0;
		uint8_t currentRecordSizeIndex = 7;
		for(i = 0 ; i < SnapShotAdded ; i++)
		{
			if(SnapShots[i].snapshotRecord == currentRecord)
			{
				currentRecordNumber++;
				DiagnosticBuffTX[ResponseLength] = (uint8_t)(SnapShots[i].snapshotID >> 8);
				DiagnosticBuffTX[ResponseLength + 1] = (uint8_t)(SnapShots[i].snapshotID);
				ResponseLength += 2;
				Diagnostic_EEProm_Read(&EEPromAddr, SnapShots[i].dataLength, DiagnosticBuffTX + ResponseLength);
				ResponseLength += SnapShots[i].dataLength;
			}
			else
			{
				currentRecord = SnapShots[i].snapshotRecord;
				DiagnosticBuffTX[currentRecordSizeIndex] = currentRecordNumber;
				currentRecordSizeIndex = ResponseLength;
				ResponseLength++;
				currentRecordNumber = 1;
				DiagnosticBuffTX[ResponseLength] = (uint8_t)(SnapShots[i].snapshotID >> 8);
				DiagnosticBuffTX[ResponseLength + 1] = (uint8_t)(SnapShots[i].snapshotID);
				ResponseLength += 2;
				Diagnostic_EEProm_Read(&EEPromAddr, SnapShots[i].dataLength, DiagnosticBuffTX + ResponseLength);
				ResponseLength += SnapShots[i].dataLength;
			}
		}
		DiagnosticBuffTX[currentRecordSizeIndex]  = currentRecordNumber;
	}
}

void Service19Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	uint8_t SubFunction;
	uint8_t suppressPosRspMsgIndicationBit;
	uint8_t mask = *(MessageData + 2);
	m_NRC = PR;
	if(length >= 2)
	{
		SubFunction = *(MessageData + 1);
		suppressPosRspMsgIndicationBit = FALSE;
		switch(SubFunction)
		{
			case REPORT_DTCNUMBER_BY_MASK:
				{
					if(length == 3)
					{
						uint16_t number= GetDTCNumberByMask(mask);
						DiagnosticBuffTX[0]  = 0x59;
						DiagnosticBuffTX[1]  = 0x01;
						DiagnosticBuffTX[2]  = DtcAvailibaleMask;
						DiagnosticBuffTX[3]  = 0x00;//ISO15031 DTCFormat
						DiagnosticBuffTX[4]  = (uint8_t)(number >> 8);
						DiagnosticBuffTX[5]  = (uint8_t)(number);
						ResponseLength = 6;
					}
					else
					{
						m_NRC = IMLOIF;
					}
				}
				break;
			case REPORT_DTCCODE_BY_MASK: /* test if sub-function parameter value is supported */
				{
					if(length == 3)
					{
						DiagnosticBuffTX[0]  = CurrentService  + 0x40;
						DiagnosticBuffTX[1]  = SubFunction;
						DiagnosticBuffTX[2]  = DtcAvailibaleMask;
						ResponseLength = 3;
						SearchDTCByMaskAndFillResponse(mask);
					}
					else
					{
						m_NRC = IMLOIF;
					}
				}
				break;
			case REPORT_DTCSNAPSHOT_BY_ID: /* test if sub-function parameter value is supported */
				{
					m_NRC = SFNS;
				}
				break;
			case REPORT_DTCSNAPSHOT_BY_DTCNUMBER:
				{
					if(length == 6)
					{
						uint32_t dtcCode = (*(uint32_t*)(MessageData + 1));
						DTCNode* tempNode = GetDTCNodeByCode(dtcCode);
						if(tempNode != NULL)
						{
							//Snapshot matchedSnaptshot;
							DiagnosticBuffTX[0]  = CurrentService  + 0x40;
							DiagnosticBuffTX[1]  = SubFunction;
							DiagnosticBuffTX[2]  = (uint8_t)(tempNode->DTCCode >> 16);
							DiagnosticBuffTX[3]  = (uint8_t)(tempNode->DTCCode >> 8);
							DiagnosticBuffTX[4]  = (uint8_t)(tempNode->DTCCode);
							DiagnosticBuffTX[5]  = (tempNode->DTCStatus.DTCStatusByte) & DtcAvailibaleMask;
							DiagnosticBuffTX[6]  = *(MessageData + 5);
							ResponseLength = 7;
							FillDTCSnapshotReponse(tempNode->SnapShotEEpromAddr , *(MessageData + 5));
							if(DiagnosticBuffTX[7] == 0)
							{
								m_NRC = ROOR;
							}
						}
						else
						{
							m_NRC = ROOR;
						}
					}
					else
					{
						m_NRC = IMLOIF;
					}
				}
				break;
			case REPORT_DTCEXTEND_DATA_BY_DTCNUMBER:
				{
					if(length == 6)
					{
						uint32_t dtcCode = (*(uint32_t*)(MessageData + 1));
						DTCNode* tempNode = GetDTCNodeByCode(dtcCode);
						if(tempNode != NULL)
						{
							//Snapshot matchedSnaptshot;
							uint8_t DataRecordNumber = *(MessageData + 5);
							DiagnosticBuffTX[0]  = CurrentService  + 0x40;
							DiagnosticBuffTX[1]  = SubFunction;
							DiagnosticBuffTX[2]  = (uint8_t)(tempNode->DTCCode >> 16);
							DiagnosticBuffTX[3]  = (uint8_t)(tempNode->DTCCode >> 8);
							DiagnosticBuffTX[4]  = (uint8_t)(tempNode->DTCCode);
							DiagnosticBuffTX[5]  = (tempNode->DTCStatus.DTCStatusByte) & DtcAvailibaleMask;
							ResponseLength = 6;
							
							if(DataRecordNumber == 0xFF)
							{
								if(AgingCounterRecord != 0)
								{
									DiagnosticBuffTX[ResponseLength++] = AgingCounterRecord;
									DiagnosticBuffTX[ResponseLength++] = tempNode->OldCounter;
								}
								
								if(AgedCounterRecord != 0)
								{
									DiagnosticBuffTX[ResponseLength++] = AgedCounterRecord;
									DiagnosticBuffTX[ResponseLength++] = tempNode->GoneCounter;
								}

								if(OccurenceCounterRecord != 0)
								{
									DiagnosticBuffTX[ResponseLength++] = OccurenceCounterRecord;
									DiagnosticBuffTX[ResponseLength++] = tempNode->FaultOccurrences;
								}

								if(PendingCounterRecord != 0)
								{
									DiagnosticBuffTX[ResponseLength++] = PendingCounterRecord;
									DiagnosticBuffTX[ResponseLength++] = tempNode->TripCounter;
								}
							}
							else if(DataRecordNumber == 0)
							{
								m_NRC = ROOR;
							}
							else if(DataRecordNumber == AgingCounterRecord)
							{
								DiagnosticBuffTX[ResponseLength++] = AgingCounterRecord;
								DiagnosticBuffTX[ResponseLength++] = tempNode->OldCounter;
							}
							else if(DataRecordNumber == AgedCounterRecord)
							{
								DiagnosticBuffTX[ResponseLength++] = AgedCounterRecord;
								DiagnosticBuffTX[ResponseLength++] = tempNode->GoneCounter;
							}
							else if(DataRecordNumber == OccurenceCounterRecord)
							{
								DiagnosticBuffTX[ResponseLength++] = OccurenceCounterRecord;
								DiagnosticBuffTX[ResponseLength++] = tempNode->FaultOccurrences;
							}
							else if(DataRecordNumber == PendingCounterRecord)
							{
								DiagnosticBuffTX[ResponseLength++] = PendingCounterRecord;
								DiagnosticBuffTX[ResponseLength++] = tempNode->TripCounter;
							}
							else
							{
								m_NRC = ROOR;
							}
						}
						else
						{
							m_NRC = ROOR;
						}
					}
					else
					{
						m_NRC = IMLOIF;
					}
				}
				break;
			case REPORT_SUPPORTED_DTC:
				{
					if(length == 2)
					{
						DiagnosticBuffTX[0]  = CurrentService + 0x40;
						DiagnosticBuffTX[1]  = SubFunction;
						DiagnosticBuffTX[2]  = DtcAvailibaleMask;
						ResponseLength = 3;
						FillAllDTCResponse();
					}
					else
					{
						m_NRC = IMLOIF;
					}
				}
				break;
			default:
				m_NRC = SFNS; /* NRC 0x12: sub-functionNotSupported */
		}
	}
	else
	{
		m_NRC = IMLOIF;
	}
	
	if ( (suppressPosRspMsgIndicationBit) && (m_NRC == 0x00) && (ResponsePending == FALSE))
	{
		suppressResponse = TRUE; /* flag to NOT send a positive response message */
	}
	else
	{
		suppressResponse = FALSE; /* flag to send the response message */
	}
}


void Service2FHandle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	uint8_t suppressPosRspMsgIndicationBit = FALSE;
	m_NRC = PR;
	if(length >= 4)
	{
		uint16_t PID = (*(MessageData + 1) << 8) | *(MessageData + 2);
		uint8_t control = *(MessageData + 3);
		DIDNode* didNode = SearchDidNode(PID);
		if(didNode == NULL)
		{
			m_NRC = ROOR;//PID not in our PID list
		}
		else if(didNode->didType != IO_DID)
		{
			m_NRC = ROOR;//mabe a IO Control DID
		}
		else
		{
			if(length == 4)
			{
				if(control == 0 || control == 1 || control == 2)
				{
					DiagnosticBuffTX[0] = 0x6F;
					DiagnosticBuffTX[1] = *(MessageData + 1);
					DiagnosticBuffTX[2] = *(MessageData + 2);
					DiagnosticBuffTX[3] = control;
					DiagnosticBuffTX[4] = didNode->Callback(control , 0);
					ResponseLength = 5;
				}
				else
				{
					m_NRC = IMLOIF;
				}
			}
			else if(length == 5)
			{
				if(control == 3)
				{
					uint8_t param = *(MessageData + 4);
					DiagnosticBuffTX[0] = 0x6F;
					DiagnosticBuffTX[1] = *(MessageData + 1);
					DiagnosticBuffTX[2] = *(MessageData + 2);
					DiagnosticBuffTX[3] = control;
					DiagnosticBuffTX[4] = didNode->Callback(control , param);
					ResponseLength = 5;
				}
				else
				{
					m_NRC = IMLOIF;
				}
			}
			else
			{
				m_NRC = IMLOIF;
			}
		}
	}
	else
	{
		m_NRC = IMLOIF;
	}

	if ( (suppressPosRspMsgIndicationBit) && (m_NRC == 0x00) && (ResponsePending == FALSE))
	{
		suppressResponse = TRUE; /* flag to NOT send a positive response message */
	}
	else
	{
		suppressResponse = FALSE; /* flag to send the response message */
	}
}

void Service31Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	#if 1
    m_NRC = PR;//CXL 淇敼
	//uint8_t ServiceName = *MessageData;
	uint8_t SubFunction =  *(MessageData + 1);
	uint16_t Routine = (*(MessageData + 2) << 8) | *(MessageData + 3);
	if(length == 4)
	{
		if(SubFunction == 1)
		{
			//Printf("routine = %x\r\n",Routine);
			if(Routine == 0xFF00)//鍒犻櫎鍐呭瓨
			{
				if(1)//if(GlobalDTCControlParam.DataBits.SystemState == SYSTEM_BOOT)
				{
					WaitConfirmBeforeErase = TRUE;
					//IsUpdating = TRUE;
					m_NRC = RCRRP;
					//ServiceNegReponse(ServiceName,m_NRC);
				}
				else
				{
				    m_NRC = CNC;
					//ServiceNegReponse(ServiceName,m_NRC);//not in bootloader
				}
			}
			else if(Routine == 0xFF01)//杞欢鍏煎鎬ф鏌�
			{
			    //uint32_t RxCRC0 = 0;
			    //uint32_t AppCRC0;
			    DiagnosticBuffTX[0] = 0x71;
			    DiagnosticBuffTX[1] = 0x01;
			    DiagnosticBuffTX[2] = 0xFF;
			    DiagnosticBuffTX[3] = 0x01;
			    ResponseLength = 5;//CXL 淇敼
			    #ifdef BOOTLOADER

			    //AppCRC = CalcAppCanCRC();//CalcAppCRC();
			    //RxCRC = (*(MessageData + 4) << 24) + (*(MessageData + 5) << 16) + (*(MessageData + 6) << 8) + *(MessageData + 7);
			    if(1)//(RxCRC0 == AppCRC0)
			    {
			         //WriteCanCRC(RxCRC);//WriteCRC(RxCRC);
			         //Printf("app CRC  %.8x = RXCRC %.8x\r\n",AppCRC,RxCRC );
			         DiagnosticBuffTX[4] = 0x00;
			         //Diagnostic_UpdatePromgramTimes();
			    }
			    else
			    {
			         //Printf("app CRC  %.8x != RXCRC %.8x\r\n",AppCRC,RxCRC );
			         DiagnosticBuffTX[4] = 0x01;
			    }
			         //N_USData_request(DIAGNOSTIC , N_Sa ,  N_Ta , PHYSICAL , 0 , DiagnosticBuffTX , 5);
			    #else
			    m_NRC = CNC;
			    //ServiceNegReponse(ServiceName,CNC);
			    #endif
			    //TODO:verify app
			}
            else
            {
                m_NRC = ROOR;
                //ServiceNegReponse(ServiceName,ROOR);//no more routine except 0xFF00
            }

		}
		else if(SubFunction == 3)
		{
		    m_NRC = CNC;
			//ServiceNegReponse(ServiceName,m_NRC);
		}
		else
		{
		    m_NRC = SFNS;
			//ServiceNegReponse(ServiceName,m_NRC);
		}
	}
	else if(length == 8)
	{
		if(SubFunction == 1)
		{

		    if(Routine == 0x0202)//杞欢瀹屾暣鎬ф鏌�
            {
                uint32_t RxCRC = 0;
                uint32_t AppCRC;
                DiagnosticBuffTX[0] = 0x71;
                DiagnosticBuffTX[1] = 0x01;
                DiagnosticBuffTX[2] = 0x02;
                DiagnosticBuffTX[3] = 0x02;
                ResponseLength = 5;//CXL 淇敼
                #ifdef BOOTLOADER

                AppCRC = CRC32_Calculate((const uint8_t*)iap_start_adddress, total_iap_length, 0xFFFFFFFF);//CalcAppCanCRC();//CalcAppCRC();
                RxCRC = (*(MessageData + 4) << 8) + *(MessageData + 5);
                RxCRC = RxCRC << 16;
                RxCRC += *(MessageData + 6) << 8;
                RxCRC += *(MessageData + 7);

                if(RxCRC == AppCRC)
                {
                    //WriteCanCRC(RxCRC);//WriteCRC(RxCRC);
                    //Printf("app CRC  %.8x = RXCRC %.8x\r\n",AppCRC,RxCRC );
                    DiagnosticBuffTX[4] = 0x00;
                    //Diagnostic_UpdatePromgramTimes();
                }
                else
                {
                    //Printf("app CRC  %.8x != RXCRC %.8x\r\n",AppCRC,RxCRC );
                    DiagnosticBuffTX[4] = 0x01;
                }
                //N_USData_request(DIAGNOSTIC , N_Sa ,  N_Ta , PHYSICAL , 0 , DiagnosticBuffTX , 5);
                #else
                    m_NRC = CNC;
                    //ServiceNegReponse(ServiceName,CNC);
                #endif
                //TODO:verify app
            }
			else
			{
			    m_NRC = ROOR;
				//ServiceNegReponse(ServiceName,ROOR);//no more routine except 0xFF00
			}
		}
		else if(SubFunction == 3)
		{
		    m_NRC = CNC;
			//ServiceNegReponse(ServiceName,CNC);
		}
		else
		{
		    m_NRC = SFNS;
			//ServiceNegReponse(ServiceName,SFNS);
		}
	}
	else
	{
	    m_NRC = IMLOIF;
		//ServiceNegReponse(ServiceName,IMLOIF);
	}
	#endif
}

void Service34Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	#if 1
	//uint8_t ServiceName = *MessageData;
    m_NRC = PR;//CXL 淇敼
	uint8_t SubFunction =  *(MessageData + 1);
	uint8_t DataLengthID = *(MessageData + 2);
	if(length == 11)
	{
		if(SubFunction == 0x00)
		{
			if(DataLengthID == 0x44)
			{
				if(1)//if(GlobalDTCControlParam.DataBits.SystemState == SYSTEM_BOOT)
				{
				    ProgramAddress = (*(MessageData + 3) << 8) + *(MessageData + 4);
				    ProgramAddress = ProgramAddress << 16;
                    ProgramAddress += (*(MessageData + 5) << 8);
                    ProgramAddress += (*(MessageData + 6));
					ProgramLength = (*(MessageData + 7) << 8) + *(MessageData + 8);
					ProgramLength = ProgramLength << 16;
					ProgramLength += (*(MessageData + 9) << 8);
					ProgramLength +=*(MessageData + 10);
					//Printf("request program addr:%.8x,len:%.8x\r\n",ProgramAddress,ProgramLength);
					#ifdef BOOTLOADER
					if(ProgramAddress == FLASH_START_ADDRESS && (ProgramAddress+ProgramLength <= FLASH_STOP_ADDRESS))
					{
					    //iap_start_adddress = ProgramAddress;
					    //total_iap_length = ProgramLength;

						m_BlockIndex = 0;
						ResponseLength = 6;//CXL 淇敼
						DiagnosticBuffTX[0] = 0x74;
						DiagnosticBuffTX[1] = 0x00;//0x20;
						DiagnosticBuffTX[2] = 0x00;
						DiagnosticBuffTX[3] = 0x00;
						DiagnosticBuffTX[4] =  (MAX_DOWNLOADING_BUF >> 8) & 0xFF;
						DiagnosticBuffTX[5] = MAX_DOWNLOADING_BUF & 0xFF;
						//N_USData_request(DIAGNOSTIC, N_Sa, N_Ta, PHYSICAL, 0, DiagnosticBuffTX, 4);
					}
					else
					{
					    m_NRC = UDNA;
						//ServiceNegReponse(ServiceName,UDNA);
					}
					#endif
				}
				else
				{
				    m_NRC = UDNA;
					//ServiceNegReponse(ServiceName,UDNA);//not in bootloader
				}
			}
			else
			{
			    m_NRC = ROOR;
				//ServiceNegReponse(ServiceName,ROOR);
			}
		}
		else
		{
		    m_NRC = SFNS;
			//ServiceNegReponse(ServiceName,SFNS);
		}
	}
	else
	{
	    m_NRC = IMLOIF;
		//ServiceNegReponse(ServiceName,IMLOIF);
	}
	#endif
}

void Service35Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	
}

void Service36Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	#if 1
	//uint8_t ServiceName = *MessageData;
    m_NRC = PR;//CXL 淇敼
	uint8_t BLockIndex = *(MessageData + 1);
	uint8_t status;
	if(length <= MAX_DTCDATA_BUF)
	{
		if(1)//(GlobalDTCControlParam.DataBits.Downloading == TRUE || ProgramAddress < 0x800A000)
		{
			//printf("rx block %2x != %2x\r\n",BLockIndex,m_BlockIndex);
			if(BLockIndex == ((m_BlockIndex + 1) & 0xFF))
			{
				m_BlockIndex = BLockIndex;
				if(HighVoltage == TRUE)
				{
				    m_NRC = VTH;
					//ServiceNegReponse(ServiceName,VTH);
				}
				else if(LowVoltage == TRUE)
				{
				    m_NRC = VTL;
					//ServiceNegReponse(ServiceName,VTL);
				}
				else
				{
					#ifdef BOOTLOADER
					if(ProgramLength > ProgramLengthComplete)
					{
						//printf("36 service will program %d bytes , address:%.8x \r\n",length-2,ProgramAddress + ProgramLengthComplete);
					    DINT;
					    status = Example_ProgramUsingAutoECC(ProgramAddress, (MessageData + 2), ((length - 2)/2));
					    ProgramAddress = ProgramAddress + ((length - 2)/2);//CXL 淇敼
					    EINT;
						if(!status)//(Update_WriteData(ProgramAddress + ProgramLengthComplete, MessageData + 2 , length - 2) == 0)
						{
							ProgramLengthComplete += ((length - 2)/2);
							DiagnosticBuffTX[0] = 0x76;
							DiagnosticBuffTX[1] = BLockIndex;
							ResponseLength = 2;//CXL 淇敼
							//N_USData_request(DIAGNOSTIC , N_Sa ,  N_Ta , PHYSICAL , 0 , DiagnosticBuffTX , 2);
						}
						else
						{
							m_BlockIndex = 0;
							m_NRC = GPF;
							//ServiceNegReponse(ServiceName,GPF);//program error
						}
					}
					else
					{
						m_BlockIndex = 0;
						m_NRC = TDS;
						//ServiceNegReponse(ServiceName,TDS);//program complete
					}
					#endif
				}
			}
			else
			{
			    m_NRC = WBSC;
				//ServiceNegReponse(ServiceName,WBSC);
			}
		}
		else
		{
		    m_NRC = RSE;
			//ServiceNegReponse(ServiceName,RSE);//not downloading not accept or address incorrect
		}
	}
	else
	{
	    m_NRC = IMLOIF;
		//ServiceNegReponse(ServiceName,IMLOIF);//length error buff will overflow
	}
	#endif
}

void Service37Handle(uint8_t N_TAType, uint16_t length, uint8_t *MessageData)
{
	#if 1
	//uint8_t ServiceName = *MessageData;
	m_NRC = PR;//CXL 淇敼
	if(length == 1)
	{
		if(1)//(GlobalDTCControlParam.DataBits.Downloading == TRUE)
		{
			//GlobalDTCControlParam.DataBits.Downloading = FALSE;
			if(1)//if(GlobalDTCControlParam.DataBits.SystemState == SYSTEM_BOOT)
			{
				ProgramAddress = 0;
				ProgramLength = 0;
				ProgramLengthComplete = 0;
				
				m_BlockIndex = 0;
				DiagnosticBuffTX[0] = 0x77;
				ResponseLength = 1;
				//N_USData_request(DIAGNOSTIC , N_Sa ,  N_Ta , PHYSICAL , 0 , DiagnosticBuffTX , 1);
			}
			else
			{
			    m_NRC = CNC;
				//ServiceNegReponse(ServiceName,CNC);//not in bootloader
			}
		}
		else
		{
		    m_NRC = RSE;
			//ServiceNegReponse(ServiceName,RSE);
		}
	}
	else
	{
	    m_NRC = IMLOIF;
		//ServiceNegReponse(ServiceName,IMLOIF);
	}
	#endif
}

#if 0
void DTC_Handler(void* DTCCodePtr)
{
	DTCCode* DTC = (DTCCode*)DTCCodePtr;
	
	if(DTC->DetectFunction() == TRUE)
	{
		if(DTC->DetectCounter < 0)//鍏抽敭鐐筨
		{
			DTC->DetectCounter = 2;
		}
		else
		{
			DTC->DetectCounter += 2;
		}
		
		if(DTC->DetectCounter >= DTC->DetectValidTimes)//鍏抽敭鐐筩
		{
			if(DTC->DTCStatus.DTCbit.TestFailed != 1 || DTC->DTCStatus.DTCbit.TestFailedThisMonitoringCycle == 0)
			{
				if(DTC->FaultOccurrences < 0xFF)
				{
					DTC->FaultOccurrences++;
				}
				DTC->OldCounter = 0;
				
				DTC->DTCStatus.DTCbit.TestFailed = 1;//娴嬭瘯澶辫触
				DTC->DTCStatus.DTCbit.ConfirmedDTC = 1;//宸茬‘璁ょ殑璇婃柇鏁呴殰锛屽叧閿偣e
				DTC->DTCStatus.DTCbit.TestFailedThisMonitoringCycle = 1;//鏈鎿嶄綔寰幆娴嬭瘯澶辫触
				//DTC->DTCStatus.DTCbit.PendingDTC = 1;//鏈‘璁ょ殑璇婃柇鏁呴殰鐮侊紝鍏抽敭鐐筪
				//DTC->DTCStatus.DTCbit.TestFailedSinceLastClear = 1;//鑷笂娆℃竻闄ゅ悗娴嬭瘯澶辫触
				//Printf("faild %x %x %x\r\n",DTC->DTCHightByte,DTC->DTCMiddleByte,DTC->DTCLowByte);
			}
		}
	}
	else
	{
		DTC->DetectCounter--;
		if(DTC->DetectCounter <=  (0 - DTC->DetectValidTimes))
		{
			if(DTC->DTCStatus.DTCbit.TestFailed != 0)
			{
				DTC->DTCStatus.DTCbit.TestFailed = 0;
				//Printf("success %x %x %x\r\n",DTC->DTCHightByte,DTC->DTCMiddleByte,DTC->DTCLowByte);
			}
		}
	}
}


void Diagnostic_ReadDTCPositiveResponse(uint8_t DTCSubFunction,uint8_t DTCStatausMask)
{
	uint8_t i;
	uint16_t DTCCounter = 0;
	//printf("DTC MASK %x\r\n",DTCStatausMask);
	if(DTCSubFunction == REPORT_DTCNUMBER_BY_MASK)
	{
		for(i = 0 ; i < DTC_LIST_COUNT ; i++)
		{
			if((DTCCodeList[i].DTCStatus.DTCStatusByte & DTCStatausMask & SUPPORTED_DTC_CODE) != 0 )
			{
				DTCCounter++;
			}
		}
		
		DiagnosticBuffTX[0] = 0x59;
		DiagnosticBuffTX[1] = DTCSubFunction;
		DiagnosticBuffTX[2] = DTCStatausMask;
		DiagnosticBuffTX[3] = ISO15031_6DTCFORMAT;
		DiagnosticBuffTX[4]  = (uint8_t)(DTCCounter>>8);
		DiagnosticBuffTX[5]  = (uint8_t)DTCCounter;
		N_USData_request(DIAGNOSTIC , N_Sa ,  N_Ta , PHYSICAL , 0 , DiagnosticBuffTX , 6);
	}
	else if(DTCSubFunction == REPORT_DTCCODE_BY_MASK)
	{
		uint8_t length = 3;
		DiagnosticBuffTX[0] = 0x59;
		DiagnosticBuffTX[1] = DTCSubFunction;
		DiagnosticBuffTX[2] = DTCStatausMask;
		for(i = 0 ; i < DTC_LIST_COUNT ; i++)
		{
			if((DTCCodeList[i].DTCStatus.DTCStatusByte & DTCStatausMask & SUPPORTED_DTC_CODE) != 0)
			{
				length += 4;
				DiagnosticBuffTX[length - 4] = (DTCCodeList[i].Alpha << 6) + DTCCodeList[i].DTCHightByte;
				DiagnosticBuffTX[length - 3] = DTCCodeList[i].DTCMiddleByte;
				DiagnosticBuffTX[length - 2] = DTCCodeList[i].DTCLowByte;
				DiagnosticBuffTX[length - 1] = DTCCodeList[i].DTCStatus.DTCStatusByte & SUPPORTED_DTC_CODE;
			}
		}
		N_USData_request(DIAGNOSTIC , N_Sa ,  N_Ta , PHYSICAL , 0 , DiagnosticBuffTX , length);
	}
	else if(DTCSubFunction == REPORT_SUPPORTED_DTC)
	{
		uint8_t length = 3;
		DiagnosticBuffTX[0] = 0x59;
		DiagnosticBuffTX[1] = DTCSubFunction;
		DiagnosticBuffTX[2] = SUPPORTED_DTC_CODE;
		for(i = 0 ; i < DTC_LIST_COUNT ; i++)
		{
			length += 4;
			DiagnosticBuffTX[length - 4] = (DTCCodeList[i].Alpha << 6) + DTCCodeList[i].DTCHightByte;
			DiagnosticBuffTX[length - 3] = DTCCodeList[i].DTCMiddleByte;
			DiagnosticBuffTX[length - 2] = DTCCodeList[i].DTCLowByte;
			DiagnosticBuffTX[length - 1] = DTCCodeList[i].DTCStatus.DTCStatusByte & SUPPORTED_DTC_CODE;
		}
		N_USData_request(DIAGNOSTIC , N_Sa ,  N_Ta , PHYSICAL , 0 , DiagnosticBuffTX , length);
	}
}
#endif

void ServiceNegReponse(uint8_t serviceName,uint8_t RejectCode)
{
	DiagnosticBuffTX[0] = 0x7F;
	DiagnosticBuffTX[1] = serviceName;
	DiagnosticBuffTX[2] = RejectCode;
	N_USData_request(DIAGNOSTIC, N_Sa, N_Ta, PHYSICAL, 0, DiagnosticBuffTX, 3);
}

void Diagnostic_ServiceHandle(uint8_t N_SA, uint8_t N_TA, uint8_t N_TAtype, uint16_t length, uint8_t *MessageData)
{
	//uint8_t  SIDIndex;
	bool ValidSid;
	uint16_t ServiceIndex;
	//uint8_t DataIndex;
	ValidSid = FALSE;
	ServiceIndex = 0;
	CurrentService = MessageData[0];	
	#if 0
	printf("rx[");
	for(DataIndex = 0; DataIndex < length; DataIndex++)
	{
		printf(" %x ",*(MessageData + DataIndex));
	}
	printf("]\r\n");
	#endif
	while((ServiceIndex < SERVICE_NUMBER) && (!ValidSid))
	{
		if(ServiceList[ServiceIndex].serviceName == CurrentService)
		{
			if(ServiceList[ServiceIndex].support == TRUE)
			{
				ValidSid = TRUE;
			}
			else//found service but service not enable by application layer
			{
				ValidSid = FALSE;
				break;
			}
		}
		else
		{
			ServiceIndex++;
		}
	}
	
	if(ValidSid == TRUE)
	{
		if(N_TAtype == PHYSICAL)
		{
			suppressResponse = FALSE;
			if(ECU_DEFAULT_SESSION == m_CurrSessionType)
			{
				if(ServiceList[ServiceIndex].PHYDefaultSession_Security == LEVEL_UNSUPPORT)
				{
					m_NRC = SNSIAS;
				    //ServiceNegReponse(ServiceList[ServiceIndex].serviceName,SNSIAS);
				}
				else
				{
					if((ServiceList[ServiceIndex].PHYDefaultSession_Security & m_SecurityLevel) == m_SecurityLevel)
					{
						ServiceList[ServiceIndex].serviceHandle(N_TAtype,length,MessageData);
						//LastService = ServiceList[ServiceIndex];
					}
					else
					{
						m_NRC = SAD;
					    //ServiceNegReponse(ServiceList[ServiceIndex].serviceName,SAD);
					}
				}
			}
			else if(ECU_EXTENED_SESSION == m_CurrSessionType)
			{
				if(ServiceList[ServiceIndex].PHYExtendedSession_Security == LEVEL_UNSUPPORT)
				{
					m_NRC = SNSIAS;
				    //ServiceNegReponse(ServiceList[ServiceIndex].serviceName,SNSIAS);
				}
				else
				{
					if((ServiceList[ServiceIndex].PHYExtendedSession_Security & m_SecurityLevel) == m_SecurityLevel)
					{
						ServiceList[ServiceIndex].serviceHandle(N_TAtype,length,MessageData);
						//LastService = ServiceList[ServiceIndex];
					}
					else
					{
						m_NRC = SAD;
					    //ServiceNegReponse(ServiceList[ServiceIndex].serviceName,SAD);
					}
				}
			}
			else if(ECU_PAOGRAM_SESSION == m_CurrSessionType)
			{
				if(ServiceList[ServiceIndex].PHYProgramSeesion_Security == LEVEL_UNSUPPORT)
				{
					m_NRC = SNSIAS;
				    //ServiceNegReponse(ServiceList[ServiceIndex].serviceName,SNSIAS);
				}
				else
				{
					if((ServiceList[ServiceIndex].PHYProgramSeesion_Security & m_SecurityLevel) == m_SecurityLevel)
					{
						ServiceList[ServiceIndex].serviceHandle(N_TAtype,length,MessageData);
					}
					else
					{
						m_NRC = SAD;
					    //ServiceNegReponse(ServiceList[ServiceIndex].serviceName,SAD);
					}
				}
			}
			else if(ECU_FACTORY_SESSION == m_CurrSessionType)
			{
				if(ServiceList[ServiceIndex].serviceName== SESSION_CONTROL
					|| ServiceList[ServiceIndex].serviceName== SECURITY_ACCESS
					|| ServiceList[ServiceIndex].serviceName== READ_DATA_BY_ID
					|| ServiceList[ServiceIndex].serviceName== WRITE_DATA_BY_ID
					|| ServiceList[ServiceIndex].serviceName== RESET_ECU)
				{
					ServiceList[ServiceIndex].serviceHandle(N_TAtype,length,MessageData);
				}
				else
				{
					m_NRC = SNSIAS;
				}
			}
		}
		else if(N_TAtype == FUNCTIONAL)
		{
			if(ECU_DEFAULT_SESSION == m_CurrSessionType)
			{
				if(ServiceList[ServiceIndex].FUNDefaultSession_Security == LEVEL_UNSUPPORT)
				{
					m_NRC = SNSIAS;
				    //ServiceNegReponse(ServiceList[ServiceIndex].serviceName,SNSIAS);
				}
				else
				{
					if((ServiceList[ServiceIndex].FUNDefaultSession_Security & m_SecurityLevel) == m_SecurityLevel)
					{
						ServiceList[ServiceIndex].serviceHandle(N_TAtype,length,MessageData);
						//LastService = ServiceList[ServiceIndex];
					}
					else
					{
						m_NRC = SAD;
					    //ServiceNegReponse(ServiceList[ServiceIndex].serviceName,SAD);
					}
				}
			}
			else if(ECU_EXTENED_SESSION == m_CurrSessionType)
			{
				if(ServiceList[ServiceIndex].FUNExtendedSession_Security == LEVEL_UNSUPPORT)
				{
					m_NRC = SNSIAS;
				    //ServiceNegReponse(ServiceList[ServiceIndex].serviceName,SNSIAS);
				}
				else
				{
					if((ServiceList[ServiceIndex].FUNExtendedSession_Security & m_SecurityLevel) == m_SecurityLevel)
					{
						ServiceList[ServiceIndex].serviceHandle(N_TAtype,length,MessageData);
						//LastService = ServiceList[ServiceIndex];
					}
					else
					{
						m_NRC = SAD;
					    //ServiceNegReponse(ServiceList[ServiceIndex].serviceName,SAD);
					}
				}
			}
			else if(ECU_PAOGRAM_SESSION == m_CurrSessionType)
			{
				if(ServiceList[ServiceIndex].FUNProgramSeesion_Security == LEVEL_UNSUPPORT)
				{
					m_NRC = SNSIAS;
				    //ServiceNegReponse(ServiceList[ServiceIndex].serviceName,SNSIAS);
				}
				else
				{
					if((ServiceList[ServiceIndex].FUNProgramSeesion_Security & m_SecurityLevel) == m_SecurityLevel)
					{
						ServiceList[ServiceIndex].serviceHandle(N_TAtype,length,MessageData);
						//LastService = ServiceList[ServiceIndex];
					}
					else
					{
						m_NRC = SAD;
					    //ServiceNegReponse(ServiceList[ServiceIndex].serviceName,SAD);
					}
				}
			}
			else if(ECU_FACTORY_SESSION == m_CurrSessionType)
			{
				m_NRC = SNS;
			}
		}
	}
	else
	{
		if(N_TAtype == PHYSICAL)//鍔熻兘瀵诲潃鏃犳晥SED涓嶅搷搴�
		{
			m_NRC = SNS;//ServiceNegReponse(ServiceName,SNS);
			suppressResponse = FALSE;
		}
		else
		{
			suppressResponse = TRUE;
		}
	}
}


void Diagnostic_MainProc(void)
{
    uint32_t rxId = 0;
	//bool ExistValidNotify = FALSE;
	if(!IsIndicationListEmpty())
	{
		NetworkNotification temp = PullIndication();
		rxId = ((temp.N_SA << 8) + temp.N_TA);
		if(temp.NotificationType == INDICATION)
		{
			uint8_t RequestEquipment = 0xFF;
			if((rxId & 0xFFFF) == (TesterPhyID & 0xFFFF) || (rxId & 0xFFFF) == (TesterFunID & 0xFFFF))
			{
				RequestEquipment = 0;
				N_Ta = (uint8_t)EcuID;
				N_Sa = (uint8_t)(EcuID >> 8);
			}
			else if((rxId & 0xFFFF) == (TesterPhyID1 & 0xFFFF) || (rxId & 0xFFFF) == (TesterFunID1 & 0xFFFF))
			{
				RequestEquipment = 1;
				N_Ta = (uint8_t)EcuID1;
				N_Sa = (uint8_t)(EcuID1 >> 8);
			}
		
			if(RequestEquipment == 0 || RequestEquipment == 1)
			{
				if(temp.N_Resut == N_OK ||temp.N_Resut == N_UNEXP_PDU)
				{
					Diagnostic_ServiceHandle(temp.N_SA, temp.N_TA, temp.N_TAtype, temp.length, temp.MessageData);

					#if 1
					if((temp.N_TAtype == FUNCTIONAL) && ((m_NRC == SNS) || (m_NRC == SFNS) || (m_NRC == SNSIAS) ||
					(m_NRC == SFNSIAS) || (m_NRC == ROOR)) && (ResponsePending == FALSE))
					#else
					if((temp.N_TAtype == FUNCTIONAL) && ((m_NRC == SNS) || (m_NRC == SFNS) || (m_NRC == SFNSIAS) || (m_NRC == ROOR)) && (ResponsePending == FALSE))
					#endif
					{
						//printf("res supress,pending =  %d\r\n",ResponsePending);
						/* suppress negative response message */
					}
					else if (suppressResponse == TRUE)
					{
						//printf("res supress bit is TRUE\r\n");
						/* suppress positive response message */
					}
					else
					{
						if(m_NRC == PR)
						{
							N_USData_request(DIAGNOSTIC, N_Sa, N_Ta, PHYSICAL, 0, DiagnosticBuffTX, ResponseLength);
						}
						else
						{
							ServiceNegReponse(CurrentService, m_NRC);
						}
					}

					
					if(m_CurrSessionType != ECU_DEFAULT_SESSION)
					{
						DiagTimer_Set(&S3serverTimer, 5000);
					}
				}
			}
		}
		else if(temp.NotificationType == CONFIRM)
		{
			//if((rxId & 0xFFFF) == (EcuID & 0xFFFF))
			//{
				if(WaitConfirmBeforeJump == TRUE)
				{
					
				}
				else if(WaitConfirmBeforeErase == TRUE)//鎿﹂櫎flash
				{
					WaitConfirmBeforeErase = FALSE;
					#ifdef BOOTLOADER
					//Printf("31 service will erase app\r\n");
					if(!Update_EraseFlash())
					{
	                    DiagnosticBuffTX[0] = 0x71;
	                    DiagnosticBuffTX[1] = 0x01;
	                    DiagnosticBuffTX[2] = 0xFF;
	                    DiagnosticBuffTX[3] = 0x00;
	                    DiagnosticBuffTX[4] = 0x00;
	                    N_USData_request(DIAGNOSTIC, N_Sa, N_Ta, PHYSICAL, 0, DiagnosticBuffTX, 5);
					}
					else
					{
					    ServiceNegReponse(CurrentService, GPF);
					}

					#endif
				}
				else if(WaitConfimBeforeReset == TRUE)//ECU澶嶄綅
				{
					WaitConfimBeforeReset = FALSE;
					if(ResetCallBackFun != NULL)
					{
						ResetCallBackFun(m_EcuResetType);
					}
				}
			//}
		}
		else if(temp.NotificationType == FF_INDICATION)
		{
			//Printf("RX FF ind\r\n");
		}
	}
	#if 0
	else
	{
		if(SaveDTCInBlock != FALSE)
		{
			if(DiagTimer_HasExpired(&DTCSavedTimer))
			{
				#if USE_MALLOC

				#else
				if(DTCSaved < DTCAdded)
				{
					Diagnostic_EEProm_Write(DTCS[DTCSaved].EEpromAddr, DTC_BYTE_NUMBER_TO_SAVE , &(DTCS[DTCSaved].DTCStatus));
					DTCSaved++;
					DiagTimer_Set(&DTCSavedTimer, 50);
				}
				else
				{
					SaveDTCInBlock = FALSE;
				}
				#endif
			}
		}
	}
	#endif
}

void Diagnostic_TimeProc(void)
{
	if(m_CurrSessionType != ECU_DEFAULT_SESSION)
	{
		if(DiagTimer_HasExpired(&S3serverTimer))
		{
			//printk("[time out]S3 server timeout\r\n");
			GotoSession(ECU_DEFAULT_SESSION);
		}
	}

	if(m_UnlockStep == WAIT_DELAY)
	{
		uint8_t i;
		for(i = 0; i < 3; i ++)
		{
			if(UnlockList[i].valid == TRUE)
			{
				if(DiagTimer_HasExpired(&UnlockList[i].SecurityLockTimer))
				{
					UnlockList[i].FaultCounter--;
					//Diagnostic_EEProm_Read(UnlockList[i].FaultCounterAddr, 1, &UnlockList[i].FaultCounter);CXL 婵烇絽娴傞崰妤呭极閿燂拷
					m_UnlockStep = WAIT_SEED_REQ;
				}
			}
		}
	}

	
	if(ResponsePending == TRUE && WaitConfirmBeforeJump == FALSE)
	{
		ResponsePending = FALSE;
		Service10PosResponse(m_CurrSessionType);
	}

	#if USE_J1939_DTC
	if(DM1DTCNumber != 0 && DiagDM1Enable != FALSE)
	{
		if(DiagTimer_HasExpired(&J1939Timer) || DiagTimer_HasStopped(&J1939Timer))
		{
			uint8_t i = 0;
			uint8_t j = 0;
			DiagTimer_Set(&J1939Timer, 1000);
			for(i = 0; i < DTCAdded;i++)
			{
				if(DTCS[i].DTCStatus.DTCbit.TestFailed == 1 && (DTCS[i].dtcLevel == LEVEL_B || DTCS[i].dtcLevel == LEVEL_A))
				{
					J1939BufTX[j * 8 + 0] = 0x40;
					J1939BufTX[j * 8 + 1] = 0xFF;
					J1939BufTX[j * 8 + 6] = 0xFF;
					J1939BufTX[j * 8 + 7] = 0xFF;
					J1939BufTX[j * 8 + 2] = (uint8_t)(DTCS[i].DM1Code.SPN);
					J1939BufTX[j * 8 + 3] = (uint8_t)(DTCS[i].DM1Code.SPN >> 8);
					J1939BufTX[j * 8 + 4] = (uint8_t)(((DTCS[i].DM1Code.SPN >> 11) & 0x00E0) | DTCS[i].DM1Code.FMI);
					J1939BufTX[j * 8 + 5] = (uint8_t)(((DTCS[i].FaultOccurrences) & 0xEF) | (DTCS[i].DM1Code.OC << 7));
					j++;
				}
			}
			TPCMRequestBAM(DM1DTCNumber * 8, 0xFFCA00 , J1939BufTX);
			DM1DTCNumber = 0;				
		}
	}
	#endif
	
	#if 0
	if(GlobalDTCControlParam.DataBits.EnableDTCDetect == TRUE)
	{
		if(DiagTimer_HasExpired(&DTCDetectTimer))
		{
			DiagTimer_Set(&DTCDetectTimer, 50);
			for(i = 0 ; i < DTC_LIST_COUNT ; i++)
			{
				if(DiagTimer_HasExpired(&DTCCodeList[i].DetectTimer))
				{
					Timer_Set(&DTCCodeList[i].DetectTimer, DTCCodeList[i].DectecPeroid);
					DTCCodeList[i].FaultHandler(&DTCCodeList[i]);
				}
			}
		}
	}
	#endif
}

void SaveSnapShotData(uint16_t EEPromAddr)
{
	uint8_t length = 0;
	uint8_t i;
	for(i = 0 ; i < SnapShotAdded; i++)
	{
		memcpy(DiagnosticBuffTX + length,SnapShots[i].dataPointer,SnapShots[i].dataLength);
		length += SnapShots[i].dataLength;
	}

	Diagnostic_EEProm_Write(&EEPromAddr, length, DiagnosticBuffTX);
}

void DtcHandle(DTCNode* DtcNode)
{
	//bool OperateCycleChange = FALSE;
	uint8_t CurrentResult;

	if(DtcNode!= NULL && DtcNode->DetectFunction != NULL)
	{
		CurrentResult = DtcNode->DetectFunction();
	}
	else
	{
		CurrentResult = PASSED;
	}
	
	if(CurrentResult == PASSED)
	{
		if(DtcNode->DTCStatus.DTCbit.TestNotCompleteThisMonitoringCycle == 1)
		{
			DtcNode->DTCStatus.DTCbit.TestNotCompleteThisMonitoringCycle = 0;//14229-1-Figure D.9-2
			//OperateCycleChange = TRUE;
		}

		if(DtcNode->DTCStatus.DTCbit.TestNotCompleteSinceLastClear == 1)
		{
			DtcNode->DTCStatus.DTCbit.TestNotCompleteSinceLastClear = 0;//14229-1-Figure D.9-1
		}
		if(DtcNode->DTCStatus.DTCbit.TestFailed == 1)
		{
			DtcNode->DTCStatus.DTCbit.TestFailed = 0;//14229-1-Figure D.9-7
		}
		#if 0
		if(DtcNode->DTCStatus.DTCbit.PendingDTC == 1)
		{
			DtcNode->DTCStatus.DTCbit.PendingDTC = 0;//14229-1-Table D.5
		}
		#endif
	}
	else if(CurrentResult == FAILED)
	{
		if(DtcNode->DTCStatus.DTCbit.TestNotCompleteThisMonitoringCycle == 1)
		{
			DtcNode->DTCStatus.DTCbit.TestNotCompleteThisMonitoringCycle = 0;//14229-1-Figure D.9-2
			//OperateCycleChange = TRUE;
		}

		if(DtcNode->DTCStatus.DTCbit.TestNotCompleteSinceLastClear == 1)
		{
			DtcNode->DTCStatus.DTCbit.TestNotCompleteSinceLastClear = 0;//14229-1-Figure D.9-1
		}
		if(DtcNode->DTCStatus.DTCbit.TestFailed == 0)
		{
			DtcNode->DTCStatus.DTCbit.TestFailed = 1;//14229-1-Figure D.9-3,8
		}
		if(DtcNode->DTCStatus.DTCbit.TestFailedThisMonitoringCycle ==0 )
		{
			DtcNode->DTCStatus.DTCbit.TestFailedThisMonitoringCycle = 1;//鏈鎿嶄綔寰幆娴嬭瘯澶辫触14229-1-Figure D.9-4
			DtcNode->TripCounter++;
			//DtcNode->DTCStatus.DTCbit.ConfirmedDTC = 1;
			//SaveSnapShotData(DtcNode->SnapShotEEpromAddr);
			#if 1
			if(DtcNode->TripCounter >= DtcNode->TripLimitTimes && DtcNode->DTCStatus.DTCbit.TestFailed == 1)//iso14229-1 Frigure D.4
			{
				if(DtcNode->DTCStatus.DTCbit.ConfirmedDTC != 1)
				{
					DtcNode->TripCounter = 0;
					DtcNode->DTCStatus.DTCbit.ConfirmedDTC = 1;
					SaveSnapShotData(DtcNode->SnapShotEEpromAddr);
				}
			}
			if(DtcNode->FaultOccurrences < 0xff)
			{
				DtcNode->FaultOccurrences++;
			}
			#endif
		}
		DtcNode->DTCStatus.DTCbit.PendingDTC = 1;//鏈‘璁ょ殑璇婃柇鏁呴殰鐮侊紝14229-1-Figure D.9-5
		DtcNode->DTCStatus.DTCbit.TestFailedSinceLastClear = 1;//鑷笂娆℃竻闄ゅ悗娴嬭瘯澶辫触14229-1-Figure D.9-6
		DtcNode->OldCounter = 0;

		#if USE_J1939_DTC
		if(DtcNode->dtcLevel == LEVEL_A || DtcNode->dtcLevel == LEVEL_B)
		{
			if(DM1DTCNumber < 255)
			{
				DM1DTCNumber++;
			}
		}
		#endif
	}
	else
	{
		
	}

	if(DtcNode->DTCStatus.DTCbit.TestFailedThisMonitoringCycle == 0 && DtcNode->DTCStatus.DTCbit.TestNotCompleteThisMonitoringCycle == 0)//iso14229-1 Frigure D.4
	{
		DtcNode->TripCounter = 0;
	}
}

void Diagnostic_DTCProc(void)
{
	if(EnableDTCDetect != FALSE && DiagTimer_GetTickCount() >= 1000)
	{
		if(DiagTimer_HasStopped(&DtcTimer) || DiagTimer_HasExpired(&DtcTimer))
		{
			#if USE_MALLOC
			DTCNode* DtcNode = DTCHeader;
			while(DtcNode != NULL)
			{
				DtcHandle(DtcNode);
				DtcNode = DtcNode->next;
			}
			#else
			uint8_t i;
			DM1DTCNumber = 0;   
			for(i = 0; i < DTCAdded; i++)
			{
				DtcHandle(DTCS + i);
			}
			#endif
			DiagTimer_Set(&DtcTimer, 50);
		}
	}
}

void J1939Proc(void)
{
	#if USE_J1939_DTC
	if(DiagDM1Enable != FALSE)
	{
		TPCMDTProc();
	}
	#endif
}


void Diagnostic_Proc(void)
{
    #if USE_J1939_DTC
	J1939Proc();
    #endif
	NetworkLayer_Proc();
	Diagnostic_MainProc();
	Diagnostic_TimeProc();
	Diagnostic_DTCProc();
}

/*****************************************************************
 **fun    : 璇婃柇灞侰AN鏁版嵁鎺ユ敹鍑芥暟锛�
 **name   : Diagnostic_RxFrame
 **ID     : CAN ID
 **data   : CAN鏁版嵁
 **IDE    : CAN甯х被鍨�
 **DLC    : CAN甯ф暟鎹暱搴�
 **RTR    : 鏁版嵁甯r杩滅▼甯�
 ****************************************************************/
void Diagnostic_RxFrame(uint32_t ID, uint8_t* data, uint8_t IDE, uint8_t DLC, uint8_t RTR)
{
	NetworkLayer_RxFrame(ID, data, IDE, DLC, RTR);
	if(0x0CECFF25 == ID || 0x0CEBFF25 == ID)
	{
        #if USE_J1939_DTC
		J1939TPReceiveData(ID, data, DLC);
        #endif
	}
}

void Diagnostic_1msTimer(void)
{
	DiagTimer_ISR_Proc();
}

void Diagnostic_DelInit(void)
{
	//Diagnostic_SaveAllDTC();
	SaveDTCInBlock = TRUE;
	DTCSaved = 0;
	DiagTimer_Set(&DTCSavedTimer, 10);
}


void Diagnostic_ClearDTC(uint32_t Group)
{
	#if USE_MALLOC
	DTCNode* DtcNode = DTCHeader;
	while(DtcNode != NULL)
	{
		if((DtcNode->DTCCode & Group) == DtcNode->DTCCode)//ONLY FFFFFF group supported this method
		{
			DtcNode->DTCStatus.DTCStatusByte = 0x50;//when clear bit4 and bit6 must be setted to 1
			DtcNode->FaultOccurrences = 0;
			DtcNode->OldCounter = 0;
			DtcNode->GoneCounter = 0;
			DtcNode->TripCounter = 0;
			//Diagnostic_EEProm_Write(DtcNode->EEpromAddr, DTC_BYTE_NUMBER_TO_SAVE , &(DtcNode->DTCStatus.DTCStatusByte));
		}
		DtcNode = DtcNode->next;
	}
	#else
	uint8_t i;
	for(i = 0; i < DTCAdded; i++)
	{
		if((DTCS[i].DTCCode & Group) == DTCS[i].DTCCode)
		{
			DTCS[i].DTCStatus.DTCStatusByte = 0x50;//when clear bit4 and bit6 must be setted to 1
			DTCS[i].FaultOccurrences = 0;
			DTCS[i].OldCounter = 0;
			DTCS[i].GoneCounter = 0;
			DTCS[i].TripCounter = 0;
			#if 1
			if(SaveDTCInBlock == FALSE)
			{
				SaveDTCInBlock = TRUE;
				DTCSaved = 0;
			}
			#endif
			//Diagnostic_EEProm_Write(DTCS[i].EEpromAddr, DTC_BYTE_NUMBER_TO_SAVE , &(DTCS[i].DTCStatus));
		}
	}
	#endif
}

void Diagnostic_SaveAllDTC(void)
{
	#if USE_MALLOC
	DTCNode* DtcNode = DTCHeader;
	while(DtcNode  != NULL)
	{
		if(DtcNode->DTCStatus.DTCbit.TestFailedThisMonitoringCycle == 0  && DtcNode->DTCStatus.DTCbit.ConfirmedDTC == 1)
		{
			if(DtcNode->OldCounter >= 100)//鏁呴殰鐮佽�佸寲鏈哄埗
			{
				DtcNode->OldCounter = 0;
				DtcNode->GoneCounter++;
				DtcNode->DTCStatus.DTCStatusByte = 0x50;//when clear bit4 and bit6 must be setted to 1 and others 0
				DtcNode->FaultOccurrences = 0;
				DtcNode->OldCounter = 0;
				DtcNode->GoneCounter = 0;
				DtcNode->TripCounter = 0;
			}
			else
			{
				DtcNode->OldCounter++;
			}
		}
		else
		{
			DtcNode->OldCounter = 0;
		}
		DtcNode->DTCStatus.DTCStatusByte &= 0xBD;//bit1 and bit6 can not be saved
		Diagnostic_EEProm_Write(DtcNode->EEpromAddr, DTC_BYTE_NUMBER_TO_SAVE , &(DtcNode->DTCStatus.DTCStatusByte));
		DtcNode  = DtcNode ->next;
	}
	#else
	uint8_t i;
	uint16_t DtcStartAddr = DTCS[0].EEpromAddr;
	uint16_t DtcBytesToSave = 0;
	uint8_t  DtcBytes[180];
	for(i = 0 ; i < DTCAdded ; i++)
	{
		if(DTCS[i].DTCStatus.DTCbit.TestNotCompleteSinceLastClear == 0 && DTCS[i].DTCStatus.DTCbit.TestFailedThisMonitoringCycle == 0)
		{
			DTCS[i].DTCStatus.DTCbit.PendingDTC = 0;
		}
	
		if(DTCS[i].DTCStatus.DTCbit.TestFailedThisMonitoringCycle == 0  && DTCS[i].DTCStatus.DTCbit.ConfirmedDTC == 1)
		{
			if(DTCS[i].OldCounter >= 40)//鏁呴殰鐮佽�佸寲鏈哄埗
			{
				DTCS[i].OldCounter = 0;
				DTCS[i].GoneCounter++;
				DTCS[i].DTCStatus.DTCStatusByte = 0x50;//when clear bit4 and bit6 must be setted to 1 and others 0
				DTCS[i].FaultOccurrences = 0;
				DTCS[i].OldCounter = 0;
				DTCS[i].GoneCounter = 0;
				DTCS[i].TripCounter = 0;
			}
			else
			{
				DTCS[i].OldCounter++;
			}
		}
		else
		{
			DTCS[i].OldCounter = 0;
		}
		DTCS[i].DTCStatus.DTCStatusByte &= 0xBD;//bit1 and bit6 can not be saved
		memcpy(DtcBytes + DtcBytesToSave,&(DTCS[i].DTCStatus),DTC_BYTE_NUMBER_TO_SAVE);
		DtcBytesToSave += DTC_BYTE_NUMBER_TO_SAVE;
		//Diagnostic_EEProm_Write(DTCS[i].EEpromAddr, DTC_BYTE_NUMBER_TO_SAVE , &(DTCS[i].DTCStatus));//&(DTCS[i].DTCStatus.DTCStatusByte));
	}
	Diagnostic_EEProm_Write(&DtcStartAddr, DtcBytesToSave, DtcBytes);
	#endif
}

void Diagnostic_LoadAllDTC(void)
{
	#if USE_MALLOC
	DTCNode* DtcNode = DTCHeader;
	while(DtcNode  != NULL)
	{
		Diagnostic_EEProm_Read(DtcNode->EEpromAddr, DTC_BYTE_NUMBER_TO_SAVE , &(DtcNode->DTCStatus.DTCStatusByte));
		DtcNode->DTCStatus.DTCStatusByte |= 0x40;//when IGN ON, bit6 default 1,
		DtcNode->DTCStatus.DTCStatusByte &= 0xFD;//when IGN ON, bit1 default 0
		DtcNode  = DtcNode ->next;
	}
	#else
	uint8_t i;
	for(i = 0 ; i < DTCAdded ; i++)
	{
		//Diagnostic_EEProm_Read(&(DTCS[i].EEpromAddr), DTC_BYTE_NUMBER_TO_SAVE, &(DTCS[i].DTCStatus));
		DTCS[i].DTCStatus.DTCStatusByte |= 0x40;//when IGN ON, bit6 default 1,
		DTCS[i].DTCStatus.DTCStatusByte &= 0xFD;//when IGN ON, bit1 default 0
	}
	#endif
}

void Diagnostic_LoadSecuriyFaultCounter(void)
{
	uint8_t i;
	for(i = 0 ; i < 3 ; i++)
	{
		if(UnlockList[i].valid != FALSE)
		{
			Diagnostic_EEProm_Read(&UnlockList[i].FaultCounterAddr, 1 ,&UnlockList[i].FaultCounter);
			if(UnlockList[i].FaultCounter == 0xFF)
			{
				UnlockList[i].FaultCounter = 0;
			}
			else if(UnlockList[i].FaultCounter >= UnlockList[i].FaultLimitCounter)
			{
				UnlockList[i].FaultCounter = 0;
				m_UnlockStep = WAIT_DELAY;
				DiagTimer_Set(&UnlockList[i].SecurityLockTimer , UnlockList[i].UnlockFailedDelayTime);
			}
			Diagnostic_EEProm_Write(&UnlockList[i].FaultCounterAddr, 1 ,&UnlockList[i].FaultCounter);
		}
	}
}

void Diagnostic_DTCDefaultValue(void)
{
	#if USE_MALLOC
	DTCNode* DtcNode = DTCHeader;
	while(DtcNode != NULL)
	{
		DtcNode->DTCStatus.DTCStatusByte = 0x50;
		DtcNode->FaultOccurrences = 0;
		DtcNode->OldCounter = 0;
		DtcNode->GoneCounter = 0;
		DtcNode->TripCounter = 0;
		Diagnostic_EEProm_Write(DtcNode->EEpromAddr, DTC_BYTE_NUMBER_TO_SAVE , &(DtcNode->DTCStatus.DTCStatusByte));
		DtcNode= DtcNode->next;
	}
	#else

	#endif
}

void Diagnostic_BindingSnapshot(void)
{
	uint8_t i;
	uint16_t SnapshotDataLength = 0;
	for(i = 0 ;  i < SnapShotAdded ; i ++)
	{
		SnapshotDataLength += SnapShots[i].dataLength;
	}
	
	for(i = 0 ;  i < MAX_DTC_NUMBER ; i ++)
	{
		DTCS[i].SnapShotEEpromAddr = ModuleEEpromStartAddr + EEpromUsed + SnapshotDataLength * i;
	}
}

void Diagnostic_LoadAllData(void)
{
	Diagnostic_LoadAllDTC();
	Diagnostic_LoadSecuriyFaultCounter();
	Diagnostic_BindingSnapshot();
}

/*
** ===================================================================
**eeprom driver end
** ===================================================================
*/

void Diagnostic_ConfigVIN(uint8_t length, uint8_t* data)
{
	DIDNode* didNode = SearchDidNode(0xF190);
	if(didNode != NULL && didNode->dataLength == length)
	{
		if(didNode->RWAttr == READWRITE && didNode->didType == EEPROM_DID)
		{
			//Diagnostic_EEProm_Write((uint32_t)(didNode->dataPointer), didNode->dataLength, data);
		}
	}
}

#if USE_J1939_DTC
void Diagnostic_DM1MsgEnable(bool dm1en)
{
	DiagDM1Enable = dm1en;
}
#endif



#endif  /* DIAGNOSTIC_C_ */

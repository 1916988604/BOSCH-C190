#ifndef LINKLIST_C_
#define LINKLIST_C_

#include "../user/inc/Dsp280015x.h"
#include "LinkList.h"



/*****************************************************************
 **fun    : ���ӽڵ�
 **name   : AddNode
 **param0 : header:ͷָ��
 **param1 : listNode:�ڵ�ָ��
 **return : ��
 ****************************************************************/
void AddNode(node* header , node* listNode)
{
	node* temp = header;
	while(temp->next != NULL)
	{
		temp = temp->next;
	}
	temp->next = listNode;
	temp->next->next = NULL;
}



/*****************************************************************
 **fun    : ɾ���ڵ�
 **name   : DeleteNode
 **param0 : header:ͷָ��
 **param1 : index:�ڵ�����
 **return : ��
 ****************************************************************/
void DeleteNode(node* header , int index)
{
	uint32_t i;
	node* temp = header;
	node* prevNode;
	for(i = 0; i < index ; i++)
	{
		prevNode = temp;
		temp = temp->next;
	}
	prevNode->next = temp->next;
	//free(temp);
}



/*****************************************************************
 **fun    : ��ȡ�ڵ�����
 **name   : GetNodeData
 **param0 : header:ͷָ��
 **param1 : index:�ڵ�����
 **return : ��
 ****************************************************************/
void* GetNodeData(node* header , int index)//header->next is 0 index,header not mean only index
{
	uint32_t i;
	node* temp = header;
	for(i = 0; i < index ; i++)
	{
		temp = temp->next;
	}
	return temp->dataPoint;
}


#endif /*LINKLIST_C_*/

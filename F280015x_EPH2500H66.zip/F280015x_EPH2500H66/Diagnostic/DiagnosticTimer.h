#ifndef DIAGNOSTICTIMER_H_
#define DIAGNOSTICTIMER_H_

#ifdef __cplusplus
 extern "C" {
#endif 

#include "Cpu.h"

#ifndef bool
#define bool uint16_t
#endif

#ifdef  DIAGNOSTICTIMER_C_
    #define DIAGNOSTICTIMER
#else
    #define DIAGNOSTICTIMER  extern
#endif

typedef struct{
	uint32_t TimerCounter;
	bool valid;
}DiagTimer;


DIAGNOSTICTIMER void DiagTimer_Init(void);
DIAGNOSTICTIMER void DiagTimer_Set(DiagTimer *STimer, uint32_t TimeLength);
DIAGNOSTICTIMER bool DiagTimer_HasStopped(DiagTimer *STimer);
DIAGNOSTICTIMER bool DiagTimer_HasExpired (DiagTimer *STimer);
DIAGNOSTICTIMER void DiagTimer_Stop(DiagTimer *STimer);
DIAGNOSTICTIMER void DiagTimer_DelayMs (uint32_t ms);
DIAGNOSTICTIMER void DiagTimer_DelayUs(uint32_t us);
DIAGNOSTICTIMER void DiagTimer_WaitExpired (DiagTimer *STimer);
DIAGNOSTICTIMER uint32_t DiagTimer_GetTickCount(void);
DIAGNOSTICTIMER void DiagTimer_ISR_Proc(void);

#ifdef __cplusplus
}
#endif


#endif /* DIAGNOSTICTIMER_H_ */


#ifndef J1939TP_H_
#define J1939TP_H_

#ifdef  J1939TP_C_
    #define J1939TP
#else
    #define J1939TP  extern
#endif

typedef char (*SendJ1939CANFun)(long ID, char *array, char length, char priority);

J1939TP void TPCMSetParamBAM(SendJ1939CANFun sendinterface);
J1939TP void TPCMRequestBAM(short messageLength,  long PGN,unsigned char* buf);
J1939TP void TPCMDTProc(void);
J1939TP void J1939TPReceiveData(unsigned long id,unsigned char* data, unsigned char length);
J1939TP void J1939TPGetReceiveData(unsigned short* length, unsigned char** dataPointer);

#endif /*  J1939TP_H_  */


#ifndef DIAGNOSTIC_H_
#define DIAGNOSTIC_H_

#include "NetworkLayerTypeDefines.h"

#ifdef DIAGNOSTIC_C_
    #define DIAGNOSTICC
#else
    #define DIAGNOSTICC  extern
#endif

typedef enum{
	LEVEL_ZERO = 7,
	LEVEL_ONE = 1,
	LEVEL_TWO = 2,
	LEVEL_THREE = 4,
	LEVEL_FOUR = 8,
	LEVEL_UNSUPPORT = 0,
}SecurityLevel;

typedef enum{
	HARD_RESET = 1,
	KEY_OFF_ON_RESET = 2,
	SOFT_RESET = 3,
	ENABLE_RAPID_POWER_SHUTDOWN = 4,
	DISABLE_RAPID_POWER_SHUTDOWN = 5,
}EcuResetType;

typedef enum{
	ISO15031_6DTCFORMAT= 1,
	ISO14229_1DTCFORMAT = 2,
	SAEJ1939_73DTCFORMAT = 3,
}DTCFormatIdentifier;

typedef enum{
	PASSED,
	IN_TESTING,
	FAILED,
}DTCTestResult;

typedef enum{
	EEPROM_DID,
	REALTIME_DID,
	IO_DID,
}DIDType;

typedef enum{
	READONLY = 1,
	WRITEONLY = 2,
	READWRITE = 3,
}ReadWriteAttr;

typedef enum{
	ERXTX,//enableRxAndTx
	ERXDTX,//enableRxAndDisableTx
	DRXETX,//disableRxAndEnableTx
	DRXTX,//disableRxAndTx
	//ERXDTXWEAI,//enableRxAndDisableTxWithEnhancedAddressInformation
	//ERXTXWEAI,//enableRxAndTxWithEnhancedAddressInformation
}CommulicationType;

typedef enum{
	NCM = 1,//application message
	NWMCM,//network manage message
	NWMCM_NCM,//application and netwrok manage message
}communicationParam;

typedef enum{
	SUB_DEFAULT = 1,//sub function supported in default session
	SUB_PROGRAM = 2,//sub function supported in program session
	SUB_EXTENDED = 4,////sub function supported in extedned session
	SUB_FACTORY = 8,//sub funcion supported in factory session,
	SUB_ALL = 7,//sub function supported in both of three session
}SubFunSuppInSession;

typedef enum{
	LEVEL_A,
	LEVEL_B,
	LEVEL_C,
}DTCLevel;

typedef enum{
    ECU_DEFAULT_SESSION = 1,
    ECU_PAOGRAM_SESSION = 2,
    ECU_EXTENED_SESSION = 3,
    ECU_FACTORY_SESSION = 0x71,//��Ӧ��session��������������
}SessionType;

typedef uint8_t (*IoControl)(uint8_t ctrl, uint8_t param);
//typedef uint32_t (*SecurityFun)(uint32_t);
typedef void (*SecurityFun)(uint8_t *seed, uint8_t *key, uint8_t size);
typedef DTCTestResult (*DetectFun)(void);
typedef void (*ResetCallBack)(EcuResetType);
typedef void (*CommCallBack)(CommulicationType, communicationParam);
typedef uint8_t (*SendCANFun)(uint32_t ID, uint8_t *array, uint8_t length);

#define USE_MALLOC			0
#define	USE_J1939_DTC		0
//#define BOOTLOADER

/*======================== buf size config ================================*/	
#define MAX_DTC_NUMBER 				35//���DTC����
#define MAX_DID_NUMBER 				70//���DID����
#define MAX_SNAPSHOT_NUMBER 		10//��������Ϣ����
#define MAX_GROUP_NUMBER			5//���DTC�����
/*======================== buf size config ================================*/	

DIAGNOSTICC void Diagnostic_Init(uint32_t requestId, uint32_t responseId, uint32_t funRequestId, uint32_t EEPromStartAddr, uint16_t EEpromSize,SendCANFun sendFun,uint16_t p2CanServerMax, uint16_t p2ECanServerMax);
DIAGNOSTICC void Diagnostic_Set2ndReqAndResID(uint32_t requestId1, uint32_t responseId1,uint32_t funRequestId1);
DIAGNOSTICC void Diagnostic_DelInit(void);
DIAGNOSTICC void Diagnostic_RxFrame(uint32_t ID,uint8_t* data,uint8_t IDE,uint8_t DLC,uint8_t RTR);
DIAGNOSTICC void Diagnostic_1msTimer(void);
DIAGNOSTICC bool InitAddSecurityAlgorithm(SecurityLevel level, SecurityFun AlgoritthmFun,byte SeedSubFunctionNum,byte KeySubFunctionNum , uint8_t* FaultCounter,uint8_t FaultLimitCounter , uint32_t UnlockFailedDelayTimeMS,SubFunSuppInSession SubFuntioncSupportedInSession,uint8_t KeySize);
DIAGNOSTICC void InitFactorySecuriyAlgorithm(void);
DIAGNOSTICC bool InitSetSessionSupportAndSecurityAccess(bool support ,uint8_t service,uint8_t PHYDefaultSession_Security,	uint8_t PHYProgramSeesion_Security,	uint8_t PHYExtendedSession_Security,	uint8_t FUNDefaultSession_Security,	uint8_t FUNProgramSeesion_Security,	uint8_t FUNExtendedSession_Security);
DIAGNOSTICC void InitAddDID(uint16_t DID , uint8_t DataLength , uint8_t* DataPointer , DIDType DidType , IoControl ControlFun , ReadWriteAttr RWAttr,uint16_t EEaddr, bool SupportWriteInFactoryMode);
#if USE_J1939_DTC
DIAGNOSTICC void Diagnostic_DM1MsgEnable(bool dm1en);
DIAGNOSTICC bool InitAddDTC(uint32_t DTCCode,DetectFun MonitorFun,byte DectecPeroid, byte ValidTimes,DTCLevel dtcLevel,uint32_t spn, uint8_t fmi);
#else
DIAGNOSTICC bool InitAddDTC(uint32_t DTCCode,DetectFun MonitorFun,byte DectecPeroid, byte ValidTimes,DTCLevel dtcLevel);
#endif
DIAGNOSTICC void InitAddDTCSnapShot(uint8_t recordNumber , uint16_t ID , uint8_t* datap , uint8_t size);
DIAGNOSTICC void InitSetAgingCounterRecordNumber(uint8_t RecordNumer);
DIAGNOSTICC void InitSetAgedCounterRecordNumber(uint8_t RecordNumer);
DIAGNOSTICC void InitSetOccurrenceCounterRecordNumber(uint8_t RecordNumer);
DIAGNOSTICC void InitSetPendingCounterRecordNumber(uint8_t RecordNumer);
//DIAGNOSTICC void InitAddDTCExtendedData(uint16_t ID , uint8_t* datap , uint8_t size);
DIAGNOSTICC void InitSetDTCAvailiableMask(uint8_t AvailiableMask);
DIAGNOSTICC void InitAddDTCGroup(uint32_t Group);
DIAGNOSTICC void InitSetSysResetParam(bool support01 , bool support02 , bool support03 , bool support04 , bool support05 , ResetCallBack callback, bool supressPosResponse);
DIAGNOSTICC void InitSetCommControlParam(bool supportSubFun00, bool supportSubFun01 , bool supportSubFun02 , bool supportSubFun03 , bool supportType01, bool supportType02, bool supportType03, CommCallBack callback, bool supressPosResponse);
DIAGNOSTICC void InitSetSessionControlParam(bool supportSub01, bool supportSub02,bool supportSub03, bool sub02SupportedInDefaultSession, bool sub03SupportedInProgramSession, bool supressPosResponse);
DIAGNOSTICC void InitSetTesterPresentSupress(bool supressPosResponse);
DIAGNOSTICC void InitSetDTCControlSupress(bool supressPosResponse);
DIAGNOSTICC void InitSetCurrentSessionDID(uint16_t m_DID);
DIAGNOSTICC void InitSetCanDataBaseVersionDID(uint16_t m_DID);
DIAGNOSTICC void InitSetCanDiagnosticVersionDID(uint16_t m_DID);
DIAGNOSTICC void InitSetCanNMVersionDID(uint16_t m_DID);
DIAGNOSTICC void InitSetCanDriverVersionDID(uint16_t m_DID);
DIAGNOSTICC void Diagnostic_LoadAllData(void);
DIAGNOSTICC void Diagnostic_ConfigVIN(uint8_t length, uint8_t* data);
DIAGNOSTICC void Diagnostic_SetNLParam(uint8_t TimeAs, uint8_t TimeBs, uint8_t TimeCr, uint8_t TimeAr, uint8_t TimeBr, uint8_t TimeCs, uint8_t BlockSize, uint8_t m_STmin, uint8_t FillData);
DIAGNOSTICC void Diagnostic_Proc(void);
DIAGNOSTICC uint32_t CRC32_Calculate(const uint8_t* data, uint32_t length, uint32_t crcTnit);
DIAGNOSTICC SessionType m_CurrSessionType;    //��ǰ�ػ�����
#endif  /* DIAGNOSTIC_H_ */

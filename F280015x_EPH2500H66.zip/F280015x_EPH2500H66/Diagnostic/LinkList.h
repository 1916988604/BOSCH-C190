#ifndef LINKLIST_H_
#define LINKLIST_H_

#include "NetworkLayerTypeDefines.h"

#ifdef  LINKLIST_C_
    #define LINKLIST
#else
    #define LINKLIST  extern
#endif


#ifndef  node
typedef struct LinkList{
	void* dataPoint;
	//uint8_t index;
	struct LinkList* next;
	//struct LinkList* prev;
}node;
#endif

LINKLIST void AddNode(node* header , node* listNode);
LINKLIST void DeleteNode(node* header , int index);
LINKLIST void* GetNodeData(node* header , int index);

#endif /*LINKLIST_H_*/
